'use strict';
/* API khusus admin: /api/admin/*  (semua rute wajib login sebagai admin) */
const express = require('express');

module.exports = function adminRouter({ db, fail, currentUser, rateLimit, TZH }) {
  const router = express.Router();
  const TZ_MOD = `${TZH >= 0 ? '+' : ''}${TZH} hours`; // zona waktu untuk "hari ini" & grafik (default WIB)

  router.use(rateLimit({
    windowMs: 60 * 1000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false,
    handler: (req, res) => fail(res, 429, 'Terlalu banyak permintaan. Coba sebentar lagi.'),
  }));
  router.use((req, res, next) => {
    const u = currentUser(req);
    if (!u) return fail(res, 401, 'Belum masuk.');
    if (u.role !== 'admin') return fail(res, 403, 'Akses ditolak. Akun ini bukan admin.');
    req.user = u;
    next();
  });

  const count = (sql, ...p) => db.prepare(sql).get(...p).n;

  router.get('/stats', (req, res) => {
    const total = count('SELECT COUNT(*) n FROM users');
    const last7 = count("SELECT COUNT(*) n FROM users WHERE created_at >= datetime('now','-7 days')");
    const today = count("SELECT COUNT(*) n FROM users WHERE date(created_at, ?) = date('now', ?)", TZ_MOD, TZ_MOD);
    const admins = count("SELECT COUNT(*) n FROM users WHERE role = 'admin'");
    const active = count('SELECT COUNT(DISTINCT user_id) n FROM sessions WHERE expires_at > ?', Date.now());
    const rows = db.prepare(
      "SELECT date(created_at, ?) d, COUNT(*) n FROM users WHERE date(created_at, ?) >= date('now', ?, '-13 days') GROUP BY d"
    ).all(TZ_MOD, TZ_MOD, TZ_MOD);
    const byDay = Object.fromEntries(rows.map((r) => [r.d, r.n]));
    const daily = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(Date.now() + TZH * 3600e3 - i * 86400e3).toISOString().slice(0, 10);
      daily.push({ date: d, n: byDay[d] || 0 });
    }
    res.json({ total, last7, today, admins, active, daily });
  });

  router.get('/users', (req, res) => {
    const qs = String(req.query.q || '').trim().slice(0, 100);
    const per = 20;
    const where = qs ? "WHERE name LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\'" : '';
    const like = '%' + qs.replace(/[\\%_]/g, (m) => '\\' + m) + '%';
    const args = qs ? [like, like] : [];
    const total = count(`SELECT COUNT(*) n FROM users ${where}`, ...args);
    const pages = Math.max(1, Math.ceil(total / per));
    const page = Math.min(Math.max(1, parseInt(req.query.page, 10) || 1), pages);
    const users = db.prepare(
      `SELECT id, name, email, role, created_at FROM users ${where} ORDER BY id DESC LIMIT ? OFFSET ?`
    ).all(...args, per, (page - 1) * per);
    res.json({ users, total, page, pages, meId: req.user.id });
  });

  const target = (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) { fail(res, 400, 'ID tidak valid.'); return null; }
    const u = db.prepare('SELECT id, role FROM users WHERE id = ?').get(id);
    if (!u) { fail(res, 404, 'Pengguna tidak ditemukan.'); return null; }
    return u;
  };

  router.post('/users/:id/role', (req, res) => {
    const u = target(req, res); if (!u) return;
    const role = req.body && req.body.role;
    if (role !== 'admin' && role !== 'user') return fail(res, 400, 'Peran tidak valid.');
    if (u.id === req.user.id) return fail(res, 400, 'Tidak bisa mengubah peran akun sendiri.');
    if (u.role === 'admin' && role === 'user' && count("SELECT COUNT(*) n FROM users WHERE role = 'admin'") <= 1) {
      return fail(res, 400, 'Harus ada minimal satu admin.');
    }
    db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, u.id);
    res.json({ ok: true });
  });

  router.delete('/users/:id', (req, res) => {
    const u = target(req, res); if (!u) return;
    if (u.id === req.user.id) return fail(res, 400, 'Tidak bisa menghapus akun sendiri.');
    db.prepare('DELETE FROM users WHERE id = ?').run(u.id); // sesi ikut terhapus (ON DELETE CASCADE)
    res.json({ ok: true });
  });

  return router;
};
