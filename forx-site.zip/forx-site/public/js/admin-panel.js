/* Panel admin FOR-X. Semua pengecekan akses dilakukan di server; halaman ini hanya tampilan. */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (t, o) => t ? new Date(t).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', ...(o || { dateStyle: 'medium', timeStyle: 'short' }) }) : '-';
const fmtDay = t => fmt(t, { dateStyle: 'medium' });
const store = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }, del(k) { try { localStorage.removeItem(k); } catch (e) { } } };

async function api(path, body) {
  try {
    const r = await fetch(path, { method: body === undefined ? 'GET' : 'POST', headers: body === undefined ? {} : { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body), credentials: 'same-origin' });
    let j = {}; try { j = await r.json(); } catch (e) { }
    return { status: r.status, ...j };
  } catch (e) { return { status: 0, ok: false, error: 'Tidak dapat terhubung ke server.' }; }
}

/* ---------- tema ---------- */
function setTheme(t) { document.documentElement.dataset.theme = t; store.set('theme', t); $('#theme').textContent = t === 'dark' ? '☀' : '☾'; }
setTheme(store.get('theme') === 'light' ? 'light' : 'dark');
$('#theme').onclick = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
$('#logout').onclick = async () => { await api('/api/logout', {}); store.del('session'); location.href = 'masuk.html'; };

/* ---------- toast ---------- */
let tt;
function toast(msg, err) { const t = $('#toast'); t.textContent = msg; t.className = 'ad-toast' + (err ? ' err' : ''); t.hidden = false; clearTimeout(tt); tt = setTimeout(() => t.hidden = true, 3600); }

/* ---------- dialog ---------- */
const dlg = $('#dlg'), dlgBody = $('#dlgBody');
function openDlg(html) { dlgBody.innerHTML = '<div class="dl">' + html + '</div>'; if (!dlg.open) dlg.showModal(); }
dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });

/* konfirmasi: kembalikan true (atau teks yang diketik) bila disetujui */
function confirmDlg({ title, body, ok = 'Ya, lanjutkan', danger, expect, label }) {
  return new Promise(resolve => {
    openDlg(`<h2>${esc(title)}</h2><p>${body}</p>
      ${expect ? `<label for="cf">${esc(label)}</label><input id="cf" autocomplete="off" spellcheck="false" placeholder="${esc(expect)}">` : ''}
      <div class="dl-act"><button type="button" class="btn pill ghost" id="cNo">Batal</button><button type="button" class="btn pill ${danger ? 'danger' : 'primary'}" id="cOk" ${expect ? 'disabled' : ''}>${esc(ok)}</button></div>`);
    const inp = $('#cf'), okb = $('#cOk');
    if (inp) { inp.oninput = () => okb.disabled = inp.value.trim().toLowerCase() !== expect.toLowerCase(); inp.focus(); } else okb.focus();
    let done = false; const fin = v => { if (done) return; done = true; dlg.close(); resolve(v); };
    $('#cNo').onclick = () => fin(false);
    okb.onclick = () => fin(inp ? inp.value.trim() : true);
    dlg.addEventListener('close', () => fin(false), { once: true });
  });
}

/* ---------- ringkasan ---------- */
async function loadStats() {
  const r = await api('/api/admin/stats'); if (!r.ok) return;
  const s = r.stats;
  $('#stats').innerHTML = [['Total pengguna', s.total], ['Daftar hari ini', s.today], ['Daftar 7 hari', s.last7], ['Admin', s.admins], ['VVIP aktif', s.vvip ?? 0], ['Sesi login aktif', s.activeSessions]]
    .map(([l, n]) => `<div class="stat"><b>${n}</b><span>${l}</span></div>`).join('');
  const max = Math.max(1, ...s.daily.map(d => d.n));
  $('#bars').innerHTML = s.daily.map(d => {
    const dt = new Date(d.d + 'T00:00:00Z'), lab = dt.toLocaleDateString('id-ID', { timeZone: 'UTC', day: 'numeric', month: 'short' });
    return `<div class="bar${d.n ? '' : ' zero'}" title="${esc(lab)}: ${d.n} pendaftar"><i style="height:${d.n ? Math.max(6, d.n / max * 100) : 3}%"></i><span>${dt.getUTCDate()}</span></div>`;
  }).join('');
  $('#chartNote').textContent = 'Total ' + s.daily.reduce((a, d) => a + d.n, 0) + ' pendaftar (zona waktu WIB)';
}

/* ---------- VVIP: helper tanggal (semua dalam WIB) ---------- */
const wibDay = t => new Date(t + 7 * 36e5).toISOString().slice(0, 10);
const addDays = (d, n) => new Date(Date.parse(d + 'T00:00:00Z') + n * 864e5).toISOString().slice(0, 10);
const daysLeft = t => Math.max(0, Math.ceil((Date.parse(t) - Date.now()) / 864e5));
function vvipCell(u) {
  if (u.vvipActive) return `<span class="vv on">VVIP</span><span class="vv-sub">sampai ${fmtDay(u.vvipUntil)} · ${daysLeft(u.vvipUntil)} hari lagi</span>`;
  if (u.vvipUntil) return `<span class="vv">Berakhir</span><span class="vv-sub">${fmtDay(u.vvipUntil)}</span>`;
  return '<span class="mut">-</span>';
}

/* ---------- pengguna ---------- */
let state = { q: '', page: 1, pages: 1, me: null }, qt;
async function loadUsers() {
  closeMenu();
  const r = await api(`/api/admin/users?q=${encodeURIComponent(state.q)}&page=${state.page}`);
  if (!r.ok) { toast(r.error || 'Gagal memuat pengguna.', true); return; }
  state.pages = r.pages; state.page = r.page;
  $('#count').textContent = r.total + ' pengguna' + (state.q ? ' cocok' : '');
  $('#pg').textContent = `Halaman ${r.page} dari ${r.pages}`;
  $('#prev').disabled = r.page <= 1; $('#next').disabled = r.page >= r.pages;
  $('#rows').innerHTML = r.users.length ? r.users.map(u => {
    const self = u.email === state.me.email;
    return `<tr data-e="${esc(u.email)}">
      <td class="first"><div class="u-name">${esc(u.name)}${self ? ' <span class="mut">(Anda)</span>' : ''}</div><div class="u-mail">${esc(u.email)}</div></td>
      <td data-l="WhatsApp">${esc(u.phone) || '-'}</td>
      <td data-l="Peran"><span class="role ${u.role === 'admin' ? 'admin' : ''}">${u.role === 'admin' ? 'Admin' : u.role === 'trader' ? 'Trader' : 'Member'}</span></td>
      <td data-l="VVIP" class="vvc">${vvipCell(u)}</td>
      <td data-l="Daftar">${fmtDay(u.created)}</td>
      <td data-l="Referal" class="ref"><code>${esc(u.referral)}</code> · ${u.referred} orang</td>
      <td data-l="Sesi aktif">${u.sessions}</td>
      <td class="r"><button type="button" class="act-btn" data-a="menu" aria-haspopup="menu" aria-expanded="false" aria-label="Aksi untuk ${esc(u.name)}">Aksi</button></td></tr>`;
  }).join('') : `<tr><td class="empty" colspan="8">${state.q ? 'Tidak ada pengguna yang cocok.' : 'Belum ada pengguna.'}</td></tr>`;
  window._users = Object.fromEntries(r.users.map(u => [u.email, u]));
}
$('#q').addEventListener('input', e => { clearTimeout(qt); qt = setTimeout(() => { state.q = e.target.value.trim(); state.page = 1; loadUsers(); }, 280); });
$('#prev').onclick = () => { if (state.page > 1) { state.page--; loadUsers(); } };
$('#next').onclick = () => { if (state.page < state.pages) { state.page++; loadUsers(); } };
const refresh = () => Promise.all([loadUsers(), loadStats()]);

/* ---------- menu aksi (dropdown) ---------- */
const menu = document.createElement('div');
menu.className = 'ad-menu'; menu.setAttribute('role', 'menu'); menu.hidden = true; document.body.append(menu);
let menuBtn = null;
function closeMenu(refocus) {
  if (!menuBtn) return;
  menuBtn.setAttribute('aria-expanded', 'false'); if (refocus) menuBtn.focus();
  menuBtn = null; menu.hidden = true; menu.innerHTML = '';
}
function placeMenu() {   // posisi menu mengikuti tombolnya (juga saat halaman di-scroll)
  if (!menuBtn) return;
  const r = menuBtn.getBoundingClientRect();
  if (r.bottom < 0 || r.top > innerHeight) return closeMenu();
  const w = menu.offsetWidth, h = menu.offsetHeight;
  const left = Math.min(Math.max(8, r.right - w), innerWidth - w - 8);
  const top = (r.bottom + 6 + h > innerHeight - 8 && r.top - h - 6 > 8) ? r.top - h - 6 : r.bottom + 6;   // buka ke atas bila kurang ruang di bawah
  menu.style.left = left + 'px'; menu.style.top = top + 'px';
}
function openMenu(btn, email) {
  if (menuBtn === btn) return closeMenu();
  closeMenu();
  const u = window._users[email], self = email === state.me.email;
  const items = [
    { a: 'vvip', t: u.vvipActive ? 'Kelola VVIP' : 'Beri VVIP' },
    { a: 'sess', t: 'Lihat sesi login' },
    'hr',
    { a: 'reset', t: 'Reset kata sandi', off: self && 'Gunakan Pengaturan Akun untuk akun Anda' },
    { a: 'trader', t: u.role === 'trader' ? 'Cabut akses trader' : 'Jadikan trader', off: self && 'Tidak bisa mengubah peran sendiri' },
    { a: 'role', t: u.role === 'admin' ? 'Jadikan member' : 'Jadikan admin', off: self && 'Tidak bisa mengubah peran sendiri' },
    'hr',
    { a: 'del', t: 'Hapus akun', danger: true, off: self && 'Tidak bisa menghapus akun sendiri' }
  ];
  menu.innerHTML = items.map(i => i === 'hr' ? '<hr role="separator">'
    : `<button type="button" role="menuitem" data-a="${i.a}" data-e="${esc(email)}" class="${i.danger ? 'danger' : ''}" ${i.off ? `disabled title="${esc(i.off)}"` : ''}>${esc(i.t)}</button>`).join('');
  menuBtn = btn; btn.setAttribute('aria-expanded', 'true');
  menu.hidden = false; placeMenu();
  const first = menu.querySelector('button:not(:disabled)'); if (first) first.focus();
}
$('#rows').addEventListener('click', e => { const b = e.target.closest('button[data-a="menu"]'); if (b) openMenu(b, b.closest('tr').dataset.e); });
menu.addEventListener('click', e => {
  const b = e.target.closest('button[data-a]'); if (!b || b.disabled) return;
  const a = b.dataset.a, email = b.dataset.e; closeMenu(); act(a, email);
});
menu.addEventListener('keydown', e => {
  const its = [...menu.querySelectorAll('button:not(:disabled)')], i = its.indexOf(document.activeElement);
  if (e.key === 'ArrowDown') { e.preventDefault(); its[(i + 1) % its.length].focus(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); its[(i - 1 + its.length) % its.length].focus(); }
  else if (e.key === 'Tab') closeMenu();
});
document.addEventListener('mousedown', e => { if (menuBtn && !menu.contains(e.target) && !menuBtn.contains(e.target)) closeMenu(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && menuBtn) closeMenu(true); });
addEventListener('scroll', placeMenu, true); addEventListener('resize', placeMenu);

async function act(a, email) {
  const u = window._users[email], nm = `<b>${esc(u.name)}</b> (${esc(email)})`;
  if (a === 'sess') return showSessions(email, u.name);
  if (a === 'vvip') return vvipDlg(email);
  if (a === 'reset') {
    if (!await confirmDlg({ title: 'Reset kata sandi?', body: `Kata sandi ${nm} akan diganti dengan sandi sementara, dan pengguna ini dikeluarkan dari semua perangkat.`, ok: 'Buat sandi sementara' })) return;
    const r = await api('/api/admin/reset', { email });
    if (!r.ok) return toast(r.error || 'Gagal reset.', true);
    openDlg(`<h2>Sandi sementara siap</h2><p>Berikan sandi ini kepada <b>${esc(u.name)}</b> lewat jalur yang aman. Sandi hanya tampil <b>sekali</b>, dan tidak tersimpan di mana pun. ${r.sessionsRevoked} sesi login dikeluarkan.</p>
      <div class="pwbox"><input id="pw" readonly value="${esc(r.password)}" aria-label="Sandi sementara"><button type="button" class="btn pill primary" id="cp">Salin</button></div>
      <p>Sarankan pengguna segera menggantinya di Pengaturan Akun setelah masuk.</p>
      <div class="dl-act"><button type="button" class="btn pill ghost" id="cl">Selesai</button></div>`);
    $('#pw').select();
    $('#cp').onclick = async () => { try { await navigator.clipboard.writeText(r.password); toast('Sandi disalin.'); } catch (e) { $('#pw').select(); toast('Salin manual: tekan Ctrl+C.', true); } };
    $('#cl').onclick = () => dlg.close();
    return refresh();
  }
  if (a === 'trader') {
    const to = u.role === 'trader' ? 'member' : 'trader';
    if (!await confirmDlg({ title: to === 'trader' ? 'Berikan akses trader?' : 'Cabut akses trader?', body: to === 'trader' ? `${nm} dapat mengirim perintah trading ke akun MT4 FOR-X. Pastikan orang ini benar-benar Anda percaya.` : `${nm} tidak lagi dapat mengirim perintah trading.`, ok: to === 'trader' ? 'Jadikan trader' : 'Cabut akses' , danger: to === 'member' })) return;
    const r = await api('/api/admin/role', { email, role: to });
    toast(r.ok ? 'Peran diperbarui.' : (r.error || 'Gagal.'), !r.ok); return refresh();
  }
  if (a === 'role') {
    const to = u.role === 'admin' ? 'member' : 'admin';
    if (!await confirmDlg({ title: to === 'admin' ? 'Jadikan admin?' : 'Turunkan menjadi member?', body: to === 'admin' ? `${nm} akan bisa membuka panel ini dan mengelola semua akun.` : `${nm} tidak lagi bisa membuka panel admin.`, ok: to === 'admin' ? 'Jadikan admin' : 'Turunkan', danger: to === 'admin' })) return;
    const r = await api('/api/admin/role', { email, role: to });
    toast(r.ok ? 'Peran diperbarui.' : (r.error || 'Gagal.'), !r.ok); return refresh();
  }
  if (a === 'del') {
    if (!await confirmDlg({ title: 'Hapus akun?', body: `Akun ${nm} dan semua sesinya akan dihapus <b>permanen</b>. Tindakan ini tidak bisa dibatalkan.`, ok: 'Hapus permanen', danger: true, expect: email, label: 'Ketik email pengguna untuk konfirmasi' })) return;
    const r = await api('/api/admin/delete', { email, confirm: email });
    toast(r.ok ? 'Akun dihapus.' : (r.error || 'Gagal.'), !r.ok); return refresh();
  }
}

/* ---------- aktivasi VVIP manual ---------- */
function vvipDlg(email) {
  const u = window._users[email], on = !!u.vvipActive, today = wibDay(Date.now());
  const base = on ? wibDay(Date.parse(u.vvipUntil)) : today;   // perpanjangan dihitung dari tanggal berakhir saat ini
  const status = on ? `VVIP aktif sampai <b>${fmtDay(u.vvipUntil)}</b> (${daysLeft(u.vvipUntil)} hari lagi).`
    : u.vvipUntil ? `VVIP berakhir pada <b>${fmtDay(u.vvipUntil)}</b>.` : 'Belum pernah VVIP.';
  openDlg(`<h2>${on ? 'Kelola VVIP' : 'Beri VVIP'}</h2>
    <p><b>${esc(u.name)}</b> (${esc(email)})<br>${status}</p>
    <label for="vd">${on ? 'Tanggal berakhir baru' : 'Tanggal berakhir'}</label>
    <input id="vd" type="date" min="${addDays(on ? base : today, 1)}" max="${addDays(today, 3650)}" value="${addDays(base, 30)}">
    <div class="vq" role="group" aria-label="Pilihan cepat">${[30, 90, 180, 365].map(n => `<button type="button" data-n="${n}">+${n} hari</button>`).join('')}</div>
    <p id="vh" class="vh"></p>
    <p class="dl-err" id="ve" hidden></p>
    <div class="dl-act">
      <button type="button" class="btn pill ghost" id="vNo">Batal</button>
      ${on ? '<button type="button" class="btn pill danger" id="vRev">Cabut VVIP</button>' : ''}
      <button type="button" class="btn pill primary" id="vOk">${on ? 'Perpanjang' : 'Aktifkan VVIP'}</button>
    </div>`);
  const inp = $('#vd'), err = $('#ve');
  const hint = () => { $('#vh').textContent = inp.value ? 'VVIP berlaku sampai ' + fmtDay(inp.value + 'T23:59:59+07:00') + ' pukul 23.59 WIB' + (on ? ' (dihitung dari tanggal berakhir saat ini).' : '.') : ''; };
  inp.oninput = hint; hint();
  dlgBody.querySelectorAll('.vq button').forEach(b => b.onclick = () => { inp.value = addDays(base, +b.dataset.n); err.hidden = true; hint(); });
  $('#vNo').onclick = () => dlg.close();
  $('#vOk').onclick = async () => {
    if (!inp.value) { err.textContent = 'Pilih tanggal berakhir dulu.'; err.hidden = false; return; }
    const btn = $('#vOk'); btn.disabled = true;
    const r = await api('/api/admin/vvip', { email, action: on ? 'extend' : 'grant', until: inp.value });
    if (!r.ok) { err.textContent = r.error || 'Gagal menyimpan.'; err.hidden = false; btn.disabled = false; return; }
    dlg.close(); toast(on ? 'VVIP diperpanjang.' : 'VVIP diaktifkan.'); refresh();
  };
  const rev = $('#vRev'); if (rev) rev.onclick = async () => {
    if (!await confirmDlg({ title: 'Cabut VVIP?', body: `VVIP milik <b>${esc(u.name)}</b> (${esc(email)}) dicabut sekarang juga, walau masa aktifnya belum habis.`, ok: 'Cabut VVIP', danger: true })) return;
    const r = await api('/api/admin/vvip', { email, action: 'revoke' });
    toast(r.ok ? 'VVIP dicabut.' : (r.error || 'Gagal.'), !r.ok); refresh();
  };
}

async function showSessions(email, name) {
  const r = await api('/api/admin/sessions?email=' + encodeURIComponent(email));
  if (!r.ok) return toast(r.error || 'Gagal memuat sesi.', true);
  const list = r.sessions;
  openDlg(`<h2>Sesi login</h2><p>${esc(name)} · ${esc(email)}</p>
    ${list.length ? `<ul class="ss">${list.map(s => `<li><span class="d">${esc(s.device || 'Perangkat tidak dikenal')}<span class="m">Masuk ${fmt(s.since)} · berlaku sampai ${fmtDay(s.until)}</span></span>${s.current ? '<span class="cur">Sesi Anda</span>' : `<button type="button" class="btn pill ghost sm" data-id="${esc(s.id)}">Cabut</button>`}</li>`).join('')}</ul>` : '<p>Tidak ada sesi aktif.</p>'}
    <div class="dl-act">${list.some(s => !s.current) ? '<button type="button" class="btn pill danger" id="all">Keluarkan dari semua perangkat</button>' : ''}<button type="button" class="btn pill ghost" id="cl">Tutup</button></div>`);
  $('#cl').onclick = () => dlg.close();
  dlgBody.querySelectorAll('button[data-id]').forEach(btn => btn.onclick = async () => {
    const x = await api('/api/admin/sessions/revoke', { email, id: btn.dataset.id });
    toast(x.ok ? 'Sesi dicabut.' : (x.error || 'Gagal.'), !x.ok); await showSessions(email, name); refresh();
  });
  const all = $('#all'); if (all) all.onclick = async () => {
    const x = await api('/api/admin/logout-all', { email });
    toast(x.ok ? `${x.revoked} sesi dikeluarkan.` : (x.error || 'Gagal.'), !x.ok); await showSessions(email, name); refresh();
  };
}

/* ---------- riwayat ---------- */
const ACT = { 'vvip-grant': 'Beri VVIP', 'vvip-extend': 'Perpanjang VVIP', 'vvip-revoke': 'Cabut VVIP', role: 'Ubah peran', reset: 'Reset kata sandi', delete: 'Hapus akun', 'logout-all': 'Keluarkan semua perangkat', revoke: 'Cabut sesi' };
async function loadLog() {
  const r = await api('/api/admin/log'); if (!r.ok) return toast(r.error || 'Gagal memuat riwayat.', true);
  $('#logRows').innerHTML = r.log.length ? r.log.map(l => {
    const ex = l.until ? ` → sampai ${fmtDay(l.until)}` : l.role ? ` → ${l.role === 'admin' ? 'Admin' : 'Member'}` : l.sessionsRevoked != null ? ` (${l.sessionsRevoked} sesi)` : '';
    return `<tr><td class="first" data-l="Waktu">${fmt(l.t)}</td><td data-l="Admin">${esc(l.admin)}</td><td data-l="Tindakan">${esc(ACT[l.action] || l.action)}${esc(ex)}</td><td data-l="Pengguna">${esc(l.target || '-')}</td><td data-l="IP">${esc(l.ip || '-')}</td></tr>`;
  }).join('') : '<tr><td class="empty" colspan="5">Belum ada tindakan tercatat.</td></tr>';
}

/* ---------- tab ---------- */
function tab(which) {
  const u = which === 'u';
  $('#tabU').setAttribute('aria-selected', u); $('#tabL').setAttribute('aria-selected', !u);
  $('#paneU').hidden = !u; $('#paneL').hidden = u; if (!u) loadLog();
}
$('#tabU').onclick = () => tab('u'); $('#tabL').onclick = () => tab('l');

/* ---------- mulai ---------- */
(async () => {
  const me = await api('/api/me');
  if (!me.ok || !me.user || me.user.role !== 'admin') {
    $('#gateMsg').textContent = me.status === 401 ? 'Silakan masuk dengan akun admin.' : 'Akun ini tidak memiliki akses admin.';
    $('#gate').hidden = false; return;
  }
  state.me = me.user; $('#who').textContent = 'Masuk sebagai ' + me.user.name + ' · ' + me.user.email;
  $('#app').hidden = false; refresh();
})();
