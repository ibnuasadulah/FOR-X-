/* Standalone logic for glosarium.html (theme, language, menu, login state) + glossary init */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let lang=store.get('lang')||'id';
const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',more:'Pelajari Selengkapnya',none:'Istilah tidak ditemukan.',close:'Tutup',ph:'Cari istilah…',glE:'KAMUS TRADING LENGKAP',glT:'Glosarium Trading',glI:'Kamus istilah trading forex, analisa teknikal, fundamental, hingga kripto dari A sampai Z untuk membantu kamu memahami pasar.'},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',more:'Learn More',none:'No terms found.',close:'Close',ph:'Search terms…',glE:'COMPLETE TRADING DICTIONARY',glT:'Trading Glossary',glI:'A to Z trading terms: forex, technical and fundamental analysis, and crypto. Click a card for the full explanation. (Definitions are in Indonesian.)'}};
const user=()=>{try{return JSON.parse(store.get('session'))}catch(e){return null}};
function renderAuth(){const s=user(),L=T[lang];
 $('#auth').innerHTML=s?`<a class="btn pill ghost" href="dashboard.html">${s.name.replace(/[<>&"]/g,'')}</a>`:`<a class="btn pill ghost" href="masuk.html">${L.login}</a> <a class="btn pill primary" href="masuk.html#daftar">${L.join} →</a>`}
function applyLang(){const L=T[lang];$$('[data-i]').forEach(e=>{if(L[e.dataset.i])e.textContent=L[e.dataset.i]});
 $('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;
 $('#gdC').textContent=L.close;renderAuth();renderGl()}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')||'dark');
$('#theme').onclick=()=>setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark');
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.onclick=e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')};
initGl();applyLang();
