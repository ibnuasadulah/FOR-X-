/* Single article page: reads ?a=<id>, renders article + related + share buttons */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let lang=store.get('lang')||'id';
const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',
 tMarket:'Analisa Market',tTips:'Tips Trading',tEdu:'Edukasi',author:'Tim Riset FOR-X',views:'kali dibaca',related:'Artikel Terkait',all:'Lihat Semua Artikel',share:'Bagikan Artikel Ini:',nf:'Artikel tidak ditemukan.',back:'Kembali ke Artikel',bc:'Navigasi'},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',
 tMarket:'Market Analysis',tTips:'Trading Tips',tEdu:'Education',author:'FOR-X Research Team',views:'views',related:'Related Articles',all:'View All Articles',share:'Share This Article:',nf:'Article not found.',back:'Back to Articles',bc:'Breadcrumb'}};
const CK={market:'tMarket',tips:'tTips',edu:'tEdu'};
const esc=s=>String(s).replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));
const ico={
 chev:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>',
 cal:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/></svg>',
 user:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.5-6 8-6s8 2 8 6"/></svg>',
 eye:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.600-7 10-7 10 7 10 7-3.600 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
 news:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 10h10M7 14h6"/></svg>',
 wa:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 21l1.700-5A9 9 0 1 1 8 19.300z"/><path d="M9 9.500c0 3 2.500 5.500 5.500 5.500l1-1.200-1.800-1-.8.800a4 4 0 0 1-2.100-2.100l.8-.8-1-1.800z"/></svg>',
 tg:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/></svg>',
 fb:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9.500"/><path d="M15 7.500h-1.500A1.800 1.800 0 0 0 11.700 9.300V22M9 13h6"/></svg>',
 x:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.244 2.250h3.308l-7.227 8.260 8.502 11.240H16.170l-5.214-6.817L4.990 21.750H1.680l7.730-8.835L1.254 2.250H8.080l4.713 6.231zm-1.161 17.520h1.833L7.084 4.126H5.117z"/></svg>'};
const id=new URLSearchParams(location.search).get('a');
const art=ART.find(a=>a.id===id);

function body(blocks){return blocks.map(b=>b[0]==='h'?`<h2>${esc(b[1])}</h2>`:b[0]==='ul'?`<ul>${b[1].map(i=>`<li>${esc(i)}</li>`).join('')}</ul>`:b[0]==='note'?`<p class="rd-note">${esc(b[1])}</p>`:`<p>${esc(b[1])}</p>`).join('')}
function render(){const t=T[lang];
 if(!art){document.title='FOR-X';$('#rdMain').innerHTML=`<div class="rd-nf"><p>${t.nf}</p><a class="btn pill primary" href="artikel.html">${t.back}</a></div>`;$('#rdSide').hidden=true;return}
 document.title=art.t+' | FOR-X';
 const url=encodeURIComponent(location.href),txt=encodeURIComponent(art.t);
 $('#rdMain').innerHTML=`
  <nav class="crumb" aria-label="${t.bc}"><a href="index.html#home">${t.home}</a>${ico.chev}<a href="artikel.html">${t.articles}</a>${ico.chev}<b aria-current="page">${esc(art.t)}</b></nav>
  <span class="badge">${t[CK[art.c]]}</span>
  <h1 class="rd-h1">${esc(art.t)}</h1>
  <div class="rd-meta"><span>${ico.cal}${art.date}</span><span>${ico.user}${t.author}</span><span>${ico.eye}${art.views} ${t.views}</span></div>
  <figure class="rd-cover"><img src="${art.img}" alt="${esc(art.t)}"></figure>
  <div class="rd-body">${body(art.body)}</div>
  <div class="rd-share"><h4>${t.share}</h4><div class="sh">
   <a class="wa" href="https://wa.me/?text=${txt}%20${url}" target="_blank" rel="noopener" aria-label="WhatsApp">${ico.wa}</a>
   <a class="tg" href="https://t.me/share/url?url=${url}&text=${txt}" target="_blank" rel="noopener" aria-label="Telegram">${ico.tg}</a>
   <a class="fb" href="https://www.facebook.com/sharer/sharer.php?u=${url}" target="_blank" rel="noopener" aria-label="Facebook">${ico.fb}</a>
   <a class="x" href="https://twitter.com/intent/tweet?url=${url}&text=${txt}" target="_blank" rel="noopener" aria-label="X">${ico.x}</a></div></div>`;
 const rel=ART.filter(a=>a.id!==art.id).sort((a,b)=>(b.c===art.c)-(a.c===art.c)).slice(0,3);
 $('#rdSide').hidden=false;
 $('#rdSide').innerHTML=`<h3>${ico.news}${t.related}</h3><div class="rel-list">${rel.map(a=>`<a class="rel" href="baca.html?a=${a.id}"><img src="${a.img}" alt="" loading="lazy"><span><b>${esc(a.t)}</b><small>${t[CK[a.c]]}</small></span></a>`).join('')}</div><a class="btn pill primary" href="artikel.html">${t.all}</a>`}
/* auth: shows login state from index.html */
const user=()=>{try{return JSON.parse(store.get('session'))}catch(e){return null}};
function renderAuth(){const s=user();
 $('#auth').innerHTML=s&&s.name?`<a class="btn pill ghost" href="dashboard.html">${esc(s.name)}</a>`:`<a class="btn pill ghost" href="masuk.html">${T[lang].login}</a> <a class="btn pill primary" href="masuk.html#daftar">${T[lang].join} →</a>`}
function applyLang(){const t=T[lang];$$('[data-i]').forEach(e=>{if(t[e.dataset.i])e.textContent=t[e.dataset.i]});$('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;renderAuth();render()}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')||'dark');
function switchTheme(){const d=document.documentElement,n=d.dataset.theme==='dark'?'light':'dark';
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){setTheme(n);return}
 if(document.startViewTransition){document.startViewTransition(()=>setTheme(n));return}
 d.classList.add('theme-anim');setTheme(n);setTimeout(()=>d.classList.remove('theme-anim'),500)}
$('#theme').onclick=switchTheme;
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.onclick=e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')};
applyLang();
