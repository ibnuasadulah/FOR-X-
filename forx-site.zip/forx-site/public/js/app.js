const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let lang=store.get('lang')||'id';
const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',out:'Keluar',h1a:'Masa Depan Dimulai dari Langkah Berani.',h1b:'Jadilah Bagian dari',s1:'Master copy trade',s2:'Follower copy trade',more:'Pelajari Selengkapnya',none:'Istilah tidak ditemukan.',close:'Tutup',ph:'Cari istilah…',glI:'Kamus istilah trading dari A sampai Z. Klik kartu untuk membaca penjelasan lengkap.',h1p:'Belajar, berdiskusi, dan berkembang bersama komunitas trader yang saling mendukung.',cta1:'Mulai bersama kami',cta2:'Pelajari lebih lanjut',inst:'Instrumen trading',aboutT:'Trading lebih terarah',aboutP:'FOR-X adalah platform edukasi dan komunitas. Kami membahas analisa teknikal, fundamental, dan manajemen risiko agar kamu bisa mengambil keputusan sendiri.',artT:'Artikel terbaru',allArt:'Lihat semua artikel',sigP:'Rekomendasi harian dengan level entry, TP, dan SL.',getSig:'Dapatkan sinyal',toolP:'Indikator dan Expert Advisor untuk MT5.',expl:'Jelajahi tools',testiT:'Testimoni',testiN:'Contoh teks. Ganti dengan testimoni asli dan izin dari member.',ask:'Hubungi support',abBadge:'Tentang FOR-X',abH1:'Trading Lebih Terarah',abH2:'Bersama',abSub:'Platform edukasi, analisis data real-time, dan komunitas trader modern Indonesia.',abP:'FOR-X hadir untuk merevolusi cara trader Indonesia memandang pasar keuangan global. Kami menggabungkan analisa teknikal presisi, fundamental makroekonomi, manajemen risiko terukur, dan teknologi indikator mutakhir agar setiap trader mampu mengambil keputusan secara mandiri, rasional, dan konsisten mendulang profit di pasar Forex & Crypto.',abB1:'Akses Fitur VVIP',abB2:'Kamus Istilah Trading',abCta:'Lihat Penawaran VVIP',arBadge:'Wawasan & Edukasi',arT1:'Artikel',arT2:'Terbaru.',arSub:'Perdalam wawasan trading Anda dengan analisa terkini, psikologi pasar, dan materi edukasi pilihan.',allArt:'Lihat Semua Artikel',sgEy:'Live Signal VIP',sgH:'Sinyal Akurat Setiap Hari.',sgP:'Dapatkan rekomendasi posisi harian dari tim analis FOR-X dengan kalkulasi rasio Risk-Reward terukur, titik entry presisi, serta proteksi Stop Loss yang rasional.',sgBtn:'Dapatkan Sinyal',sgSt:'Update Harian',ixEy:'Tool Custom FOR-X',ixH:'Indikator Eksklusif FOR-X.',ixP:'Gunakan indikator kustom algoritma FOR-X untuk membaca arah tren, konfirmasi momentum, serta titik pembalikan harga langsung di platform charting Anda.',ixBtn:'Jelajahi Tools',ixSt:'Tingkat Akurasi Tinggi',bpBadge:'Broker Partnership',bpT1:'Special Trading',bpT2:'Fee.',bpP:'Dapatkan special trading fee di berbagai broker rekomendasi kami yang sudah teregulasi. Hemat biaya spread dan nikmati rebate kompetitif di setiap lot transaksi Anda.',bpQ:'“Mantap, proses deposit dan withdraw di broker-broker rekomendasi FOR-X super lancar dan spread sangat tipis.”',bpBy:'- Sarki (Trader FOR-X)',bpBtn:'Buka Akun Rekomendasi',bpNote:'Broker Legal & Teregulasi',tsBadge:'Bukti Kepuasan Member',tsT1:'Testimoni',tsT2:'Member',tsSub:'Ribuan trader telah merasakan kemudahan navigasi pasar bersama kami.',tsBtn:'Lihat Membership',tsRole:'Member For-X',fqBadge:'Pertanyaan Umum',fqT1:'Frequently Asked',fqT2:'Questions.',fqSub:'Jawaban atas pertanyaan yang paling sering diajukan mengenai ekosistem dan fasilitas FOR-X.',fqAsk:'Masih memiliki pertanyaan lain yang belum terjawab?',fqBtn:'Hubungi Tim Support FOR-X'},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',out:'Log out',h1a:'The Future Starts with a Bold Step.',h1b:'Be Part of',s1:'Master copy trade',s2:'Follower copy trade',more:'Learn More',none:'No terms found.',close:'Close',ph:'Search terms…',glI:'A trading glossary from A to Z. Click a card to read the full explanation. (Definitions are in Indonesian.)',h1p:'Learn, discuss, and grow with a supportive community of traders.',cta1:'Get started',cta2:'Learn more',inst:'Trading instruments',aboutT:'Trade with more direction',aboutP:'FOR-X is an education and community platform. We cover technical analysis, fundamentals, and risk management so you can make your own decisions.',artT:'Latest articles',allArt:'View all articles',sigP:'Daily recommendations with entry, TP, and SL levels.',getSig:'Get signals',toolP:'Indicators and Expert Advisors for MT5.',expl:'Explore tools',testiT:'Testimonials',testiN:'Sample text. Replace with real testimonials and member permission.',ask:'Contact support',abBadge:'About FOR-X',abH1:'Trade with More Direction',abH2:'Together with',abSub:'An education platform, real-time data analysis, and a modern trader community in Indonesia.',abP:'FOR-X is here to change how Indonesian traders see the global financial markets. We combine precise technical analysis, macroeconomic fundamentals, measured risk management, and modern indicator technology so every trader can make independent, rational, and consistent decisions in the Forex & Crypto markets.',abB1:'Access VVIP Features',abB2:'Trading Glossary',abCta:'View VVIP Offers',arBadge:'Insights & Education',arT1:'Latest',arT2:'Articles.',arSub:'Deepen your trading insight with fresh analysis, market psychology, and curated learning material.',allArt:'View All Articles',sgEy:'Live VIP Signals',sgH:'Accurate Signals Every Day.',sgP:'Get daily position recommendations from the FOR-X analyst team, with measured risk-reward ratios, precise entry points, and rational Stop Loss protection.',sgBtn:'Get Signals',sgSt:'Updated Daily',ixEy:'FOR-X Custom Tool',ixH:'Exclusive FOR-X Indicators.',ixP:'Use FOR-X algorithm-based custom indicators to read trend direction, confirm momentum, and spot price reversals right on your charting platform.',ixBtn:'Explore Tools',ixSt:'High Accuracy Level',bpBadge:'Broker Partnership',bpT1:'Special Trading',bpT2:'Fee.',bpP:'Get special trading fees at our recommended regulated brokers. Save on spread costs and enjoy competitive rebates on every lot you trade.',bpQ:'“Great, deposits and withdrawals at FOR-X recommended brokers are super smooth and the spreads are very tight.”',bpBy:'- Sarki (FOR-X Trader)',bpBtn:'Open Recommended Account',bpNote:'Legal & Regulated Brokers',tsBadge:'Member Satisfaction',tsT1:'Testimonials',tsT2:'Members',tsSub:'Thousands of traders have found navigating the markets easier with us.',tsBtn:'View Membership',tsRole:'FOR-X Member',fqBadge:'Common Questions',fqT1:'Frequently Asked',fqT2:'Questions.',fqSub:'Answers to the questions we get asked most about the FOR-X ecosystem and facilities.',fqAsk:'Still have questions we haven\'t answered?',fqBtn:'Contact FOR-X Support'}};
const D={
feat:[['<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H4v1a3 3 0 0 0 3 3M17 6h3v1a3 3 0 0 1-3 3"/>','Komunitas Trading Nomor 1','Ekosistem trader aktif terbesar di Indonesia yang saling berbagi insight dan saling mendukung.'],['<path d="M22 10 12 5 2 10l10 5zM6 12v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5"/>','Edukasi Trading Forex dari Ahlinya','Kurikulum komprehensif mulai dari dasar hingga strategi lanjutan dipandu master trader.'],['<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>','Signal Trading Akurat','Setup posisi harian dengan level entry, TP, dan SL yang diperhitungkan secara presisi.'],['<path d="M19 5 5 19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>','Special Trading Fee','Spread super ketat dan potongan komisi spesial dari broker-broker mitra resmi.'],['<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 3v4M12 17v4M3 12h4M17 12h4"/>','Indikator Eksklusif','Indikator kustom tingkat dewa yang dirancang untuk mendeteksi momentum dan tren pasar.'],['<circle cx="12" cy="8" r="3"/><circle cx="5" cy="10" r="2"/><circle cx="19" cy="10" r="2"/><path d="M6 20c0-4 3-6 6-6s6 2 6 6"/>','Copy Trade Circle','Hubungkan akun Anda dengan Master handal atau bangun basis follower Anda sendiri.'],['<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18"/>','IB Training','Pelatihan khusus Introducer Broker (IB) untuk membangun karier dan passive income berkelanjutan di industri finansial global.']],
art:[['XAUUSD: Potensi Breakout Menuju All Time High?','Analisa Market','Analisa teknikal gold hari ini dengan peluang breakout di area supply utama.','11 Oct 2026','assets/article-1.png'],['5 Kesalahan Fatal Trader Pemula','Tips Trading','Hindari kesalahan umum yang sering dilakukan pemula agar tidak kehilangan modal.','10 Oct 2026','assets/article-2.png'],['Cara Menggunakan Indikator RSI dengan Benar','Edukasi','Panduan lengkap membaca RSI untuk mendapatkan entry yang lebih akurat.','09 Oct 2026','assets/article-3.png'],['Prediksi Rilis NFP Jumat Ini','Analisa Market','Dampak data tenaga kerja AS terhadap pasangan mata uang mayor.','08 Oct 2026','assets/article-4.png']],
testi:[['Angel','"Ilmunya luar biasa, dari saya gak ngerti sama sekali sampai bisa jadi mahir."'],['King','"Setelah gabung, saya berhasil merubah uang 1 juta menjadi 31 juta setelah gabung disini."'],['Dewi','"Suami saya sampai bingung saya dapat uang dari mana hahaha."'],['Agung','"Awalnya iseng gabung karena murah, ternyata ilmunya keren, orangnya juga keren-keren."'],['Irfan','"Dulu awalnya ragu, sekarang bersyukur bisa gabung disini."'],['Farhan','"Dulu buat makan aja susah, sekarang bisa bahagiakan orang tua."']],
faq:[['Apakah pemula yang belum pernah trading bisa bergabung di FOR-X?','Bisa. Materi dimulai dari dasar seperti pips, lot, dan leverage.'],['Bagaimana cara mendapatkan sinyal trading harian?','Lewat channel privat dan dashboard member.'],['Apakah indikator eksklusif FOR-X bisa dipakai di MetaTrader 5 (MT5)?','Ya, tools dibuat untuk MetaTrader 5.'],['Apakah ada jaminan pasti profit di setiap trading?','Tidak. Trading berisiko dan hasil tidak dijamin.'],['Bagaimana cara mendaftar program IB Training?','Isi formulir di halaman IB Training.']],
plans:[['Basic','Gratis','Akses komunitas dan artikel'],['VVIP','Rp 0 (contoh)','Sinyal harian dan mentoring'],['Partner IB','Hubungi kami','Pelatihan dan pendampingan']],
tools:[['Expert Advisor','Contoh EA untuk MT5'],['Indikator tren','Contoh indikator custom'],['Kalkulator lot','Lihat di bawah']]
};
const card=(h,p,s)=>`<div class="card">${s?`<small>${s}</small>`:''}<h3>${h}</h3><p>${p}</p></div>`;
$('#features').innerHTML=D.feat.map(f=>`<div class="fcard"><i class="fic"><svg viewBox="0 0 24 24" aria-hidden="true">${f[0]}</svg></i><h3>${f[1]}</h3><p>${f[2]}</p></div>`).join('');
const cal='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/></svg>',arr='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
let AID=['xauusd-breakout-ath','kesalahan-fatal-trader-pemula','indikator-rsi','rilis-nfp'];
const eh=x=>String(x).replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));
let aI=0;const aCard=a=>`<a class="acard" href="baca.html?a=${encodeURIComponent(AID[(aI++)%AID.length])}"><div class="athumb"><img src="${eh(a[4])}" alt="" loading="lazy"><span class="achip">${eh(a[1])}</span></div><div class="abody"><h3>${eh(a[0])}</h3><p>${eh(a[2])}</p><div class="ameta"><span>${cal} ${eh(a[3])}</span><b>Baca ${arr}</b></div></div></a>`;
function renderHomeArt(){aI=0;$('#homeArt').innerHTML=D.art.map(aCard).join('');aI=0;$('#allArtList').innerHTML=D.art.map(aCard).join('')}
renderHomeArt();
API.articles().then(r=>{if(!r.ok||!r.articles.length)return;const L={market:'Analisa Market',tips:'Tips Trading',edu:'Edukasi'},list=r.articles.slice(0,4);
 D.art=list.map(a=>[a.t,L[a.c],a.d,a.date,a.img]);AID=list.map(a=>a.id);renderHomeArt()});
$('#testi').innerHTML=D.testi.map(t=>`<figure class="tcard"><div class="tstars" role="img" aria-label="5 dari 5"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z"/></svg><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z"/></svg><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z"/></svg><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z"/></svg><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z"/></svg></div><blockquote>${t[1]}</blockquote><figcaption><i class="tav">${t[0][0]}</i><span><b>${t[0]}</b><small data-i="tsRole">Member For-X</small></span></figcaption></figure>`).join('');
$('#faq').innerHTML=D.faq.map(f=>`<details><summary><span>${f[0]}</span><i class="fq-ic"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></i></summary><p>${f[1]}</p></details>`).join('');
$('#plans').innerHTML=D.plans.map(p=>`<div class="card"><h3>${p[0]}</h3><p><b>${p[1]}</b></p><p>${p[2]}</p><p><a class="btn primary" href="masuk.html#daftar">Gabung</a></p></div>`).join('');
$('#toolList').innerHTML=D.tools.map(t=>card(t[0],t[1])).join('');
function lot(){const b=+$('#bal').value,r=+$('#rk').value,s=+$('#sl').value;$('#lot').textContent='Lot: '+(s>0?(b*r/100/(s*10)).toFixed(2):'0.00')}
['#bal','#rk','#sl'].forEach(i=>$(i).oninput=lot);lot();

/* i18n */
function applyLang(){const t=T[lang];$$('[data-i]').forEach(e=>{if(t[e.dataset.i])e.textContent=t[e.dataset.i]});$('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;renderAuth()}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
/* theme */
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')||'dark');
/* theme switch with smooth cross-fade (colors unchanged) */
function switchTheme(){const d=document.documentElement,n=d.dataset.theme==='dark'?'light':'dark';
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){setTheme(n);return}
 if(document.startViewTransition){document.startViewTransition(()=>setTheme(n));return}
 d.classList.add('theme-anim');setTheme(n);setTimeout(()=>d.classList.remove('theme-anim'),500)}
$('#theme').onclick=switchTheme;
/* menu */
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.onclick=e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')};
/* router */
const pages=['home','about','vvip','ib','articles','tools','contact','login','account'];
function route(){let h=(location.hash||'#home').slice(1);if(h==='ib'){location.replace('ib.html');return}
 if(!pages.includes(h))h='home';
 if(h==='account'&&!user()){location.replace('masuk.html');return}
 $$('.page').forEach(p=>p.classList.toggle('on',p.id==='p-'+h));
 $('#dd').classList.remove('open');$('#links').classList.remove('show');
 if(h==='account')renderAccount();window.scrollTo(0,0)}
addEventListener('hashchange',route);
/* auth (backend /api) */
const user=()=>API.user();
function renderAuth(){const s=user();
 $('#auth').innerHTML=s?`<a class="btn pill ghost" href="dashboard.html">${s.name.replace(/[<>&"]/g,'')}</a>`:`<a class="btn pill ghost" href="masuk.html">${T[lang].login}</a> <a class="btn pill primary" href="masuk.html#daftar">${T[lang].join} →</a>`}
function renderAccount(){const s=user();if(!s)return;$('#acT').textContent='Halo, '+s.name;
 const box=$('#acB');box.replaceChildren();
 const row=(k,v)=>{const p=document.createElement('p'),b=document.createElement('b');b.textContent=k+': ';p.append(b,document.createTextNode(v));box.append(p)};
 row('Email',s.email);
 if(s.referral_code)row('Kode referal',s.referral_code);
 row('Keanggotaan',s.vvip_active?'VVIP aktif sampai '+new Date(s.vvip_until).toLocaleDateString('id-ID',{day:'2-digit',month:'long',year:'numeric'}):'Belum VVIP');
 const a=document.createElement('a');a.className='btn pill primary';a.href='vvip.html';a.textContent=s.vvip_active?'Perpanjang VVIP':'Gabung VVIP';box.append(a);
 if(s.role==='admin'){const d=document.createElement('a');d.className='btn pill ghost';d.href='admin.html';d.textContent='Dashboard Admin';d.style.marginLeft='8px';box.append(d)}}
$('#out').onclick=async()=>{await API.logout();renderAuth();location.hash='#home'};
/* form kontak -> /api/contact */
const cf=$('#contactForm');
if(cf)cf.onsubmit=async e=>{e.preventDefault();const m=$('#cm'),btn=$('#cSend');
 const say2=(c,t)=>{const d=document.createElement('div');d.className='msg '+c;d.textContent=t;m.replaceChildren(d)};
 const data={name:$('#cn').value.trim(),email:$('#ce').value.trim(),topic:$('#ct').value,message:$('#cx').value.trim(),website:$('#cw').value};
 if(data.name.length<2)return say2('err','Nama wajib diisi.');
 if(!/^\S+@\S+\.\S+$/.test(data.email))return say2('err','Masukkan email yang valid.');
 if(data.message.length<10)return say2('err','Pesan minimal 10 karakter.');
 btn.disabled=true;const r=await API.contact(data);btn.disabled=false;
 if(!r.ok)return say2('err',r.error);
 e.target.reset();say2('ok','Terima kasih! Pesanmu sudah kami terima dan akan segera dibalas.')};

applyLang();route();

/* hero typing */
(function(){
  const tw = $('#typed'), w = 'FOR-X';
  if (!tw || matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  let n = 0, d = 1;
  (function tick() {
    tw.textContent = w.slice(0, n);
    let t = d > 0 ? 110 : 55;
    if (d > 0 && n === w.length) { d = -1; t = 2000; } // pauses 3 seconds after typing
    else if (d < 0 && n === 0) { d = 1; t = 500; }
    n += d;
    setTimeout(tick, t);
  })();
})();