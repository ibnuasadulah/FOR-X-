const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let lang=store.get('lang')||'id',cat='all';
const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',
 arBadge:'Pusat Literasi & Wawasan',arH1:'Artikel &',arH2:'Edukasi',arSub:'Perdalam wawasan trading Anda dengan analisis terkini, tips psikologi, dan materi edukasi pilihan dari tim riset profesional FOR-X.',arGo:'Cari',ph:'Cari artikel, topik, strategi...',tAll:'Semua Topik',tMarket:'Analisa Market',tTips:'Tips Trading',tEdu:'Edukasi',more:'Baca Selengkapnya',arNone:'Artikel tidak ditemukan.'},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',
 arBadge:'Literacy & Insight Hub',arH1:'Articles &',arH2:'Education',arSub:'Deepen your trading insight with fresh analysis, psychology tips, and curated learning material from the FOR-X research team.',arGo:'Search',ph:'Search articles, topics, strategies...',tAll:'All Topics',tMarket:'Market Analysis',tTips:'Trading Tips',tEdu:'Education',more:'Read More',arNone:'No articles found.'}
};
const CK={market:'tMarket',tips:'tTips',edu:'tEdu'};
const cal='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/></svg>',arr='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
const esc=s=>String(s).replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));
function renderArt(){const t=T[lang],q=$('#artQ').value.trim().toLowerCase();
 const list=ART.filter(a=>(cat==='all'||a.c===cat)&&(!q||(a.t+' '+a.d+' '+t[CK[a.c]]).toLowerCase().includes(q)));
 $('#artGrid').innerHTML=list.map(a=>`<a class="acard" href="baca.html?a=${a.id}"><div class="athumb"><img src="${a.img}" alt="" loading="lazy"><span class="achip">${t[CK[a.c]]}</span></div><div class="abody"><h3>${esc(a.t)}</h3><p>${esc(a.d)}</p><div class="ameta"><span>${cal} ${a.date}</span><b>${t.more} ${arr}</b></div></div></a>`).join('');
 $('#artNone').hidden=list.length>0}
$('#artForm').onsubmit=e=>{e.preventDefault();renderArt()};
$('#artQ').oninput=renderArt;
$$('#artChips .chip').forEach(b=>b.onclick=()=>{cat=b.dataset.f;$$('#artChips .chip').forEach(x=>x.setAttribute('aria-pressed',x===b));renderArt()});
/* auth: hanya menampilkan status login dari index.html */
const user=()=>{try{return JSON.parse(store.get('session'))}catch(e){return null}};
function renderAuth(){const s=user();
 $('#auth').innerHTML=s&&s.name?`<a class="btn pill ghost" href="dashboard.html">${esc(s.name)}</a>`:`<a class="btn pill ghost" href="masuk.html">${T[lang].login}</a> <a class="btn pill primary" href="masuk.html#daftar">${T[lang].join} →</a>`}
/* i18n */
function applyLang(){const t=T[lang];$$('[data-i]').forEach(e=>{if(t[e.dataset.i])e.textContent=t[e.dataset.i]});$('#artQ').placeholder=t.ph;$('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;renderAuth();renderArt()}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
/* theme */
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')||'dark');
/* theme switch with smooth cross-fade (colors unchanged) */
function switchTheme(){const d=document.documentElement,n=d.dataset.theme==='dark'?'light':'dark';
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){setTheme(n);return}
 if(document.startViewTransition){document.startViewTransition(()=>setTheme(n));return}
 d.classList.add('theme-anim');setTheme(n);setTimeout(()=>d.classList.remove('theme-anim'),500)}
$('#theme').onclick=switchTheme;
/* menu */
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.onclick=e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')};
applyLang();
