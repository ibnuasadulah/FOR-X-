/* Kalender Ekonomi FOR-X: data feed Fair Economy (pemilik Metals Mine) lewat server sendiri (/api/calendar).
   Memakai helper dari dashboard.js: $, esc. Dipakai di kartu kecil (Dashboard) dan halaman Kalender Ekonomi. */
(()=>{
let data=null,loading=null,minImp=2,cur='';
const IMP={High:3,Medium:2,Low:1};
const tz={timeZone:'Asia/Jakarta'};
const tFmt=d=>d.toLocaleTimeString('id-ID',{...tz,hour:'2-digit',minute:'2-digit',hour12:false}).replace(':','.');
const dFmt=d=>d.toLocaleDateString('id-ID',{...tz,weekday:'long',day:'numeric',month:'long'});
const dayKey=d=>d.toLocaleDateString('en-CA',tz);

function load(force){
 if(data&&!force&&Date.now()-data.fetched<6e5)return Promise.resolve(data);
 if(loading)return loading;
 loading=fetch('/api/calendar',{credentials:'same-origin'}).then(r=>r.json()).then(j=>{
  if(!j.ok)throw new Error(j.error||'gagal');
  data={fetched:Date.now(),items:j.items.map(e=>({...e,t:new Date(e.date),i:IMP[e.impact]||0})).filter(e=>!isNaN(e.t)).sort((a,b)=>a.t-b.t)};return data})
 .finally(()=>{loading=null});
 return loading}

const row=(e,full)=>{const past=e.t<Date.now()-36e5;
 return `<div class="cr${past?' past':''}"><span class="ct">${full?'':e.t.toLocaleDateString('id-ID',{...tz,weekday:'short'})+' '}${tFmt(e.t)}</span><span class="cc">${esc(e.country)}</span><i class="ci i${e.i}" title="${esc(e.impact)}"></i><span class="cn">${esc(e.title)}</span>${full?`<span class="cf">${esc(e.forecast)||'-'}</span><span class="cp">${esc(e.previous)||'-'}</span>`:''}</div>`};
const msg=(t,retry)=>`<p class="empty">${t}${retry?' <button type="button" class="btn ghost sm" data-retry>Coba lagi</button>':''}</p>`;

function paint(){
 const sm=$('#calSmall'),bg=$('#calBig');if(!data)return;
 if(sm&&sm.offsetParent!==null){const up=data.items.filter(e=>e.i>=2&&e.t>=Date.now()-36e5).slice(0,6);
  sm.innerHTML=up.length?up.map(e=>row(e,false)).join(''):msg('Tidak ada rilis penting tersisa minggu ini.')}
 if(bg&&bg.offsetParent!==null){
  const sel=$('#calCur');if(sel&&!sel.options.length){const cs=[...new Set(data.items.filter(e=>e.i>0).map(e=>e.country))].sort();sel.innerHTML='<option value="">Semua mata uang</option>'+cs.map(c=>`<option>${esc(c)}</option>`).join('');sel.value=cur}
  const list=data.items.filter(e=>(minImp===1?e.i>=1:e.i>=minImp)&&(!cur||e.country===cur));
  if(!list.length){bg.innerHTML=msg('Tidak ada event untuk filter ini.');return}
  let html='<div class="cr ch-h"><span class="ct">Waktu</span><span class="cc">Mata uang</span><i></i><span class="cn">Event</span><span class="cf">Forecast</span><span class="cp">Previous</span></div>',day='';
  list.forEach(e=>{const k=dayKey(e.t);if(k!==day){day=k;html+=`<div class="cd">${esc(dFmt(e.t))}</div>`}html+=row(e,true)});
  bg.innerHTML=html}}

function show(){const box=[$('#calSmall'),$('#calBig')].filter(x=>x&&x.offsetParent!==null);if(!box.length)return;
 if(!data)box.forEach(b=>b.innerHTML=msg('Memuat kalender…'));
 load().then(paint).catch(()=>box.forEach(b=>b.innerHTML=msg('Kalender belum bisa dimuat.',true)))}

window.calInit=show;
document.addEventListener('click',e=>{if(e.target.closest('[data-retry]')){data=null;show()}});
document.addEventListener('change',e=>{if(e.target.id==='calCur'){cur=e.target.value;paint()}});
document.addEventListener('click',e=>{const b=e.target.closest('#calImp button');if(!b)return;minImp=+b.dataset.i;$$('#calImp button').forEach(x=>x.classList.toggle('on',x===b));paint()});
setInterval(()=>{if(data&&Date.now()-data.fetched>18e5)show()},6e4);
show();
})();
