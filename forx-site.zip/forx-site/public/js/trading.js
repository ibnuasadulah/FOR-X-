/* Chart & Trading FOR-X.
   Tab 1: chart pasar asli (widget TradingView), hanya untuk analisa.
   Tab 2: akun DEMO. Harga disimulasikan di browser (bukan harga pasar), jadi aman untuk latihan Buy/Sell.
   Memakai helper dari dashboard.js: $, $$, store, esc, money, toast, UID, KJ, load, save. */
(()=>{
const SYM={
 XAUUSD:{p:2650,d:2,pip:.1,c:100,q:1,sp:3,v:1.2,tv:'FOREXCOM:XAUUSD'},
 EURUSD:{p:1.0850,d:5,pip:1e-4,c:1e5,q:1,sp:1.2,v:.35,tv:'FX:EURUSD'},
 GBPUSD:{p:1.2700,d:5,pip:1e-4,c:1e5,q:1,sp:1.5,v:.45,tv:'FX:GBPUSD'},
 USDJPY:{p:150.20,d:3,pip:.01,c:1e5,q:0,sp:1.4,v:.4,tv:'FX:USDJPY'},
 AUDUSD:{p:.6550,d:5,pip:1e-4,c:1e5,q:1,sp:1.4,v:.3,tv:'FX:AUDUSD'},
 USDCAD:{p:1.3650,d:5,pip:1e-4,c:1e5,q:0,sp:1.6,v:.35,tv:'FX:USDCAD'}};
const KD='demo:'+UID,START=10000;
let D;try{D=JSON.parse(store.get(KD))}catch(e){}
if(!D||typeof D!=='object')D={};
D.bal=isFinite(D.bal)?D.bal:START;D.pos=Array.isArray(D.pos)?D.pos:[];D.hist=Array.isArray(D.hist)?D.hist:[];D.px=D.px||{};
Object.keys(SYM).forEach(k=>{if(!(D.px[k]>0))D.px[k]=SYM[k].p});
const persist=()=>store.set(KD,JSON.stringify(D));
const fmt=(s,v)=>v.toFixed(SYM[s].d);
const bid=s=>D.px[s]-SYM[s].sp*SYM[s].pip/2,ask=s=>D.px[s]+SYM[s].sp*SYM[s].pip/2;
const plOf=(o,price)=>{const m=SYM[o.s];return (o.side==='BUY'?price-o.e:o.e-price)*o.l*m.c/(m.q?1:D.px[o.s])};
const floatPl=o=>plOf(o,o.side==='BUY'?bid(o.s):ask(o.s));
let sym='XAUUSD',tf=60,chart=null,series=null,candles=[],lines=[],tvTheme='',inited=false,timer=0;

/* ---------- tab ---------- */
function tab(t){$$('#trTabs button').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));
 $('#trTv').hidden=t!=='tv';$('#trDemo').hidden=t!=='demo';$('#trMt4').hidden=t!=='mt4';$('#trPosCard').hidden=t==='mt4';$('#trHistCard').hidden=t==='mt4';
 if(t==='tv')tvChart();else if(t==='demo'){startChart();renderAll()}else if(t==='mt4'){loadMT4Status();}}

/* ---------- chart TradingView (harga asli) ---------- */
function tvChart(){const box=$('#trTv .tvc'),th=document.documentElement.dataset.theme;if(tvTheme===th)return;tvTheme=th;box.innerHTML='';
 const w=document.createElement('div');w.className='tradingview-widget-container';w.style.cssText='height:100%;width:100%';
 const s=document.createElement('script');s.src='https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';s.async=true;
 s.text=JSON.stringify({autosize:true,symbol:'FOREXCOM:XAUUSD',interval:'15',timezone:'Asia/Jakarta',theme:th,style:'1',locale:'id',allow_symbol_change:true,hide_side_toolbar:false,save_image:true,support_host:'https://www.tradingview.com'});
 w.appendChild(s);box.appendChild(w)}

/* ---------- chart demo (candlestick) ---------- */
function loadLib(){return window.LightweightCharts?Promise.resolve():new Promise((ok,no)=>{const s=document.createElement('script');
 s.src='https://cdn.jsdelivr.net/npm/lightweight-charts@4.2.1/dist/lightweight-charts.standalone.production.js';s.onload=ok;s.onerror=no;document.head.appendChild(s)})}
const css=v=>getComputedStyle(document.documentElement).getPropertyValue(v).trim();
function themeOpts(){return{layout:{background:{type:'solid',color:'transparent'},textColor:css('--mut')},grid:{vertLines:{color:css('--line')},horzLines:{color:css('--line')}},rightPriceScale:{borderColor:css('--line')},timeScale:{borderColor:css('--line'),timeVisible:true,secondsVisible:false}}}
window.trTheme=()=>{if(chart)chart.applyOptions(themeOpts());if(series)series.applyOptions({upColor:css('--brand'),downColor:css('--bad'),wickUpColor:css('--brand'),wickDownColor:css('--bad'),borderVisible:false});
 tvTheme='';if(!$('#trTv').hidden&&!$('#v-trading').hidden)tvChart()};
function seed(){const m=SYM[sym],n=150,now=Math.floor(Date.now()/1e3/tf)*tf,sig=m.v*m.pip*Math.sqrt(tf),arr=[];let p=D.px[sym];
 for(let i=0;i<n;i++){const o=p;let h=o,l=o,c=o;for(let k=0;k<8;k++){c+=(Math.random()-.5)*2*sig/2.2;h=Math.max(h,c);l=Math.min(l,c)}arr.push({time:now-(n-i)*tf,open:o,high:h,low:l,close:c});p=c}
 const sh=D.px[sym]-arr[n-1].close;arr.forEach(x=>{x.open+=sh;x.high+=sh;x.low+=sh;x.close+=sh});candles=arr;series.setData(candles);chart.timeScale().fitContent();drawLines()}
function startChart(){if(chart){chart.resize($('#trChart').clientWidth,$('#trChart').clientHeight);return}
 loadLib().then(()=>{if(chart)return;chart=LightweightCharts.createChart($('#trChart'),{autoSize:true,crosshair:{mode:LightweightCharts.CrosshairMode.Normal},...themeOpts()});series=chart.addCandlestickSeries();trTheme();seed()})
 .catch(()=>{$('#trChart').innerHTML='<p class="empty">Chart gagal dimuat. Periksa koneksi internet lalu muat ulang halaman.</p>'})}
function drawLines(){if(!series)return;lines.forEach(l=>series.removePriceLine(l));lines=[];
 D.pos.filter(o=>o.s===sym).forEach(o=>{const add=(price,t,col,st)=>price&&lines.push(series.createPriceLine({price,color:col,lineWidth:1,lineStyle:st,axisLabelVisible:true,title:t}));
  add(o.e,o.side+' '+o.l,o.side==='BUY'?css('--brand'):css('--bad'),0);add(o.sl,'SL',css('--bad'),2);add(o.tp,'TP',css('--brand'),2)})}

/* ---------- harga bergerak ---------- */
function ticks(){const now=Math.floor(Date.now()/1e3);
 Object.keys(SYM).forEach(k=>{const m=SYM[k];D.px[k]=Math.max(m.pip*10,D.px[k]+(Math.random()-.5)*2*m.v*m.pip)});
 if(series&&candles.length){const t=Math.floor(now/tf)*tf,px=D.px[sym];let c=candles[candles.length-1];
  if(t>c.time){c={time:t,open:c.close,high:px,low:px,close:px};candles.push(c)}else{c.high=Math.max(c.high,px);c.low=Math.min(c.low,px);c.close=px}
  series.update(c)}
 let closed=false;
 D.pos.slice().forEach(o=>{const b=bid(o.s),a=ask(o.s),buy=o.side==='BUY';
  if(o.sl&&(buy?b<=o.sl:a>=o.sl)){closePos(o.id,o.sl,'SL');closed=true}
  else if(o.tp&&(buy?b>=o.tp:a<=o.tp)){closePos(o.id,o.tp,'TP');closed=true}});
 if(!closed)renderLive();persist()}
function renderLive(){if($('#v-trading').hidden||$('#trDemo').hidden)return;
 $('#trBid').textContent=fmt(sym,bid(sym));$('#trAsk').textContent=fmt(sym,ask(sym));
 $('#trSell small').textContent=fmt(sym,bid(sym));$('#trBuy small').textContent=fmt(sym,ask(sym));
 let fl=0;D.pos.forEach(o=>{const v=floatPl(o);fl+=v;['#pl-','#plf-'].forEach(k=>{const c=$(k+o.id);if(c){c.textContent=money(v);c.className=v>=0?'pos':'neg'}})});
 $('#trBal').textContent=money(D.bal);$('#trEq').textContent=money(D.bal+fl);
 const f=$('#trFl');f.textContent=money(fl);f.className=fl>=0?'pos':'neg'}

/* ---------- order ---------- */
function open(side){const l=parseFloat($('#trLot').value),sl=parseFloat($('#trSl').value)||0,tp=parseFloat($('#trTp').value)||0,m=SYM[sym],e=side==='BUY'?ask(sym):bid(sym),er=t=>{$('#trErr').textContent=t;$('#trErr').hidden=!t};
 if(!(l>=.01&&l<=10))return er('Lot harus antara 0.01 dan 10.');
 if(side==='BUY'&&((sl&&sl>=e)||(tp&&tp<=e)))return er('Buy: SL harus di bawah dan TP di atas harga entry.');
 if(side==='SELL'&&((sl&&sl<=e)||(tp&&tp>=e)))return er('Sell: SL harus di atas dan TP di bawah harga entry.');
 if(D.pos.length>=20)return er('Maksimal 20 posisi terbuka.');
 er('');D.pos.push({id:Date.now()+Math.random().toString(36).slice(2,5),s:sym,side,l:Math.round(l*100)/100,e,sl,tp,t:Date.now()});
 persist();drawLines();renderAll();toast(side+' '+sym+' '+l.toFixed(2)+' lot @ '+fmt(sym,e))}
function closePos(id,price,why){const i=D.pos.findIndex(o=>o.id===id);if(i<0)return;const o=D.pos[i],x=price||(o.side==='BUY'?bid(o.s):ask(o.s)),r=Math.round(plOf(o,x)*100)/100;
 D.pos.splice(i,1);D.bal=Math.round((D.bal+r)*100)/100;D.hist.unshift({id:o.id,s:o.s,side:o.side,l:o.l,e:o.e,x,r,t:Date.now(),why:why||'Manual'});D.hist=D.hist.slice(0,30);
 if($('#trJr').checked){const d=new Date(),a=load();a.push({id:o.id,d:new Date(d-d.getTimezoneOffset()*6e4).toISOString().slice(0,10),p:o.s,s:o.side,l:o.l,r,n:'Demo trading ('+(why||'Manual')+')'});save(a);if(typeof render==='function')render()}
 persist();drawLines();renderAll();toast((r>=0?'Profit ':'Loss ')+money(r)+' • '+o.s+' ditutup'+(why?' ('+why+')':''))}

/* ---------- tampilan tabel ---------- */
const tm=t=>new Date(t).toLocaleString('id-ID',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',hour12:false});
function renderAll(){
 $('#trPos tbody').innerHTML=D.pos.map(o=>`<tr><td>${o.s}</td><td class="${o.side==='BUY'?'pos':'neg'}">${o.side}</td><td>${o.l.toFixed(2)}</td><td>${fmt(o.s,o.e)}</td><td>${o.sl?fmt(o.s,o.sl):'-'}</td><td>${o.tp?fmt(o.s,o.tp):'-'}</td><td id="pl-${o.id}">-</td><td><button class="btn ghost sm" data-close="${o.id}" type="button">Tutup</button></td></tr>`).join('');
 $('#trPosE').hidden=D.pos.length>0;
 $('#trFsPos').innerHTML=D.pos.length?D.pos.map(o=>`<span class="chip"><b class="${o.side==='BUY'?'pos':'neg'}">${o.side}</b> ${o.s} ${o.l.toFixed(2)} @ ${fmt(o.s,o.e)} <b id="plf-${o.id}">-</b><button class="btn ghost sm" data-close="${o.id}" type="button">Tutup</button></span>`).join('')+(D.pos.length>1?'<button class="btn sm" data-closeall type="button">Tutup Semua</button>':''):'<span class="mut">Tidak ada posisi terbuka.</span>';
 $('#trHist tbody').innerHTML=D.hist.map(h=>`<tr><td>${tm(h.t)}</td><td>${h.s}</td><td class="${h.side==='BUY'?'pos':'neg'}">${h.side}</td><td>${h.l.toFixed(2)}</td><td>${fmt(h.s,h.e)} → ${fmt(h.s,h.x)}</td><td class="${h.r>=0?'pos':'neg'}">${money(h.r)}</td><td>${esc(h.why)}</td></tr>`).join('');
 $('#trHistE').hidden=D.hist.length>0;renderLive()}


/* ---------- QuickPro MT4 real-account bridge ---------- */
let mt4Poll=0,mt4Busy=false,mt4Snapshot=null;
const mt4Money=n=>Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
async function mt4Api(url,opts={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});let j={};try{j=await r.json()}catch(e){}if(!r.ok)throw new Error(j.error||'Permintaan gagal.');return j}
function mt4Err(t){const e=$('#mt4Err');e.textContent=t||'';e.hidden=!t}
function mt4Render(x){mt4Snapshot=x;$('#mt4Conn').textContent=x.online?'ONLINE':'OFFLINE';$('#mt4Conn').className=x.online?'pos':'neg';$('#mt4Seen').textContent=x.lastSeen?'Update '+new Date(x.lastSeen).toLocaleTimeString('id-ID'):'Menunggu terminal MT4';$('#mt4Bal').textContent=x.account?'$'+mt4Money(x.account.balance)+' '+esc(x.account.currency):'—';$('#mt4Eq').textContent=x.account?'$'+mt4Money(x.account.equity)+' '+esc(x.account.currency):'—';$('#mt4Pl').textContent=x.account?'$'+mt4Money(x.account.profit):'—';$('#mt4MaxLot').textContent=x.maxLot||'—';$('#mt4Account').textContent=x.account?`Login ${x.account.login} · ${x.account.server} · Leverage 1:${x.account.leverage} · Free margin ${mt4Money(x.account.freeMargin)} ${x.account.currency}`:(x.configured?'Terminal belum mengirim data akun.':'Bridge belum dikonfigurasi oleh administrator.');
 const ps=x.positions||[];$('#mt4Positions').innerHTML=ps.map(p=>`<tr><td>${p.ticket}</td><td>${esc(p.symbol)}</td><td class="${p.type===0?'pos':'neg'}">${p.type===0?'BUY':'SELL'}</td><td>${Number(p.lots).toFixed(2)}</td><td>${p.openPrice}</td><td>${p.sl||'—'}</td><td>${p.tp||'—'}</td><td class="${p.profit>=0?'pos':'neg'}">${mt4Money(p.profit+p.swap+p.commission)}</td><td><button class="btn ghost sm" type="button" data-mt4-close="${p.ticket}" ${!x.online?'disabled':''}>Tutup</button></td></tr>`).join('');$('#mt4PosEmpty').hidden=ps.length>0;
 $('#mt4Commands').innerHTML=(x.commands||[]).map(c=>`<tr><td>${new Date(c.createdAt).toLocaleString('id-ID')}</td><td>${c.action==='open'?`${c.side} ${esc(c.symbol)} ${c.lots} lot`:`Tutup #${c.ticket}`}</td><td>${esc(c.status)}</td><td>${esc(c.result||'—')}</td></tr>`).join('')||'<tr><td colspan="4">Belum ada perintah.</td></tr>';
 const allowed=(x.allowedSymbols||[]);const sym=$('#mt4Symbol');if(allowed.length&&!allowed.includes(sym.value.toUpperCase()))sym.value=allowed[0];$('#mt4Buy').disabled=$('#mt4Sell').disabled=!x.online;}
async function loadMT4Status(){if(mt4Busy||$('#trMt4').hidden)return;mt4Busy=true;try{mt4Render(await mt4Api('/api/mt4/status'))}catch(e){mt4Err(e.message)}finally{mt4Busy=false}}
async function mt4Order(side){mt4Err('');if(!mt4Snapshot||!mt4Snapshot.online)return mt4Err('Terminal QuickPro MT4 belum online.');const payload={symbol:$('#mt4Symbol').value.trim().toUpperCase(),side,lots:Number($('#mt4Lots').value),sl:Number($('#mt4Sl').value)||0,tp:Number($('#mt4Tp').value)||0};if(!confirm(`Kirim order ${side} ${payload.symbol} ${payload.lots} lot ke akun QuickPro MT4?`))return;try{const r=await mt4Api('/api/mt4/orders',{method:'POST',body:JSON.stringify(payload)});toast('Perintah dikirim ke terminal MT4. Menunggu hasil eksekusi.');setTimeout(loadMT4Status,1200)}catch(e){mt4Err(e.message)}}
async function mt4Close(ticket){if(!confirm(`Tutup posisi MT4 ticket #${ticket}?`))return;try{await mt4Api('/api/mt4/close',{method:'POST',body:JSON.stringify({ticket:Number(ticket)})});toast('Perintah tutup dikirim. Menunggu konfirmasi MT4.');setTimeout(loadMT4Status,1200)}catch(e){mt4Err(e.message)}}

/* ---------- init (dipanggil saat menu dibuka) ---------- */
window.trInit=()=>{
 if(!inited){inited=true;
  $('#trSym').innerHTML=Object.keys(SYM).map(k=>`<option>${k}</option>`).join('');
  $('#trFs').onclick=()=>{const c=$('#v-trading>.card');if(document.fullscreenElement)document.exitFullscreen();else if(c.requestFullscreen)c.requestFullscreen().catch(()=>{})};
  document.addEventListener('fullscreenchange',()=>{$('#trFs').lastChild.textContent=document.fullscreenElement?'Keluar':'Layar Penuh';if(chart)setTimeout(()=>chart.timeScale().fitContent(),100)});
  $('#trTabs').onclick=e=>{const b=e.target.closest('button');if(b)tab(b.dataset.tab)};
  $('#mt4Refresh').onclick=loadMT4Status;$('#mt4Buy').onclick=()=>mt4Order('BUY');$('#mt4Sell').onclick=()=>mt4Order('SELL');$('#mt4Positions').onclick=e=>{const b=e.target.closest('[data-mt4-close]');if(b)mt4Close(b.dataset.mt4Close)};
  $('#trSym').onchange=e=>{sym=e.target.value;if(series)seed();renderAll()};
  $('#trTf').onclick=e=>{const b=e.target.closest('button');if(!b)return;tf=+b.dataset.tf;$$('#trTf button').forEach(x=>x.classList.toggle('on',x===b));if(series)seed()};
  $('#trBuy').onclick=()=>open('BUY');$('#trSell').onclick=()=>open('SELL');
  $('#trFsPos').onclick=e=>{if(e.target.closest('[data-closeall]'))D.pos.slice().forEach(o=>closePos(o.id,0,'Tutup Semua'));else{const b=e.target.closest('[data-close]');if(b)closePos(b.dataset.close)}};
  $('#trPos').onclick=e=>{const b=e.target.closest('[data-close]');if(b)closePos(b.dataset.close)};
  $('#trReset').onclick=()=>{if(confirm('Reset akun demo ke $'+START.toLocaleString('en-US')+'? Semua posisi dan riwayat demo dihapus.')){D.bal=START;D.pos=[];D.hist=[];persist();drawLines();renderAll()}};
  timer=setInterval(ticks,1000);if(!mt4Poll)mt4Poll=setInterval(()=>{if(!$('#trMt4').hidden)loadMT4Status()},5000)}
 tab($('#trTabs .on').dataset.tab)};
})();
