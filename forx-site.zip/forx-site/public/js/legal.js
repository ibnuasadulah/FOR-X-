/* Logic untuk syarat.html dan privasi.html (tema, bahasa ID/EN, menu, status login, daftar isi) */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let lang=store.get('lang')==='en'?'en':'id';
const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',other:'Baca juga',terms:'Syarat & Ketentuan',privacy:'Kebijakan Privasi'},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',other:'Also read',terms:'Terms & Conditions',privacy:'Privacy Policy'}};
const user=()=>{try{return JSON.parse(store.get('session'))}catch(e){return null}};
function renderAuth(){const s=user(),L=T[lang];
 $('#auth').innerHTML=s&&s.name?`<a class="btn pill ghost" href="dashboard.html">${String(s.name).replace(/[<>&"]/g,'')}</a>`:`<a class="btn pill ghost" href="masuk.html">${L.login}</a> <a class="btn pill primary" href="masuk.html#daftar">${L.join} →</a>`}
function applyLang(){const L=T[lang];
 $$('[data-i]').forEach(e=>{if(L[e.dataset.i]!==undefined)e.textContent=L[e.dataset.i]});
 $('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;
 document.title=document.documentElement.dataset[lang==='en'?'titleEn':'titleId']||document.title;
 renderAuth();spy()}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')==='light'?'light':'dark');
function switchTheme(){const d=document.documentElement,n=d.dataset.theme==='dark'?'light':'dark';
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){setTheme(n);return}
 if(document.startViewTransition){document.startViewTransition(()=>setTheme(n));return}
 d.classList.add('theme-anim');setTheme(n);setTimeout(()=>d.classList.remove('theme-anim'),500)}
$('#theme').onclick=switchTheme;
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.addEventListener('click',e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')});

/* daftar isi: tandai bagian yang sedang dibaca */
let obs=null;
function spy(){
 if(obs)obs.disconnect();
 const secs=$$('.lg-doc [data-lang="'+lang+'"] section'),links=$$('.lg-toc[data-lang="'+lang+'"] a');
 if(!('IntersectionObserver' in window)||!secs.length)return;
 obs=new IntersectionObserver(es=>{es.forEach(en=>{if(en.isIntersecting){links.forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#'+en.target.id))}})},{rootMargin:'-90px 0px -65% 0px'});
 secs.forEach(s=>obs.observe(s))}
applyLang();
