/* Logic for tentang.html (theme, language, menu, login state, page text ID/EN) */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let lang=store.get('lang')||'id';
const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',
tE:'TENTANG KAMI',tH:'Mengenal Lebih Dekat <span class="grad">FOR-X</span>',tS:'Membangun komunitas trader yang jujur, disiplin, dan saling mendukung, dengan proses yang jelas dan risiko yang selalu dihormati.',
hE:'SEJARAH SINGKAT',hH:'Awal Mula Perjalanan <span class="grad">Kami</span>',
h1:'<b>FOR-X</b> berawal dari sekelompok kecil <b>trader</b> yang rutin bertukar catatan tentang pergerakan harga emas dan mata uang. Dari obrolan itu lahir keinginan untuk membuat wadah belajar yang terbuka, jujur, dan mudah diikuti.',
h2:'Kini FOR-X berkembang menjadi komunitas yang menyediakan edukasi bertahap, alat bantu analisa, dan ruang diskusi yang sehat bagi <b>trader</b> pemula hingga berpengalaman, dengan risiko yang selalu dibahas secara rasional.',
vH:'Visi <span class="grad">Kami</span>',vP:'Menjadi komunitas trading yang dipercaya karena kejujuran dan mutu edukasinya, tempat setiap anggota belajar membaca pasar secara mandiri, mengambil keputusan berdasarkan data, dan menjaga risiko dengan disiplin.',
mH:'Misi <span class="grad">Kami</span>',
m1:'<b>Edukasi berkelanjutan:</b> materi yang terstruktur dan realistis, tanpa janji cepat kaya.',
m2:'<b>Alat bantu yang berguna:</b> tools analisa, kalkulator, dan ruang diskusi untuk membantu keputusan yang lebih terukur.',
m3:'<b>Komunitas yang suportif:</b> budaya saling membantu, mengulas jurnal trading, dan saling menguatkan saat sedang drawdown.',
nE:'NILAI-NILAI UTAMA',nH:'Fondasi <span class="grad">Komunitas</span> Kami',nP:'Nilai-nilai ini menjadi pegangan kami dalam setiap materi dan diskusi.',
c1T:'Integritas',c1P:'Kami jujur soal hasil, mengakui kerugian sebagai bagian dari proses, dan tidak memakai klaim keuntungan yang berlebihan.',
c2T:'Belajar Tanpa Henti',c2P:'Pasar terus berubah. Rasa ingin tahu dan latihan yang konsisten adalah cara terbaik untuk tetap relevan.',
c3T:'Saling Mendukung',c3P:'Trading tidak harus dijalani sendirian. Diskusi yang sehat membantu semua orang belajar dan tetap tenang saat pasar bergejolak.'},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',
tE:'ABOUT US',tH:'Getting to Know <span class="grad">FOR-X</span> Better',tS:'Building an honest, disciplined, and supportive trader community, with clear processes and risk always respected.',
hE:'BRIEF HISTORY',hH:'The Start of <span class="grad">Our</span> Journey',
h1:'<b>FOR-X</b> began as a small group of <b>traders</b> who regularly shared notes on gold and currency movements. Those conversations grew into the idea of an open, honest, easy-to-follow place to learn.',
h2:'Today FOR-X is a community offering step-by-step education, analysis tools, and healthy discussion for <b>traders</b> from beginners to experienced, with risk always discussed rationally.',
vH:'Our <span class="grad">Vision</span>',vP:'To be a trading community trusted for its honesty and quality of education, where every member learns to read the market independently, decide from data, and manage risk with discipline.',
mH:'Our <span class="grad">Mission</span>',
m1:'<b>Continuous education:</b> structured, realistic lessons with no get-rich-quick promises.',
m2:'<b>Useful tools:</b> analysis tools, calculators, and discussion spaces that support more measured decisions.',
m3:'<b>A supportive community:</b> a culture of helping each other, reviewing trading journals, and lifting each other up during drawdowns.',
nE:'CORE VALUES',nH:'The Foundation of Our <span class="grad">Community</span>',nP:'These values guide every lesson and discussion.',
c1T:'Integrity',c1P:'We are honest about results, treat losses as part of the process, and avoid exaggerated profit claims.',
c2T:'Always Learning',c2P:'Markets keep changing. Curiosity and consistent practice are the best way to stay relevant.',
c3T:'Mutual Support',c3P:'Trading does not have to be done alone. Healthy discussion helps everyone learn and stay calm when markets get rough.'}};
const user=()=>{try{return JSON.parse(store.get('session'))}catch(e){return null}};
function renderAuth(){const s=user(),L=T[lang];
 $('#auth').innerHTML=s?`<a class="btn pill ghost" href="dashboard.html">${s.name.replace(/[<>&"]/g,'')}</a>`:`<a class="btn pill ghost" href="masuk.html">${L.login}</a> <a class="btn pill primary" href="masuk.html#daftar">${L.join} →</a>`}
function applyLang(){const L=T[lang];$$('[data-i]').forEach(e=>{if(L[e.dataset.i]!==undefined)e.innerHTML=L[e.dataset.i]});
 $('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;renderAuth()}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')||'dark');
/* theme switch with smooth cross-fade (colors unchanged) */
function switchTheme(){const d=document.documentElement,n=d.dataset.theme==='dark'?'light':'dark';
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){setTheme(n);return}
 if(document.startViewTransition){document.startViewTransition(()=>setTheme(n));return}
 d.classList.add('theme-anim');setTheme(n);setTimeout(()=>d.classList.remove('theme-anim'),500)}
$('#theme').onclick=switchTheme;
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.onclick=e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')};
applyLang();
