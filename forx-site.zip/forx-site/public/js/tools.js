/* Trading Tools page: catalog (filterable), lot calculator, theme/lang/auth */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let lang=store.get('lang')||'id',cat='all';
const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',
 tlBadge:'Katalog Indikator & Bot',tlH1:'Trading',tlH2:'Tools',tlSub:'Kumpulan alat bantu, kalkulator risiko, indikator presisi MetaTrader 5, hingga Expert Advisor (EA) kustom untuk memaksimalkan potensi trading Anda.',
 cAll:'Semua',cEa:'Expert Advisor',cInd:'Indikator',cCalc:'Kalkulator',kBadge:'Kalkulator Lot',kT:'Hitung Ukuran Lot dari Risiko Anda',kS:'Tentukan risiko per transaksi, lalu lihat lot yang sesuai dengan jarak stop loss Anda.',
 kBal:'Saldo akun (USD)',kRisk:'Risiko per transaksi (%)',kSl:'Stop loss (pips)',kPv:'Nilai pip per 1 lot (USD)',kRes:'Ukuran lot',kAmt:'Risiko (USD)',
 kNote:'Nilai pip default 10 USD berlaku untuk 1 lot standar pada pair seperti EUR/USD. Instrumen lain (emas, JPY, indeks) berbeda, sesuaikan sebelum dipakai.',
 tvvip:'Member VVIP',tfree:'Gratis',tUse:'Pakai sekarang',tGet:'Lihat paket',gEa:'Expert Advisor',gInd:'Indikator',gCalc:'Kalkulator'},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',
 tlBadge:'Indicator & Bot Catalog',tlH1:'Trading',tlH2:'Tools',tlSub:'A collection of helper tools, risk calculators, precision MetaTrader 5 indicators, and custom Expert Advisors (EA) to maximize your trading potential.',
 cAll:'All',cEa:'Expert Advisor',cInd:'Indicators',cCalc:'Calculators',kBadge:'Lot Calculator',kT:'Work Out Your Lot Size from Your Risk',kS:'Set your risk per trade, then see the lot size that fits your stop loss distance.',
 kBal:'Account balance (USD)',kRisk:'Risk per trade (%)',kSl:'Stop loss (pips)',kPv:'Pip value per 1 lot (USD)',kRes:'Lot size',kAmt:'Risk (USD)',
 kNote:'The default pip value of 10 USD applies to 1 standard lot on pairs like EUR/USD. Other instruments (gold, JPY, indices) differ, so adjust it before use.',
 tvvip:'VVIP members',tfree:'Free',tUse:'Use now',tGet:'View plan',gEa:'Expert Advisor',gInd:'Indicator',gCalc:'Calculator'}};
/* CATALOG: replace with your real products. type: ea | ind | calc, acc: vvip | free */
const ico={
 ea:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="7" width="14" height="12" rx="3"/><path d="M12 7V4M9 12h.01M15 12h.01M9 16h6M2 12v3M22 12v3"/></svg>',
 ind:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 20h18M4 15l5-5 4 3 7-8"/></svg>',
 calc:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/></svg>'};
const TOOLS=[
{type:'ea',acc:'vvip',
 id:{t:'Trend Follower EA',d:'Expert Advisor yang mengikuti arah tren dengan aturan masuk dan keluar yang jelas untuk MetaTrader 5.',f:['Stop loss & take profit otomatis','Filter sesi dan spread','Dapat diuji di Strategy Tester']},
 en:{t:'Trend Follower EA',d:'An Expert Advisor that follows the trend with clear entry and exit rules for MetaTrader 5.',f:['Automatic stop loss & take profit','Session and spread filters','Testable in Strategy Tester']}},
{type:'ea',acc:'vvip',
 id:{t:'Risk Guard EA',d:'Pelindung akun yang menutup posisi atau menghentikan trading saat batas drawdown harian tercapai.',f:['Batas drawdown harian','Batas jumlah posisi','Notifikasi ke ponsel']},
 en:{t:'Risk Guard EA',d:'An account protector that closes positions or stops trading when the daily drawdown limit is hit.',f:['Daily drawdown limit','Maximum open positions','Mobile notifications']}},
{type:'ind',acc:'vvip',
 id:{t:'Supply & Demand Zones',d:'Indikator yang menandai area supply dan demand otomatis di grafik MT5 Anda.',f:['Zona otomatis multi-timeframe','Peringatan saat harga menyentuh zona','Warna yang dapat diatur']},
 en:{t:'Supply & Demand Zones',d:'An indicator that automatically marks supply and demand areas on your MT5 chart.',f:['Automatic multi-timeframe zones','Alert when price touches a zone','Customizable colors']}},
{type:'ind',acc:'vvip',
 id:{t:'Market Structure Mapper',d:'Menandai Higher High, Lower Low, BOS, dan CHoCH agar struktur pasar terbaca sekilas.',f:['Label BOS & CHoCH','Penanda swing high dan low','Ringan dan tidak repaint']},
 en:{t:'Market Structure Mapper',d:'Marks Higher Highs, Lower Lows, BOS, and CHoCH so market structure reads at a glance.',f:['BOS & CHoCH labels','Swing high and low markers','Lightweight, non-repainting']}},
{type:'ind',acc:'free',
 id:{t:'Session Clock',d:'Penunjuk jam sesi Asia, Eropa, dan Amerika langsung di grafik, lengkap dengan waktu rilis berita penting.',f:['Zona waktu lokal','Penanda sesi berwarna','Pengingat rilis berita']},
 en:{t:'Session Clock',d:'Shows the Asian, European, and US sessions right on the chart, with major news release times.',f:['Local time zone','Colored session markers','News release reminders']}},
{type:'calc',acc:'free',href:'#kalkulator',
 id:{t:'Kalkulator Lot',d:'Hitung ukuran lot yang tepat dari saldo, persentase risiko, dan jarak stop loss.',f:['Hasil langsung saat mengetik','Atur nilai pip sendiri','Gratis tanpa daftar']},
 en:{t:'Lot Calculator',d:'Work out the right lot size from your balance, risk percentage, and stop loss distance.',f:['Instant results as you type','Set your own pip value','Free, no sign-up']}}
];
const GK={ea:'gEa',ind:'gInd',calc:'gCalc'};
const esc=s=>String(s).replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));
function renderTools(){const t=T[lang];
 $('#tlGrid').innerHTML=TOOLS.filter(x=>cat==='all'||x.type===cat).map(x=>{const c=x[lang],free=x.acc==='free';
  const href=x.href||(free?'#kalkulator':'vvip.html');
  return `<article class="tool"><div class="tool-top"><i class="fic">${ico[x.type]}</i><span class="tool-cat">${t[GK[x.type]]}</span></div><h3>${esc(c.t)}</h3><p>${esc(c.d)}</p><ul>${c.f.map(i=>`<li>${esc(i)}</li>`).join('')}</ul><div class="tool-foot"><span class="tool-acc"><i class="dot${free?'':' dim'}"></i>${free?t.tfree:t.tvvip}</span><a class="btn pill ${free?'primary':'ghost'}" href="${href}">${free?t.tUse:t.tGet}</a></div></article>`}).join('')}
$$('#tlChips .chip').forEach(b=>b.onclick=()=>{cat=b.dataset.f;$$('#tlChips .chip').forEach(x=>x.setAttribute('aria-pressed',x===b));renderTools()});
/* lot calculator */
function calc(){const v=id=>parseFloat($(id).value)||0,bal=v('#kBal'),r=v('#kRisk'),sl=v('#kSl'),pv=v('#kPv'),amt=bal*r/100;
 const lot=sl>0&&pv>0?amt/(sl*pv):0;$('#kLot').textContent=lot.toFixed(2);$('#kAmt').textContent=amt.toFixed(2)}
$('#calc').addEventListener('input',calc);$('#calc').onsubmit=e=>e.preventDefault();calc();
/* auth */
const user=()=>{try{return JSON.parse(store.get('session'))}catch(e){return null}};
function renderAuth(){const s=user();
 $('#auth').innerHTML=s&&s.name?`<a class="btn pill ghost" href="dashboard.html">${esc(s.name)}</a>`:`<a class="btn pill ghost" href="masuk.html">${T[lang].login}</a> <a class="btn pill primary" href="masuk.html#daftar">${T[lang].join} →</a>`}
function applyLang(){const t=T[lang];$$('[data-i]').forEach(e=>{if(t[e.dataset.i])e.textContent=t[e.dataset.i]});$('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;renderAuth();renderTools()}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')||'dark');
function switchTheme(){const d=document.documentElement,n=d.dataset.theme==='dark'?'light':'dark';
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){setTheme(n);return}
 if(document.startViewTransition){document.startViewTransition(()=>setTheme(n));return}
 d.classList.add('theme-anim');setTheme(n);setTimeout(()=>d.classList.remove('theme-anim'),500)}
$('#theme').onclick=switchTheme;
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.onclick=e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')};
applyLang();
