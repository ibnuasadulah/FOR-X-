/* Logic for vvip.html (theme, language, menu, login state, page text ID/EN) */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let lang=store.get('lang')||'id';
const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',
tE:'PREMIUM MEMBERSHIP',tH:'Tingkatkan Disiplin Trading Bersama <span class="grad">FOR-X Membership</span>',tS:'Akses setup harian, indikator eksklusif MT5, materi terstruktur, dan mentoring dari trader berpengalaman dalam satu keanggotaan.',
b1:'Lihat Paket VVIP',b2:'Konsultasi via Telegram',
fE:'FASILITAS MEMBER',fH:'Semua yang Kamu Butuhkan untuk <span class="grad">Konsisten</span>',fP:'Kami menyusun ekosistem VVIP agar kamu tidak perlu trading sendirian dan kebingungan di pasar.',
f1T:'Modul Video Terstruktur',f1P:'Dari dasar struktur pasar hingga price action, supply & demand, dan manajemen risiko, disusun bertahap.',
f2T:'Setup Harian',f2P:'Ide trading harian untuk emas dan pair mayor lengkap dengan area entry, target, dan stop loss sebagai bahan belajar.',
f3T:'Indikator Kustom MT5',f3P:'Indikator buatan tim untuk membantu menyaring noise dan memberi konfirmasi tambahan pada analisamu.',
f4T:'Grup Diskusi Privat',f4P:'Grup Telegram tertutup untuk bedah chart dan bertukar sudut pandang secara sehat tanpa spam.',
f5T:'Live Session & Mentoring',f5P:'Sesi live saat rilis berita besar seperti NFP, CPI, dan FOMC untuk memahami reaksi pasar bersama-sama.',
f6T:'Rebate & Biaya Spesial',f6P:'Penawaran spread dan rebate dari broker mitra berlisensi untuk membantu menekan biaya trading.',
pE:'PILIHAN MEMBERSHIP',pH:'Gabung <span class="grad">Membership</span> Sekarang',pP:'Semua fasilitas premium dalam satu paket, tanpa biaya tersembunyi.',
cB:'SPESIAL PROMO',cT:'Biaya Akses VVIP',cPer:'/ bulan',
l1:'Modul video lengkap',l2:'Setup harian emas & forex',l3:'Indikator eksklusif MT5',l4:'Grup diskusi privat',l5:'Rebate & biaya spesial di broker mitra',l6:'Webinar & live session berkala',
cBtn:'Daftar VVIP',cN:'Kuota promo terbatas. Harga di atas hanya contoh.',rk:'Trading berisiko dan dapat menyebabkan kerugian modal. Tidak ada jaminan profit.'},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',
tE:'PREMIUM MEMBERSHIP',tH:'Sharpen Your Trading Discipline with <span class="grad">FOR-X Membership</span>',tS:'Daily setups, exclusive MT5 indicators, structured lessons, and mentoring from experienced traders in one membership.',
b1:'View VVIP Plan',b2:'Chat on Telegram',
fE:'MEMBER BENEFITS',fH:'Everything You Need to Stay <span class="grad">Consistent</span>',fP:'We built the VVIP ecosystem so you do not have to trade alone or feel lost in the market.',
f1T:'Structured Video Modules',f1P:'From market structure basics to price action, supply & demand, and risk management, taught step by step.',
f2T:'Daily Setups',f2P:'Daily trade ideas for gold and major pairs with entry areas, targets, and stop loss levels as learning material.',
f3T:'Custom MT5 Indicators',f3P:'Team-built indicators that help filter noise and add confirmation to your own analysis.',
f4T:'Private Discussion Group',f4P:'A closed Telegram group for chart reviews and healthy exchange of views, with no spam.',
f5T:'Live Sessions & Mentoring',f5P:'Live sessions during major news such as NFP, CPI, and FOMC to understand market reactions together.',
f6T:'Rebates & Special Fees',f6P:'Spread and rebate offers from licensed partner brokers to help reduce trading costs.',
pE:'MEMBERSHIP PLAN',pH:'Join <span class="grad">Membership</span> Today',pP:'All premium benefits in one plan, with no hidden fees.',
cB:'SPECIAL PROMO',cT:'VVIP Access Fee',cPer:'/ month',
l1:'Complete video modules',l2:'Daily gold & forex setups',l3:'Exclusive MT5 indicators',l4:'Private discussion group',l5:'Rebates & special fees at partner brokers',l6:'Regular webinars & live sessions',
cBtn:'Join VVIP',cN:'Limited promo quota. Prices shown are examples only.',rk:'Trading involves risk and can result in loss of capital. No profit is guaranteed.'}};
const user=()=>{try{return JSON.parse(store.get('session'))}catch(e){return null}};
function renderAuth(){const s=user(),L=T[lang];
 $('#auth').innerHTML=s?`<a class="btn pill ghost" href="dashboard.html">${s.name.replace(/[<>&"]/g,'')}</a>`:`<a class="btn pill ghost" href="masuk.html">${L.login}</a> <a class="btn pill primary" href="masuk.html#daftar">${L.join} →</a>`}
function applyLang(){const L=T[lang];$$('[data-i]').forEach(e=>{if(L[e.dataset.i]!==undefined)e.innerHTML=L[e.dataset.i]});
 $('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;renderAuth()}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')||'dark');
/* theme switch with smooth cross-fade (colors unchanged) */
function switchTheme(){const d=document.documentElement,n=d.dataset.theme==='dark'?'light':'dark';
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){setTheme(n);return}
 if(document.startViewTransition){document.startViewTransition(()=>setTheme(n));return}
 d.classList.add('theme-anim');setTheme(n);setTimeout(()=>d.classList.remove('theme-anim'),500)}
$('#theme').onclick=switchTheme;
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.onclick=e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')};
applyLang();
