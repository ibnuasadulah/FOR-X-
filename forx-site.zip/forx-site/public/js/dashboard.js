/* Dashboard member FOR-X. Butuh login: membaca localStorage 'session' ({name,email}) seperti halaman lain. */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}},del(k){try{localStorage.removeItem(k)}catch(e){}}};
const esc=s=>String(s).replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&#39;'}[c]));

/* ---------- guard: harus login ---------- */
let S=null;try{S=(window.API&&typeof API.user==='function'&&API.user())||JSON.parse(store.get('session'))}catch(e){}
if(!S||!S.name){location.replace('masuk.html?next=dashboard.html');throw new Error('not logged in')}
const UID=String(S.email||S.name).toLowerCase();
const KJ='journal:'+UID,KB='balance:'+UID;

/* ---------- tema ---------- */
const SUN='<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',MOON='<svg viewBox="0 0 24 24"><path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/></svg>';
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#themeBtn').innerHTML=t==='dark'?SUN:MOON;if(window.trTheme)trTheme()}
$('#themeBtn').onclick=()=>setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark');

/* ---------- profil ---------- */
let initials=S.name.trim().slice(0,2).toUpperCase()||'?';
$('#av').textContent=initials;$('#uName').textContent=S.name;$('#hName').textContent=S.name;$('#uMail').textContent=S.email||'';
const ROLE=S.role==='admin'?'Admin':S.role==='trader'?'Trader':((/vip/i.test(String(S.role||S.plan||S.tier||''))||S.vvip_active)?'VVIP':'Member');
$('#hName').nextElementSibling.textContent=ROLE;$('.un small').textContent=ROLE+' ▾';
$('#logout').onclick=async()=>{try{if(window.API&&typeof API.logout==='function')await API.logout()}catch(e){}store.del('session');location.href='masuk.html'};

/* ---------- menu samping ---------- */
const I={
 dash:'<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 cal:'<rect x="4" y="5" width="16" height="16" rx="2"/><path d="M16 3v4M8 3v4M4 11h16"/>',
 book:'<path d="M3 5h7a2 2 0 0 1 2 2v13a2 2 0 0 0-2-2H3zM21 5h-7a2 2 0 0 0-2 2v13a2 2 0 0 1 2-2h7z"/>',
 tool:'<rect x="3" y="8" width="18" height="12" rx="2"/><path d="M9 8V6a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/>',
 acc:'<circle cx="12" cy="12" r="9"/><path d="M14.5 9.5c-.5-1-1.4-1.5-2.5-1.5-1.4 0-2.5.8-2.5 2s1 1.6 2.5 2 2.5.8 2.5 2-1 2-2.5 2c-1.1 0-2-.5-2.5-1.5M12 6v2M12 16v2"/>',
 bot:'<rect x="5" y="7" width="14" height="12" rx="3"/><path d="M12 7V4M9 12h.01M15 12h.01M9 16h6"/>',
 note:'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h3"/>',
 cup:'<path d="M8 4h8v5a4 4 0 0 1-8 0zM8 6H4v1a3 3 0 0 0 4 3M16 6h4v1a3 3 0 0 1-4 3M12 13v4M8 21h8M10 17h4"/>',
 chat:'<path d="M4 5h16v11H9l-5 4z"/>',
 sig:'<path d="M3 17l6-6 4 4 8-9"/>',
 vid:'<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
 crown:'<path d="M3 8l4 3 5-6 5 6 4-3-2 10H5z"/>',
 user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.5-6 8-6s8 2 8 6"/>'};
const NAV=[
 {t:'dashboard',n:'Dashboard',i:'dash'},
 {g:'MAIN MENU'},{t:'waktu',n:'Waktu Pasar',i:'clock'},{t:'kalender',n:'Kalender Ekonomi',i:'cal'},{h:'artikel.html',n:'Artikel & Edukasi',i:'book'},{h:'tools.html',n:'Tools Trading',i:'tool'},
 {g:'TRADING'},{t:'trading',n:'Chart & Trading',i:'sig'},{t:'mt5',n:'Akun MT5',i:'acc'},{t:'auto',n:'MT5 Auto Trading',i:'bot'},{t:'jurnal',n:'Jurnal Trading',i:'note'},
 {g:'COMMUNITY'},{h:'https://t.me/forxtraderindo',n:'Forum Komunitas',i:'chat',x:1},{h:'vvip.html',n:'Sinyal VIP',i:'sig'},{h:'https://t.me/forxtraderindo',n:'Event & Webinar',i:'vid',x:1},{t:'vip',n:'VIP Member',i:'crown'},
 {g:'ACCOUNT'},{t:'profil',n:'Profil Saya',i:'user'}];
$('#nav').innerHTML=NAV.map(x=>x.g?`<div class="ng">${x.g}</div>`:
 `<a class="ni" data-t="${x.t||''}" href="${x.t?'#'+x.t:x.h}"${x.x?' target="_blank" rel="noopener"':''}><svg viewBox="0 0 24 24">${I[x.i]}</svg>${esc(x.n)}</a>`).join('');

const SOON={mt5:['Akun MT5','Koneksi akun MT5 membutuhkan Expert Advisor dan server penerima data. Fitur ini akan aktif setelah integrasi EA selesai. Sementara itu, gunakan Jurnal Trading.'],auto:['MT5 Auto Trading','Fitur auto trading akan tersedia setelah koneksi akun MT5 diaktifkan.']};
function route(){let h=location.hash.slice(1)||'dashboard';if(!$('#v-'+h)&&!SOON[h])h='dashboard';
 $$('.view').forEach(v=>v.hidden=true);
 if(SOON[h]){$('#v-soon').hidden=false;$('#soonT').textContent=SOON[h][0];$('#soonP').textContent=SOON[h][1]}else $('#v-'+h).hidden=false;
 const NAVMAP={akun:'profil',keamanan:'profil',syarat:'profil',privasi:'profil'};
 $$('.ni').forEach(a=>a.classList.toggle('on',a.dataset.t===(NAVMAP[h]||h)));
 const vw=SOON[h]?$('#v-soon'):$('#v-'+h);vw.querySelectorAll('.card').forEach((c,i)=>c.style.setProperty('--i',i));
 if(h==='akun')prefillAkun();if(h==='profil'||h==='akun')loadExtra();if(h==='keamanan')loadSessions();
 $('#app').classList.remove('open');$('#menuBtn').setAttribute('aria-expanded','false');window.scrollTo(0,0);
 if((h==='kalender'||h==='dashboard')&&window.calInit)calInit();if(h==='trading'&&window.trInit)trInit()}
addEventListener('hashchange',route);
$('#menuBtn').onclick=()=>{const o=$('#app').classList.toggle('open');$('#menuBtn').setAttribute('aria-expanded',o)};
$('#scrim').onclick=()=>$('#app').classList.remove('open');

/* popover */
[['bellBtn','bellPop'],['userBtn','userPop']].forEach(([b,p])=>$('#'+b).onclick=e=>{e.stopPropagation();const o=$('#'+p).hidden;$$('.pop').forEach(x=>x.hidden=true);$('#'+p).hidden=!o;$('#'+b).setAttribute('aria-expanded',o)});
document.addEventListener('click',()=>$$('.pop').forEach(x=>x.hidden=true));
document.addEventListener('keydown',e=>{if(e.key==='Escape')$$('.pop').forEach(x=>x.hidden=true)});

/* ---------- jam & sesi pasar ---------- */
const SES=[{n:'Sydney',s:21,e:6},{n:'Tokyo',s:0,e:9},{n:'London',s:8,e:17},{n:'New York',s:13,e:22}]; /* jam UTC */
const wib=h=>String((h+7)%24).padStart(2,'0')+':00';
function marketOpen(d){const day=d.getUTCDay(),h=d.getUTCHours();return !((day===5&&h>=22)||day===6||(day===0&&h<22))}
function sessState(d){const h=d.getUTCHours(),mo=marketOpen(d);return SES.map(x=>({...x,open:mo&&(x.s<x.e?h>=x.s&&h<x.e:h>=x.s||h<x.e)}))}
const sessHtml=x=>`<div class="sess${x.open?' open':''}"><div><b>${x.n} Session</b><small>${wib(x.s)} - ${wib(x.e)} WIB</small></div><span class="pill">${x.open?'OPEN':'CLOSED'}</span></div>`;
function tick(){const d=new Date(),st=sessState(d),act=st.filter(x=>x.open);
 $('#clock').textContent=d.toLocaleTimeString('id-ID',{hour12:false});
 $('#date').textContent=d.toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
 $('#sessActive').innerHTML=act.length?act.map(sessHtml).join(''):'<p class="empty">Pasar forex sedang tutup (akhir pekan).</p>';
 $('#sessAll').innerHTML=st.map(sessHtml).join('')}
tick();setInterval(tick,1000);

/* ---------- kalender ekonomi (widget TradingView) ---------- */
function tvInit(){}
window.tvInit=tvInit;

/* ---------- jurnal ---------- */
const load=()=>{try{const a=JSON.parse(store.get(KJ));return Array.isArray(a)?a:[]}catch(e){return []}};
const save=a=>store.set(KJ,JSON.stringify(a));
const bal=()=>parseFloat(store.get(KB))||0;
const money=n=>(n<0?'-':'')+'$'+Math.abs(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const todayISO=()=>{const d=new Date();return new Date(d-d.getTimezoneOffset()*6e4).toISOString().slice(0,10)};
$('#jD').value=todayISO();

$('#jf').onsubmit=e=>{e.preventDefault();const er=m=>{$('#jE').textContent=m;$('#jE').hidden=!m;return !m};
 const d=$('#jD').value,p=$('#jP').value.trim().toUpperCase(),l=parseFloat($('#jL').value),r=parseFloat($('#jR').value);
 if(!/^\d{4}-\d{2}-\d{2}$/.test(d))return er('Tanggal wajib diisi.');
 if(!/^[A-Z0-9\/._-]{2,12}$/.test(p))return er('Pair tidak valid, contoh: XAUUSD.');
 if(!(l>0))return er('Lot harus lebih dari 0.');
 if(!isFinite(r))return er('Isi profit/loss, boleh negatif.');
 er('');const a=load();a.push({id:Date.now()+Math.random().toString(36).slice(2,6),d,p,s:$('#jS').value,l,r,n:$('#jN').value.trim().slice(0,120)});save(a);
 $('#jP').value=$('#jL').value=$('#jR').value=$('#jN').value='';render()};
$('#bf').onsubmit=e=>{e.preventDefault();const v=parseFloat($('#bal').value);store.set(KB,String(isFinite(v)&&v>0?v:0));render()};
$('#jClear').onclick=()=>{if(confirm('Hapus semua transaksi jurnal?')){save([]);render()}};
$('#jt tbody').onclick=e=>{const b=e.target.closest('.x');if(!b)return;save(load().filter(x=>x.id!==b.dataset.id));render()};

const EMPTY_LINE='<svg viewBox="0 0 24 24"><path d="M4 4v16h16M8 15l3-4 3 3 5-7"/></svg>',EMPTY_PIE='<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 3v9h9"/></svg>';
const empty=(ic,t)=>`<div class="es">${ic}<span>${t}</span></div>`;
let perfMode='profit',perfData=null;
const cls=v=>v>0?'pos':v<0?'neg':'';
const KBD='badges:'+UID;
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
function animNum(sel,to,fmt,ms=900){const el=$(sel),from=el._v||0;el._v=to;cancelAnimationFrame(el._r);
 if(reduce||from===to){el.innerHTML=fmt(to);return}
 const t0=performance.now(),step=t=>{const k=Math.min(1,(t-t0)/ms),e=1-Math.pow(1-k,3);el.innerHTML=fmt(from+(to-from)*e);if(k<1)el._r=requestAnimationFrame(step)};el._r=requestAnimationFrame(step)}
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('show'),3800)}

function perfChart(a,days,mode,b){perfData=null;const cut=days?Date.now()-days*864e5:0,L=a.filter(x=>!cut||new Date(x.d).getTime()>=cut).sort((x,y)=>x.d.localeCompare(y.d));
 if(!L.length)return empty(EMPTY_LINE,'Data tidak tersedia. Catat transaksi di Jurnal Trading.');
 const base=mode==='equity'?b:0;let c=base;const pts=[base,...L.map(x=>c+=x.r)],mn=Math.min(...pts),mx=Math.max(...pts),rg=(mx-mn)||1,W=600,H=230,pad=18;
 const X=i=>pad+i*(W-2*pad)/Math.max(pts.length-1,1),Y=v=>H-pad-(v-mn)/rg*(H-2*pad),col=mode==='equity'?'#6c8cff':'var(--brand)';
 const line=pts.map((v,i)=>`${i?'L':'M'}${X(i).toFixed(1)} ${Y(v).toFixed(1)}`).join(' ');
 perfData={pts,L,W,H,pad,X,Y,mode};
 return `<div class="pw${mode==='equity'?' eq':''}"><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Grafik ${mode==='equity'?'equity':'profit kumulatif'}"><line x1="${pad}" x2="${W-pad}" y1="${Y(base)}" y2="${Y(base)}" stroke="var(--line)" stroke-dasharray="4 4"/><path d="${line} L${X(pts.length-1)} ${Y(base)} L${X(0)} ${Y(base)}Z" fill="${col}" opacity=".12" stroke="none"/><path d="${line}" fill="none" stroke="${col}" stroke-width="2.5" vector-effect="non-scaling-stroke"/></svg><i class="vl" hidden></i><i class="dot" hidden></i><div class="tip" hidden></div></div>`}
/* nilai muncul saat grafik disorot */
const perfEl=$('#perf');
perfEl.addEventListener('pointermove',e=>{const d=perfData,w=perfEl.querySelector('.pw');if(!d||!w)return;
 const r=w.getBoundingClientRect(),n=d.pts.length-1,vx=(e.clientX-r.left)/r.width*d.W,i=Math.max(0,Math.min(n,Math.round((vx-d.pad)/(d.W-2*d.pad)*n)));
 const fx=d.X(i)/d.W,fy=d.Y(d.pts[i])/d.H,vl=w.querySelector('.vl'),dot=w.querySelector('.dot'),tip=w.querySelector('.tip'),t=d.L[i-1];
 vl.style.left=dot.style.left=tip.style.left=fx*100+'%';dot.style.top=tip.style.top=fy*100+'%';
 tip.innerHTML=i?`<b>${esc(t.d)}</b><span>${esc(t.p)} ${t.s==='SELL'?'Sell':'Buy'} · <em class="${cls(t.r)}">${money(t.r)}</em></span><span>${d.mode==='equity'?'Equity':'Profit kumulatif'}: <b>${money(d.pts[i])}</b></span>`:`<b>Titik awal</b><span>${d.mode==='equity'?'Saldo awal':'Mulai'}: <b>${money(d.pts[0])}</b></span>`;
 tip.style.transform=`translate(${fx<.2?'0':fx>.8?'-100%':'-50%'},${fy<.4?'16px':'calc(-100% - 14px)'})`;
 [vl,dot,tip].forEach(x=>x.hidden=false)});
perfEl.addEventListener('pointerleave',()=>perfEl.querySelectorAll('.vl,.dot,.tip').forEach(x=>x.hidden=true));

const COL=['#14c76a','#00b0ff','#ffb300','#ab47bc','#ff5252','#26c6da','#9ccc65','#8d6e63'];
function distChart(a){if(!a.length)return empty(EMPTY_PIE,'Data tidak tersedia.');
 const m={};a.forEach(x=>m[x.p]=(m[x.p]||0)+1);const ent=Object.entries(m).sort((x,y)=>y[1]-x[1]).slice(0,8),tot=ent.reduce((s,x)=>s+x[1],0);let off=0;
 const arcs=ent.map(([k,v],i)=>{const pc=v/tot*100,s=`<circle r="15.9155" cx="21" cy="21" fill="none" stroke="${COL[i]}" stroke-width="6" stroke-dasharray="${pc} ${100-pc}" stroke-dashoffset="${-off}" transform="rotate(-90 21 21)"><title>${esc(k)}: ${v} transaksi (${Math.round(pc)}%)</title></circle>`;off+=pc;return s}).join('');
 return `<div class="dn"><svg viewBox="0 0 42 42" role="img" aria-label="Distribusi instrumen">${arcs}<text x="21" y="22.2" text-anchor="middle" font-size="7" font-weight="700" fill="currentColor" stroke="none">${tot}</text><text x="21" y="26.8" text-anchor="middle" font-size="2.8" fill="var(--mut)" stroke="none">transaksi</text></svg><div class="legend">${ent.map(([k,v],i)=>`<span><i style="background:${COL[i]}"></i>${esc(k)} ${Math.round(v/tot*100)}%</span>`).join('')}</div></div>`}

/* ---------- lencana pencapaian ---------- */
const BIC={flag:'<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',check:'<path d="m5 12 5 5 9-10"/>',list:'<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',medal:'<circle cx="12" cy="9" r="5"/><path d="m9 13-2 8 5-3 5 3-2-8"/>',cal:I.cal,bolt:'<path d="M13 3 5 14h6l-1 7 8-11h-6z"/>',grid:'<rect x="4" y="4" width="7" height="7"/><rect x="13" y="4" width="7" height="7"/><rect x="4" y="13" width="7" height="7"/><rect x="13" y="13" width="7" height="7"/>',coin:I.acc,trophy:I.cup,target:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',shield:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="m9 12 2 2 4-4"/>'};
function badgeDefs(a,b){const n=a.length,wins=a.filter(x=>x.r>0).length,profit=a.reduce((s,x)=>s+x.r,0),days=new Set(a.map(x=>x.d)).size,pairs=new Set(a.map(x=>x.p)).size,wr=n?wins/n*100:0;
 let st=0,best=0;[...a].sort((x,y)=>x.d.localeCompare(y.d)).forEach(x=>{st=x.r>0?st+1:0;best=Math.max(best,st)});
 const calm=a.every(x=>x.r>=0||-x.r<=b*.02),c=(v,t)=>({ok:v>=t,p:Math.min(1,v/t),h:`${Math.min(Math.floor(v),t)}/${t}`}),pr=t=>({ok:profit>=t,p:Math.max(0,Math.min(1,profit/t)),h:`${money(Math.max(0,profit))} / ${money(t)}`});
 return [
  {id:'first',ic:'flag',n:'Langkah Pertama',d:'Catat transaksi pertama',...c(n,1)},
  {id:'green',ic:'check',n:'Hijau Pertama',d:'Raih 1 transaksi profit',...c(wins,1)},
  {id:'ten',ic:'list',n:'Konsisten 10',d:'Catat 10 transaksi',...c(n,10)},
  {id:'fifty',ic:'medal',n:'Veteran 50',d:'Catat 50 transaksi',...c(n,50)},
  {id:'days5',ic:'cal',n:'Rajin Mencatat',d:'Catat di 5 hari berbeda',...c(days,5)},
  {id:'streak3',ic:'bolt',n:'Tiga Beruntun',d:'3 transaksi profit berturut-turut',...c(best,3)},
  {id:'pairs3',ic:'grid',n:'Diversifikasi',d:'Trading 3 instrumen berbeda',...c(pairs,3)},
  {id:'p100',ic:'coin',n:'Profit $100',d:'Total profit mencapai $100',...pr(100)},
  {id:'p1000',ic:'trophy',n:'Profit $1.000',d:'Total profit mencapai $1.000',...pr(1000)},
  {id:'wr60',ic:'target',n:'Akurasi 60%',d:'Win rate 60%+ dari minimal 10 transaksi',ok:n>=10&&wr>=60,p:n>=10?Math.min(1,wr/60):n/10,h:n>=10?wr.toFixed(0)+'% / 60%':n+'/10 transaksi'},
  {id:'risk',ic:'shield',n:'Penjaga Risiko',d:'Min. 5 transaksi, tiap loss tidak lebih dari 2% saldo awal',ok:b>0&&n>=5&&calm,p:b>0&&calm?Math.min(1,n/5):0,h:b>0?(calm?n+'/5 transaksi':'Ada loss lebih dari 2%'):'Isi saldo awal dulu'}]}
function renderBadges(a,b){const defs=badgeDefs(a,b),got=defs.filter(x=>x.ok);
 $('#bCount').textContent=`${got.length}/${defs.length} terbuka`;
 $('#bGrid').innerHTML=defs.map(x=>`<div class="bd${x.ok?' on':''}"><i class="bi"><svg viewBox="0 0 24 24">${BIC[x.ic]}</svg></i><b>${esc(x.n)}</b><small>${esc(x.d)}</small><em>${x.ok?'✓ Terbuka':esc(x.h)}</em><span class="bp"><i style="width:${Math.round(x.p*100)}%"></i></span></div>`).join('');
 let seen=null;try{seen=JSON.parse(store.get(KBD))}catch(e){}
 const ids=got.map(x=>x.id);
 if(!Array.isArray(seen)){store.set(KBD,JSON.stringify(ids));return}
 const fresh=got.filter(x=>!seen.includes(x.id));
 if(fresh.length){store.set(KBD,JSON.stringify([...new Set([...seen,...ids])]));toast('🏆 Lencana baru: '+fresh[0].n+(fresh.length>1?` (+${fresh.length-1} lainnya)`:''))}}

function render(){const a=load(),b=bal(),n=a.length,profit=a.reduce((s,x)=>s+x.r,0),wins=a.filter(x=>x.r>0).length,wr=n?wins/n*100:0;
 animNum('#sEq',b+profit,money);$('#sEqN').textContent=n?(b?`Saldo awal ${money(b)}`:'Atur saldo awal di Jurnal Trading'):'Data belum tersedia';
 animNum('#sPr',profit,money);$('#sPr').className=cls(profit);$('#sPrN').textContent=n?`${wins} menang, ${n-wins} rugi/impas`:'Data belum tersedia';
 animNum('#sWr',wr,v=>v.toFixed(2)+'<span>%</span>');$('#sWrN').textContent=n?'Dari jurnal trading':'Data belum tersedia';
 animNum('#sTr',n,v=>String(Math.round(v)));$('#sTrN').textContent=n?'Dari jurnal trading':'Data belum tersedia';
 const pf=perfChart(a,+$('#range').value,perfMode,b),df=distChart(a);
 $('#perf').innerHTML=pf;$('#dist').innerHTML=df;
 $('#perf').style.display=$('#dist').style.display='';
 $('#bal').value=b||'';renderBadges(a,b);renderComplete();
 const rows=[...a].sort((x,y)=>y.d.localeCompare(x.d)).map(x=>`<tr><td>${esc(x.d)}</td><td>${esc(x.p)}</td><td>${x.s==='SELL'?'Sell':'Buy'}</td><td>${x.l}</td><td class="${cls(x.r)}">${money(x.r)}</td><td>${esc(x.n||'-')}</td><td><button class="x" data-id="${esc(x.id)}" aria-label="Hapus">✕</button></td></tr>`).join('');
 $('#jt tbody').innerHTML=rows;$('#jEmpty').hidden=n>0;$('#jt').parentElement.hidden=!n}
$('#range').onchange=render;
$$('.lg').forEach(b=>b.onclick=()=>{perfMode=b.dataset.m;$$('.lg').forEach(x=>{x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)});render()});


/* ---------- profil, akun, keamanan ---------- */
const KP='avatar:'+UID;
const fmtDate=iso=>{const d=new Date(iso);return isNaN(d)?'':d.toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'})};
function paintAvatar(){const p=store.get(KP),ok=p&&/^data:image\/jpeg;base64,[A-Za-z0-9+\/=]+$/.test(p);
 ['#pfAv','#av'].forEach(s=>{const e=$(s);e.style.backgroundImage=ok?`url("${p}")`:'';e.style.backgroundSize='cover';e.textContent=ok?'':initials});renderComplete()}
function paintNames(){initials=S.name.trim().slice(0,2).toUpperCase()||'?';
 $('#uName').textContent=$('#hName').textContent=$('#pfName').textContent=S.name;$('#pfMail').textContent=S.email||'';
 const d=S.created&&fmtDate(S.created);$('#pfSince').textContent=d?'Terdaftar sejak '+d:'';
 $('#vipState').textContent=ROLE;paintAvatar()}
$('#camBtn').onclick=()=>$('#photo').click();
$('#photo').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;
 if(!/^image\/(jpeg|png|webp)$/.test(f.type)||f.size>5*1024*1024)return alert('Pilih foto JPG, PNG, atau WebP maksimal 5 MB.');
 const img=new Image(),url=URL.createObjectURL(f);
 img.onload=()=>{const c=document.createElement('canvas'),n=256,s=Math.min(img.width,img.height);c.width=c.height=n;c.getContext('2d').drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,n,n);URL.revokeObjectURL(url);store.set(KP,c.toDataURL('image/jpeg',.85));paintAvatar()};
 img.onerror=()=>{URL.revokeObjectURL(url);alert('Foto tidak dapat dibaca.')};img.src=url};

const fm=(id,ok,t)=>{const e=$(id);e.className='fm '+(ok?'ok':'err');e.textContent=t||'';e.hidden=!t};
const noApi=(id,fn)=>{if(window.API&&typeof API[fn]==='function')return false;fm(id,false,'Fitur ini membutuhkan server Node.js FOR-X (auth.js versi baru).');return true};
async function prefillAkun(){$('#aName').value=S.name;$('#aMail').value=S.email||'';fm('#pMsg',true,'');fm('#wMsg',true,'');
 if(window.API&&API.refresh){const r=await API.refresh();if(r&&r.user)$('#aPhone').value=r.user.phone||''}}
$('#pForm').onsubmit=async e=>{e.preventDefault();if(noApi('#pMsg','updateProfile'))return;
 const r=await API.updateProfile({name:$('#aName').value.trim(),phone:$('#aPhone').value.trim()});
 if(!r.ok)return fm('#pMsg',false,r.error);S=API.user()||S;paintNames();fm('#pMsg',true,'Perubahan disimpan.')};
$('#wForm').onsubmit=async e=>{e.preventDefault();if(noApi('#wMsg','changePassword'))return;
 const cur=$('#wCur').value,pw=$('#wNew').value;
 if(!cur)return fm('#wMsg',false,'Masukkan kata sandi saat ini.');
 if(pw.length<8)return fm('#wMsg',false,'Kata sandi baru minimal 8 karakter.');
 if(pw!==$('#wNew2').value)return fm('#wMsg',false,'Konfirmasi kata sandi tidak sama.');
 const r=await API.changePassword(cur,pw);if(!r.ok)return fm('#wMsg',false,r.error);
 $('#wForm').reset();fm('#wMsg',true,'Kata sandi diubah. Perangkat lain telah dikeluarkan.')};
$('#outAll').onclick=async()=>{if(noApi('#kMsg','logoutAll'))return;if(!confirm('Keluar dari semua perangkat?'))return;await API.logoutAll();store.del('session');location.href='masuk.html'};

/* ---------- kelengkapan profil ---------- */
let PHONE='',REF='',REFD=0;
function renderComplete(){const n=load().length,items=[['Nama lengkap',true],['Alamat email',!!S.email],['Nomor telepon',!!PHONE,'#akun'],['Foto profil',!!store.get(KP),'photo'],['Saldo awal jurnal',bal()>0,'#jurnal'],['Transaksi pertama di jurnal',n>0,'#jurnal']];
 const done=items.filter(x=>x[1]).length,pct=Math.round(done/items.length*100);
 $('#cPct').textContent=pct+'%';$('#cBar').style.width=pct+'%';$('.ring').style.background=`conic-gradient(var(--brand) 0 ${pct}%,var(--line) 0)`;
 $('#cList').innerHTML=items.map(([t,ok,go])=>`<li class="${ok?'ok':''}"><i>${ok?'✓':''}</i><span>${t}</span>${ok?'':go==='photo'?'<button type="button" data-act="photo">Unggah ›</button>':`<a href="${go}">Lengkapi ›</a>`}</li>`).join('')}
$('#cList').onclick=e=>{if(e.target.closest('[data-act=photo]'))$('#photo').click()};

/* ---------- referal ---------- */
function renderRef(){$('#refCard').hidden=!REF;if(!REF)return;$('#refCode').textContent=REF;$('#refCnt').textContent=REFD?`${REFD} teman bergabung dengan kode Anda.`:'Belum ada teman yang bergabung.'}
async function copy(t){try{await navigator.clipboard.writeText(t);return true}catch(e){const x=document.createElement('textarea');x.value=t;document.body.appendChild(x);x.select();let ok=false;try{ok=document.execCommand('copy')}catch(_){}x.remove();return ok}}
$('#refCopy').onclick=async()=>toast(await copy(REF)?'Kode referal disalin.':'Tidak dapat menyalin.');
$('#refShare').onclick=async()=>{const url=`${location.origin}/masuk.html?ref=${encodeURIComponent(REF)}`;
 if(navigator.share){try{await navigator.share({title:'FOR-X',text:'Gabung komunitas trading FOR-X dengan kode referal saya.',url});return}catch(e){if(e.name==='AbortError')return}}
 toast(await copy(url)?'Link referal disalin.':'Tidak dapat menyalin.')};
async function loadExtra(){if(!(window.API&&API.refresh))return;const r=await API.refresh();
 if(r&&r.user){PHONE=r.user.phone||'';REF=r.user.referral||'';REFD=r.user.referred||0;S=API.user()||S;renderRef();renderComplete()}}

/* ---------- perangkat aktif ---------- */
async function loadSessions(){const ul=$('#sList');
 if(!(window.API&&API.sessions)){ul.innerHTML='<li class="mut">Daftar perangkat membutuhkan server Node.js FOR-X (auth.js versi baru).</li>';return}
 const r=await API.sessions();if(!r.ok){ul.innerHTML=`<li class="mut">${esc(r.error||'Gagal memuat.')}</li>`;return}
 const fmt=ms=>ms?new Date(ms).toLocaleString('id-ID',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}):'';
 ul.innerHTML=r.sessions.map(x=>`<li><i class="ri"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg></i><span><b>${esc(x.device)}${x.current?' <em class="tag">Perangkat ini</em>':''}</b><small>Masuk ${fmt(x.since)}</small></span>${x.current?'':`<button class="btn ghost sm" data-id="${esc(x.id)}" type="button">Keluarkan</button>`}</li>`).join('')||'<li class="mut">Tidak ada sesi.</li>'}
$('#sList').onclick=async e=>{const b=e.target.closest('[data-id]');if(!b)return;b.disabled=true;const r=await API.revokeSession(b.dataset.id);
 if(!r.ok){toast(r.error||'Gagal mengeluarkan perangkat.');b.disabled=false;return}toast('Perangkat dikeluarkan.');loadSessions()};

setTheme(store.get('theme')==='light'?'light':'dark');
paintNames();render();route();loadExtra();
