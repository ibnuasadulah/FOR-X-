/* Glossary: data + rendering. Loaded before app.js (uses $, T, lang from app.js at call time). */
const G=`Arbitrage|Memanfaatkan selisih harga aset yang sama di dua pasar untuk mengambil selisihnya.|Selisih harga biasanya sangat tipis dan cepat hilang, sehingga arbitrase butuh eksekusi sangat cepat. Contoh: aset dijual lebih murah di satu platform dan lebih mahal di platform lain pada saat yang sama.
Ask Price|Harga jual dari broker, yaitu harga yang kamu bayar saat membeli.|Di grafik, posisi buy dieksekusi di harga ask. Selisih antara ask dan bid disebut spread.
Bear Market|Kondisi pasar saat harga cenderung turun dalam waktu lama.|Biasanya disertai sentimen pesimis. Trader bisa mencari peluang jual (sell), tetapi tetap perlu manajemen risiko.
Bid Price|Harga beli dari broker, yaitu harga yang kamu terima saat menjual.|Posisi sell dieksekusi di harga bid. Bid selalu sedikit lebih rendah dari ask.
Bull Market|Kondisi pasar saat harga cenderung naik dalam waktu lama.|Ditandai oleh puncak dan lembah yang makin tinggi serta sentimen optimis.
Candlestick|Bentuk grafik yang menampilkan harga open, high, low, dan close.|Satu candle mewakili satu periode waktu. Badan candle menunjukkan selisih open dan close, sedangkan sumbu (wick) menunjukkan harga tertinggi dan terendah.
Cross Rate|Kurs dua mata uang yang dihitung lewat mata uang ketiga, biasanya dolar AS.|Misalnya kurs EUR/JPY dapat dihitung dari EUR/USD dan USD/JPY. Pair seperti ini juga disebut cross pair.
Day Trading|Gaya trading yang membuka dan menutup posisi dalam hari yang sama.|Posisi tidak ditahan semalam, sehingga terhindar dari biaya swap dan risiko gap antarhari. Konsekuensinya, trader harus aktif memantau pasar.
Drawdown|Penurunan nilai akun dari titik tertingginya.|Biasanya dinyatakan dalam persen. Drawdown besar butuh pemulihan yang lebih besar, misalnya turun 50% butuh naik 100% untuk kembali impas.
Equity|Nilai akun saat ini termasuk profit atau loss yang masih berjalan.|Equity = saldo + floating profit/loss.
Expert Advisor (EA)|Program otomatis yang membuka dan menutup posisi di MetaTrader.|Ia mengikuti aturan yang diprogram, tetapi tetap perlu diuji dan dipantau.
Fibonacci Retracement|Alat untuk memperkirakan level support dan resistance dari rasio Fibonacci.|Level yang sering dipakai adalah 38,2%, 50%, dan 61,8% dari satu ayunan harga. Anggap sebagai area perhatian, bukan kepastian.
Fundamental Analysis|Analisa nilai aset dari data ekonomi, berita, dan kebijakan.|Contohnya suku bunga, inflasi, dan data tenaga kerja. Sering dipadukan dengan analisa teknikal.
Gap|Celah harga antara penutupan sebelumnya dan pembukaan berikutnya.|Biasanya muncul setelah berita penting atau saat pasar libur lalu buka kembali.
Going Long|Membuka posisi beli dengan harapan harga naik.|Kebalikannya adalah going short, yaitu menjual lebih dulu. Posisi long untung jika harga naik di atas harga masuk.
Hawkish|Sikap bank sentral yang condong memperketat kebijakan untuk menekan inflasi.|Pernyataan hawkish biasanya memberi sinyal kenaikan suku bunga, yang cenderung menguatkan mata uang negara itu. Lawannya adalah dovish.
Hedging|Membuka posisi lawan untuk mengurangi risiko.|Contoh: memiliki posisi buy lalu membuka sell pada aset terkait untuk meredam kerugian. Biaya dan aturan broker perlu diperhatikan.
Indicator|Alat hitung berbasis harga atau volume untuk membantu analisa.|Contoh: moving average, RSI, MACD. Indikator membantu membaca kondisi pasar, bukan alat prediksi pasti.
Initial Margin|Dana minimum yang dibutuhkan untuk membuka satu posisi.|Besarnya bergantung pada ukuran lot dan leverage. Dana ini ditahan selama posisi terbuka.
Japanese Candlesticks|Gaya grafik candle yang berasal dari Jepang.|Kini menjadi format grafik paling umum karena menampilkan open, high, low, dan close sekaligus dalam satu bentuk.
Jobless Claims|Data mingguan jumlah warga AS yang mengajukan tunjangan pengangguran.|Angka yang naik menandakan pasar kerja melemah. Rilisnya sering menggerakkan dolar AS.
Kiwi|Sebutan populer untuk dolar Selandia Baru (NZD).|Pair NZD/USD sering disebut "kiwi", mengikuti nama burung maskot negara itu.
KYC (Know Your Customer)|Proses verifikasi identitas nasabah oleh broker.|Biasanya meminta dokumen identitas dan bukti alamat. Tujuannya mencegah penipuan dan pencucian uang.
Leverage|Pengganda daya beli yang memakai dana pinjaman broker.|Dengan leverage 1:100, modal 100 dolar bisa mengendalikan posisi sekitar 10.000 dolar. Profit dan loss ikut membesar, jadi gunakan dengan hati-hati.
Lot|Satuan ukuran posisi dalam trading.|Satu lot standar umumnya setara 100.000 unit mata uang dasar. Ada juga mini lot (0,1) dan micro lot (0,01).
Margin|Dana jaminan yang ditahan broker untuk membuka posisi.|Margin bukan biaya, tetapi dana yang dikunci selama posisi terbuka.
Margin Call|Peringatan saat dana akun tidak cukup menopang posisi.|Jika kerugian terus membesar, broker bisa menutup posisi otomatis (stop out). Jaga ukuran lot agar jauh dari kondisi ini.
NFP (Non-Farm Payrolls)|Data tenaga kerja Amerika Serikat yang dirilis tiap bulan.|Sering memicu pergerakan besar dan spread melebar di sekitar waktu rilis.
No Dealing Desk (NDD)|Model broker yang meneruskan order ke penyedia likuiditas tanpa meja dealer sendiri.|Tujuannya mengurangi konflik kepentingan dan requote. Spread biasanya mengambang dan kadang ada komisi.
Overbought|Kondisi saat harga dianggap sudah naik terlalu jauh dan terlalu cepat.|Indikator seperti RSI di atas 70 sering dibaca sebagai overbought. Harga tetap bisa naik, jadi jangan dipakai sendirian.
Oversold|Kondisi saat harga dianggap sudah turun terlalu jauh dan terlalu cepat.|RSI di bawah 30 sering dibaca sebagai oversold. Seperti overbought, ini bukan sinyal pasti pembalikan.
Pip|Satuan pergerakan harga terkecil pada banyak pair.|Pada pair seperti EUR/USD, 1 pip biasanya 0,0001. Pada pair yang memuat JPY, 1 pip biasanya 0,01.
Price Action|Analisa yang berfokus pada pergerakan harga itu sendiri dengan sedikit indikator.|Trader membaca pola candle, support-resistance, dan struktur tren langsung dari grafik.
Quantitative Easing (QE)|Bank sentral membeli aset untuk menambah jumlah uang beredar.|Dipakai saat ekonomi lesu untuk menurunkan suku bunga jangka panjang dan mendorong kredit. Efek sampingnya bisa melemahkan mata uang.
Quote Currency|Mata uang kedua dalam sebuah pair.|Pada EUR/USD, USD adalah quote currency; harga menunjukkan berapa USD untuk 1 EUR.
Resistance|Level harga yang sering menahan kenaikan.|Saat harga mendekati resistance, penjual cenderung muncul. Jika tertembus, level itu bisa menjadi support.
Risk/Reward Ratio|Perbandingan potensi rugi dengan potensi untung.|Jika risiko 10 pip dan target 30 pip, rasionya 1:3. Rasio yang baik membantu bertahan meski tidak semua transaksi menang.
Spread|Selisih antara harga bid dan ask.|Spread adalah biaya transaksi. Biasanya melebar saat likuiditas rendah atau ada berita besar.
Stop Loss|Level otomatis untuk menutup posisi saat rugi mencapai batas.|Stop loss membantu membatasi kerugian per transaksi. Tentukan sebelum membuka posisi.
Take Profit|Level otomatis untuk menutup posisi saat target untung tercapai.|Membantu mengamankan hasil tanpa harus memantau layar terus-menerus.
Technical Analysis|Analisa pergerakan harga dari grafik dan indikator.|Mengandalkan pola historis, tren, dan level harga untuk memperkirakan skenario.
Unemployment Rate|Persentase angkatan kerja yang menganggur dan sedang mencari pekerjaan.|Salah satu ukuran kesehatan ekonomi. Perubahan yang tak terduga bisa menggerakkan mata uang.
Uptrend|Tren naik: puncak dan lembah harga bergerak makin tinggi.|Trader tren biasanya mencari peluang beli saat harga terkoreksi di dalam uptrend.
Volatility|Seberapa besar dan cepat harga bergerak.|Volatilitas tinggi memberi peluang lebih besar, tetapi risikonya juga naik.
Volume|Jumlah transaksi dalam periode tertentu.|Volume tinggi saat breakout sering dianggap sebagai konfirmasi tambahan.
Whale|Sebutan untuk pemain bermodal sangat besar yang bisa menggerakkan harga.|Istilah ini populer di kripto, merujuk pada dompet atau institusi dengan kepemilikan besar.
Whipsaw|Harga bergerak tajam ke satu arah lalu cepat berbalik.|Kondisi ini sering memicu stop loss di kedua arah, terutama saat pasar sideways atau ada berita.
XAG/USD|Simbol harga satu ons perak dalam dolar AS.|XAG adalah kode perak. Harga dikuotasikan per troy ounce.
XAU/USD|Simbol harga satu ons emas dalam dolar AS.|XAU adalah kode emas. Salah satu instrumen paling populer dan sering dianggap aset safe haven.
Yen|Mata uang resmi Jepang (JPY).|Yen sering dianggap safe haven. Pair berisi JPY biasanya memakai dua angka desimal, jadi 1 pip = 0,01.
Yield|Imbal hasil dari suatu investasi, biasanya dalam persen per tahun.|Pada obligasi, yield naik saat harga turun. Selisih yield antarnegara memengaruhi arus modal dan kurs.
Z-Score|Ukuran statistik jarak sebuah nilai dari rata-rata, dalam satuan simpangan baku.|Dipakai, misalnya, untuk melihat seberapa ekstrem harga dibanding rata-ratanya.
Zero-Sum Game|Situasi saat untung satu pihak sama dengan rugi pihak lain.|Dalam praktik, trading justru negative-sum karena spread dan komisi dibayar oleh semua pihak.`.split('\n').map(l=>l.split('|')).sort((a,b)=>a[0].localeCompare(b[0]));
const AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
function renderGl(){
 const q='',L=T[lang];
 const list=G.filter(g=>!q||(g[0]+' '+g[1]).toLowerCase().includes(q));
 const has=new Set(list.map(g=>g[0][0].toUpperCase()));
 $('#alpha').innerHTML=AZ.map(l=>`<button class="al" data-l="${l}" ${has.has(l)?'':'disabled'}>${l}</button>`).join('');
 $('#gl').innerHTML=AZ.filter(l=>has.has(l)).map(l=>`<div class="gsec" id="g-${l}"><div class="ghead"><span class="badge">${l}</span><i></i></div><div class="ggrid">${list.filter(g=>g[0][0].toUpperCase()===l).map(g=>`<div class="gcard" tabindex="0" role="button" data-t="${G.indexOf(g)}"><h3>${g[0]}</h3><p>${g[1]}</p><div class="gmore">${L.more} →</div></div>`).join('')}</div></div>`).join('')||`<p>${L.none}</p>`}
let gd;
const slug=s=>s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
function openG(i,fromHash){const g=G[i];$('#gdL').textContent=g[0][0].toUpperCase();$('#gdT').textContent=g[0];$('#gdS').textContent=g[1];$('#gdD').textContent=g[2];
 if(!gd.open){if(gd.showModal)gd.showModal();else gd.setAttribute('open','')}
 if(!fromHash)location.hash=slug(G[i][0])}
function showFromHash(){const h=decodeURIComponent(location.hash.slice(1)),i=G.findIndex(x=>slug(x[0])===h);if(i>=0)openG(i,true);else if(gd.open)gd.close()}
function initGl(){
gd=$('#gd');
gd.addEventListener('close',()=>{if(location.hash)try{history.replaceState(null,'',location.pathname+location.search)}catch(e){location.hash=''}});
addEventListener('hashchange',showFromHash);
$('#alpha').onclick=e=>{const b=e.target.closest('.al');if(b&&!b.disabled)$('#g-'+b.dataset.l).scrollIntoView()};
$('#gl').onclick=e=>{const c=e.target.closest('.gcard');if(c)openG(+c.dataset.t)};
$('#gl').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){const c=e.target.closest('.gcard');if(c){e.preventDefault();openG(+c.dataset.t)}}};
const closeG=()=>gd.close?gd.close():gd.removeAttribute('open');
$('#gdX').onclick=closeG;$('#gdC').onclick=closeG;gd.onclick=e=>{if(e.target===gd)closeG()};

showFromHash();
}
