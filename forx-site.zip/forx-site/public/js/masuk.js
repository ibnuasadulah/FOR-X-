/* Halaman Masuk & Daftar: tab login/daftar, validasi, kirim ke /api, tema, bahasa */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let lang=store.get('lang')||'id',mode='reg',busy=false;
const esc=s=>String(s).replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));
const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',
 wel:'Selamat Datang di',sub:'Komunitas trading terpadu dengan edukasi, sinyal, dan alat analisis modern.',tL:'Masuk Akun',tR:'Daftar Baru',
 lName:'Nama Lengkap',lEmail:'Alamat Email',lPhone:'Nomor Telepon / WhatsApp',lRef:'Kode Referal',opt:'(opsional)',refHint:'Masukkan kode referal teman atau mentor Anda jika ada.',lPass:'Kata Sandi',lConf:'Konfirmasi Sandi',
 phName:'Nama Lengkap Anda',phEmail:'nama@email.com',phPhone:'08xxxxxxxxxx atau 628xxxxxxxxxx',phRef:'CONTOH: FX89A2K4',phPass:'Min. 8 karakter',phConf:'Ulangi sandi',phPassL:'Masukkan kata sandi',
 forgot:'Lupa kata sandi? Hubungi admin',terms:'Saya telah membaca dan menyetujui <a href="syarat.html" target="_blank" rel="noopener">Syarat &amp; Ketentuan</a> serta <a href="privasi.html" target="_blank" rel="noopener">Kebijakan Privasi</a> FOR-X.',
 subReg:'Buat Akun FOR-X Sekarang',subLogin:'Masuk ke Akun',wait:'Memproses…',
 swRegQ:'Sudah memiliki akun?',swRegA:'Masuk di Sini',swLoginQ:'Belum punya akun?',swLoginA:'Daftar di Sini',
 help:'Ada kendala saat mendaftar? Hubungi kami via email di',
 eName:'Nama lengkap wajib diisi.',eEmail:'Masukkan alamat email yang valid.',ePhone:'Nomor telepon/WhatsApp tidak valid. Contoh: 08123456789.',ePass:'Kata sandi minimal 8 karakter.',ePassL:'Masukkan kata sandi.',eConf:'Konfirmasi sandi tidak sama.',eTerms:'Centang persetujuan Syarat & Ketentuan terlebih dahulu.',
 okReg:'Akun berhasil dibuat! Mengarahkan Anda…',okLogin:'Berhasil masuk! Mengarahkan Anda…',
 doneH:'Anda sudah masuk',doneP:'Masuk sebagai {n}.',doneGo:'Ke Akun Saya',doneOut:'Keluar',show:'Tampilkan sandi',hide:'Sembunyikan sandi'},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',
 wel:'Welcome to',sub:'An all-in-one trading community with education, signals, and modern analysis tools.',tL:'Log In',tR:'Sign Up',
 lName:'Full Name',lEmail:'Email Address',lPhone:'Phone / WhatsApp Number',lRef:'Referral Code',opt:'(optional)',refHint:'Enter your friend\'s or mentor\'s referral code, if you have one.',lPass:'Password',lConf:'Confirm Password',
 phName:'Your full name',phEmail:'name@email.com',phPhone:'08xxxxxxxxxx or 628xxxxxxxxxx',phRef:'EXAMPLE: FX89A2K4',phPass:'Min. 8 characters',phConf:'Repeat password',phPassL:'Enter your password',
 forgot:'Forgot password? Contact admin',terms:'I have read and agree to the <a href="syarat.html" target="_blank" rel="noopener">Terms &amp; Conditions</a> and <a href="privasi.html" target="_blank" rel="noopener">Privacy Policy</a> of FOR-X.',
 subReg:'Create My FOR-X Account',subLogin:'Log In',wait:'Please wait…',
 swRegQ:'Already have an account?',swRegA:'Log in here',swLoginQ:'Don\'t have an account?',swLoginA:'Sign up here',
 help:'Having trouble signing up? Email us at',
 eName:'Full name is required.',eEmail:'Enter a valid email address.',ePhone:'Invalid phone/WhatsApp number. Example: 08123456789.',ePass:'Password must be at least 8 characters.',ePassL:'Enter your password.',eConf:'Passwords do not match.',eTerms:'Please accept the Terms & Conditions first.',
 okReg:'Account created! Redirecting…',okLogin:'Logged in! Redirecting…',
 doneH:'You are already logged in',doneP:'Logged in as {n}.',doneGo:'Go to My Account',doneOut:'Log out',show:'Show password',hide:'Hide password'}};
const ICON={reg:'<path d="M15 20v-1a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v1M8.500 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM19 8v6M22 11h-6"/>',login:'<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/>'};
/* tujuan setelah berhasil: hanya nama file .html di situs ini (tolak alamat luar) */
const NEXT=(()=>{const n=new URLSearchParams(location.search).get('next')||'';return /^[a-z0-9_-]+\.html(#[a-z0-9_-]+)?$/i.test(n)?n:'dashboard.html'})();

function msg(type,text){const d=document.createElement('div');d.className='msg '+type;d.textContent=text;$('#fmsg').replaceChildren(d)}
function clearErr(){$('#fmsg').replaceChildren();$$('#auForm input').forEach(i=>i.removeAttribute('aria-invalid'));$('.chk').classList.remove('bad')}
function bad(id,text){clearErr();const i=$('#'+id);if(i)i.setAttribute('aria-invalid','true');msg('err',text);if(i)i.focus()}

function setMode(m,push){mode=m;const L=T[lang],reg=m==='reg';
 $('#tL').setAttribute('aria-selected',!reg);$('#tR').setAttribute('aria-selected',reg);
 $$('[data-only]').forEach(e=>{const on=e.dataset.only===(reg?'reg':'login');e.hidden=!on;e.querySelectorAll('input').forEach(i=>i.disabled=!on)});
 $('.f2').classList.toggle('one',!reg);
 $('#fw').autocomplete=reg?'new-password':'current-password';$('#fw').placeholder=reg?L.phPass:L.phPassL;
 $('#fsubT').textContent=reg?L.subReg:L.subLogin;$('#fsubI').innerHTML=ICON[reg?'reg':'login'];
 $('#swQ').textContent=reg?L.swRegQ:L.swLoginQ;$('#swA').textContent=reg?L.swRegA:L.swLoginA;$('#swA').setAttribute('href',reg?'#masuk':'#daftar');
 clearErr();
 if(push)try{history.replaceState(null,'',location.pathname+location.search+(reg?'#daftar':''))}catch(e){}}
$('#tL').onclick=()=>setMode('login',true);$('#tR').onclick=()=>setMode('reg',true);
$('#swA').onclick=e=>{e.preventDefault();setMode(mode==='reg'?'login':'reg',true)};
addEventListener('hashchange',()=>setMode(location.hash==='#daftar'?'reg':'login'));

/* tombol mata (lihat/sembunyikan sandi) */
$$('.eye').forEach(b=>b.onclick=()=>{const i=$('#'+b.dataset.for),show=i.type==='password';i.type=show?'text':'password';b.classList.toggle('on',show);b.setAttribute('aria-label',T[lang][show?'hide':'show'])});
$('#fr').oninput=e=>{e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'')};

/* kirim */
$('#auForm').onsubmit=async e=>{e.preventDefault();if(busy)return;const L=T[lang];clearErr();
 const email=$('#fe').value.trim(),pw=$('#fw').value;
 if(!/^\S+@\S+\.\S+$/.test(email))return bad('fe',L.eEmail);
 let r;
 if(mode==='login'){
  if(!pw)return bad('fw',L.ePassL);
  busy=true;$('#fsub').disabled=true;$('#fsubT').textContent=L.wait;
  r=await API.login(email.toLowerCase(),pw)}
 else{
  const name=$('#fn').value.trim(),phone=$('#fp').value.trim();
  if(name.length<2)return bad('fn',L.eName);
  if(!/^(\+?62|0)?8\d{7,13}$/.test(phone.replace(/[\s\-().]/g,'')))return bad('fp',L.ePhone);
  if(pw.length<8)return bad('fw',L.ePass);
  if($('#fc').value!==pw)return bad('fc',L.eConf);
  if(!$('#ft').checked){clearErr();$('.chk').classList.add('bad');msg('err',L.eTerms);return}
  busy=true;$('#fsub').disabled=true;$('#fsubT').textContent=L.wait;
  r=await API.register({name,email:email.toLowerCase(),password:pw,phone,referral:$('#fr').value.trim(),terms:true})}
 busy=false;$('#fsub').disabled=false;setMode(mode);
 if(!r.ok){if(/referal|referral/i.test(r.error))$('#fr').setAttribute('aria-invalid','true');return msg('err',r.error)}
 msg('ok',mode==='reg'?L.okReg:L.okLogin);$('#fsub').disabled=true;
 setTimeout(()=>{location.href=NEXT},700)};

/* sudah login? tampilkan kartu ringkas, bukan form */
function showDone(u){const L=T[lang];$('#auCard').hidden=!!u;$('#auDone').hidden=!u;if(!u)return;
 $('#doneH').textContent=L.doneH;$('#doneP').textContent=L.doneP.replace('{n}',u.name);$('#doneGo').textContent=L.doneGo;$('#doneGo').href=NEXT;$('#doneOut').textContent=L.doneOut}
$('#doneOut').onclick=async()=>{await API.logout();renderAuth();showDone(null);setMode('login')};
function onAuthChange(u){showDone(u)}

/* auth (navbar) */
const user=()=>API.user();
function renderAuth(){const s=user();
 $('#auth').innerHTML=s&&s.name?`<a class="btn pill ghost" href="dashboard.html">${esc(s.name)}</a>`:`<a class="btn pill ghost" href="masuk.html">${T[lang].login}</a> <a class="btn pill primary" href="masuk.html#daftar">${T[lang].join} →</a>`}
$('#auth').addEventListener('click',e=>{const a=e.target.closest('a');if(!a||!/masuk\.html/.test(a.getAttribute('href')||''))return;e.preventDefault();setMode(a.getAttribute('href').includes('#daftar')?'reg':'login',true);window.scrollTo(0,0)});

/* i18n */
function applyLang(){const L=T[lang];
 $$('[data-i]').forEach(e=>{if(L[e.dataset.i]!==undefined)e.textContent=L[e.dataset.i]});
 $$('[data-ph]').forEach(e=>e.placeholder=L[e.dataset.ph]);
 $('#tTxt').innerHTML=L.terms;
 $('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;
 renderAuth();setMode(mode);showDone(user())}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
/* theme */
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')||'dark');
function switchTheme(){const d=document.documentElement,n=d.dataset.theme==='dark'?'light':'dark';
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){setTheme(n);return}
 if(document.startViewTransition){document.startViewTransition(()=>setTheme(n));return}
 d.classList.add('theme-anim');setTheme(n);setTimeout(()=>d.classList.remove('theme-anim'),500)}
$('#theme').onclick=switchTheme;
/* menu */
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.onclick=e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')};
/* awal: ?ref=KODE mengisi kode referal; #daftar atau ?ref membuka tab daftar, selain itu tab masuk */
const REF=(new URLSearchParams(location.search).get('ref')||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,20);
if(REF)$('#fr').value=REF;
mode=(location.hash==='#daftar'||REF)?'reg':'login';
applyLang();
