/* kontak.html: info kontak, topik bantuan, form pesan (-> API.contact), FAQ, tema, bahasa, menu */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
const esc=s=>String(s).replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));
let lang=store.get('lang')||'id';

/* ====== UBAH DI SINI: data kontak resmi ====== */
const CONTACT={email:'support@forxtrading.com',telegramUrl:'https://t.me/forxtraderindo',telegramLabel:'@forxtraderindo'};

const T={
id:{home:'Beranda',about:'Tentang',services:'Layanan',articles:'Artikel',portfolio:'Portofolio',glossary:'Glosarium',login:'Masuk',join:'Daftar Sekarang',
 kBadge:'PUSAT BANTUAN',kH1:'Hubungi',kH2:'Kami',kSub:'Punya pertanyaan seputar membership, program IB Training, atau ingin berkolaborasi? Kami siap menyambut Anda.',
 iT:'Informasi Kontak Resmi',iP:'Silakan hubungi tim kami melalui saluran resmi di bawah ini. Kami akan membalas pertanyaan Anda secepat mungkin dalam 1x24 jam kerja.',iEm:'EMAIL RESMI',iTg:'TELEGRAM RESMI',cp:'Salin',
 cT:'Kirim Email Langsung',cP:'Klik tombol di bawah untuk langsung membuka aplikasi email Anda dan mengirim pertanyaan.',cB:'Tulis Email Sekarang',cB2:'Atau chat via Telegram',
 tT:'Pilih topik bantuan',tP:'Pilih salah satu, formulirnya akan terisi otomatis.',ask:'Tanyakan ›',
 t1T:'Keanggotaan VVIP',t1P:'Paket, fasilitas, dan cara bergabung.',t2T:'Partnership IB',t2P:'Pelatihan IB dan kerja sama partner.',t3T:'Kendala Akun',t3P:'Masuk, daftar, atau lupa kata sandi.',
 fT:'Kirim Pesan',fP:'Isi formulir ini dan tim kami akan membalas lewat email.',fN:'Nama',fE:'Email',fTp:'Topik',fM:'Pesan',fB:'Kirim Pesan',
 o1:'Pertanyaan umum',o2:'Keanggotaan VVIP',o3:'Partnership IB',o4:'Kendala akun',o5:'Lainnya',
 qT:'Pertanyaan Umum',qP:'Jawaban singkat untuk hal yang sering ditanyakan.',
 eN:'Nama wajib diisi.',eE:'Masukkan email yang valid.',eM:'Pesan minimal 10 karakter.',sending:'Mengirim…',ok:'Terima kasih! Pesan Anda sudah kami terima dan akan segera dibalas.',noapi:'Layanan pesan belum tersedia. Silakan kirim lewat email.',copied:'Disalin ✓',mailSub:'Pertanyaan dari website FOR-X',
 risk:'Trading berisiko dan dapat menyebabkan kerugian modal. Tidak ada jaminan profit.',
 faq:[['Bagaimana cara bergabung VVIP?','Buka halaman VVIP Signal, lihat paket dan fasilitasnya, lalu ikuti langkah pendaftaran. Untuk pertanyaan seputar pembayaran, kirim pesan lewat formulir ini atau Telegram.'],
  ['Saya lupa kata sandi, bagaimana?','Saat ini reset kata sandi dibantu oleh admin. Hubungi kami lewat email atau Telegram dan sebutkan alamat email akun Anda.'],
  ['Bagaimana cara menjadi partner IB?','Pelajari program di halaman IB Training, lalu hubungi tim partnership lewat Telegram atau formulir ini dengan topik Partnership IB.'],
  ['Di mana saya menemukan kode referal?','Masuk ke dashboard, buka Profil Saya, lalu Pengaturan Akun. Kode referal Anda ada di bagian paling atas.'],
  ['Apakah ada jaminan profit?','Tidak ada. Trading berisiko dan dapat menyebabkan kerugian modal. Seluruh materi kami bersifat edukasi, bukan ajakan membeli atau menjual.']]},
en:{home:'Home',about:'About',services:'Services',articles:'Articles',portfolio:'Portfolio',glossary:'Glossary',login:'Log in',join:'Join Now',
 kBadge:'HELP CENTER',kH1:'Contact',kH2:'Us',kSub:'Questions about membership, the IB Training program, or want to collaborate? We are ready to hear from you.',
 iT:'Official Contact Information',iP:'Reach our team through the official channels below. We will reply as soon as possible, within 1 business day.',iEm:'OFFICIAL EMAIL',iTg:'OFFICIAL TELEGRAM',cp:'Copy',
 cT:'Send an Email Directly',cP:'Click the button below to open your email app and send your question.',cB:'Write an Email Now',cB2:'Or chat on Telegram',
 tT:'Choose a help topic',tP:'Pick one and the form fills in automatically.',ask:'Ask now ›',
 t1T:'VVIP Membership',t1P:'Plans, benefits, and how to join.',t2T:'IB Partnership',t2P:'IB training and partner cooperation.',t3T:'Account Issues',t3P:'Log in, sign up, or forgotten password.',
 fT:'Send a Message',fP:'Fill in this form and our team will reply by email.',fN:'Name',fE:'Email',fTp:'Topic',fM:'Message',fB:'Send Message',
 o1:'General question',o2:'VVIP membership',o3:'IB partnership',o4:'Account issue',o5:'Other',
 qT:'Frequently Asked Questions',qP:'Short answers to common questions.',
 eN:'Name is required.',eE:'Enter a valid email.',eM:'Message must be at least 10 characters.',sending:'Sending…',ok:'Thank you! We received your message and will reply soon.',noapi:'The message service is unavailable. Please email us instead.',copied:'Copied ✓',mailSub:'Question from the FOR-X website',
 risk:'Trading involves risk and can result in loss of capital. No profit is guaranteed.',
 faq:[['How do I join VVIP?','Open the VVIP Signal page, review the plan and benefits, then follow the sign-up steps. For payment questions, message us through this form or Telegram.'],
  ['I forgot my password. What now?','Password resets are currently handled by an admin. Contact us by email or Telegram and mention your account email address.'],
  ['How do I become an IB partner?','Read about the program on the IB Training page, then contact the partnership team on Telegram or through this form with the IB Partnership topic.'],
  ['Where do I find my referral code?','Log in to the dashboard, open My Profile, then Account Settings. Your referral code is at the top.'],
  ['Is profit guaranteed?','No. Trading carries risk and can lead to loss of capital. All our material is educational, not a call to buy or sell.']]}};

/* ---------- isi halaman ---------- */
function render(){const L=T[lang];
 $$('[data-i]').forEach(e=>{if(L[e.dataset.i]!==undefined)e.innerHTML=L[e.dataset.i]});
 $('#kEmail').textContent=CONTACT.email;$('#kTg').textContent=CONTACT.telegramLabel;
 $('#kMail').href=`mailto:${CONTACT.email}?subject=${encodeURIComponent(L.mailSub)}`;
 $('#kTgBtn').href=CONTACT.telegramUrl;
 $('#faq').innerHTML=L.faq.map(([q,a])=>`<details name="faq"><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}

/* salin email / telegram */
function toast(m){let t=$('.toast-kt');if(!t){t=document.createElement('div');t.className='toast-kt';t.setAttribute('role','status');document.body.appendChild(t)}t.textContent=m;t.classList.add('show');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('show'),1800)}
async function copy(t){try{await navigator.clipboard.writeText(t);return true}catch(e){const x=document.createElement('textarea');x.value=t;document.body.appendChild(x);x.select();let ok=false;try{ok=document.execCommand('copy')}catch(_){}x.remove();return ok}}
document.addEventListener('click',async e=>{const b=e.target.closest('[data-copy]');if(!b)return;
 const ok=await copy(b.dataset.copy==='email'?CONTACT.email:CONTACT.telegramLabel);toast(ok?T[lang].copied:'—')});

/* kartu topik -> isi form */
function pickTopic(t){const sel=$('#kt');if([...sel.options].some(o=>o.value===t))sel.value=t;$('#pesan').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth',block:'start'});setTimeout(()=>($('#kn').value?$('#kx'):$('#kn')).focus({preventScroll:true}),450)}
$$('.kt-tp').forEach(b=>b.onclick=()=>pickTopic(b.dataset.topic));
const qt=new URLSearchParams(location.search).get('topik');if(qt&&[...$('#kt').options].some(o=>o.value===qt))$('#kt').value=qt;

/* form */
$('#kx').addEventListener('input',()=>$('#kCnt').textContent=$('#kx').value.length+'/2000');
$('#kForm').addEventListener('input',e=>e.target.removeAttribute('aria-invalid'));
const say=(c,t)=>{const m=$('#kSt');if(!t){m.replaceChildren();return}const d=document.createElement('div');d.className='m '+c;d.textContent=t;m.replaceChildren(d)};
const bad=(id,t)=>{$$('#kForm [aria-invalid]').forEach(i=>i.removeAttribute('aria-invalid'));$('#'+id).setAttribute('aria-invalid','true');$('#'+id).focus();say('err',t)};
$('#kForm').onsubmit=async e=>{e.preventDefault();const L=T[lang],btn=$('#kSend');say('',''); 
 const d={name:$('#kn').value.trim(),email:$('#ke').value.trim(),topic:$('#kt').value,message:$('#kx').value.trim(),website:$('#kw').value};
 if(d.name.length<2)return bad('kn',L.eN);
 if(!/^\S+@\S+\.\S+$/.test(d.email))return bad('ke',L.eE);
 if(d.message.length<10)return bad('kx',L.eM);
 if(!(window.API&&typeof API.contact==='function'))return say('err',L.noapi);
 btn.disabled=true;btn.textContent=L.sending;
 const r=await API.contact(d);btn.disabled=false;btn.textContent=L.fB;
 if(!r.ok)return say('err',r.error||L.noapi);
 $('#kx').value='';$('#kCnt').textContent='0/2000';$$('#kForm [aria-invalid]').forEach(i=>i.removeAttribute('aria-invalid'));say('ok',L.ok)};
/* isi nama/email otomatis kalau sudah login */
try{const u=window.API&&API.user&&API.user();if(u){if(u.name)$('#kn').value=u.name;if(u.email)$('#ke').value=u.email}}catch(e){}

/* animasi muncul saat di-scroll */
function reveal(){const els=$$('.rv');if(!('IntersectionObserver' in window)||matchMedia('(prefers-reduced-motion:reduce)').matches){els.forEach(e=>e.classList.add('in'));return}
 const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.12});
 els.forEach((e,i)=>{e.style.transitionDelay=(i%3)*80+'ms';io.observe(e)})}

/* ---------- navbar: masuk / tema / bahasa / menu (sama seperti halaman lain) ---------- */
const user=()=>{try{return JSON.parse(store.get('session'))}catch(e){return null}};
function renderAuth(){const s=user(),L=T[lang];
 $('#auth').innerHTML=s&&s.name?`<a class="btn pill ghost" href="dashboard.html">${esc(s.name)}</a>`:`<a class="btn pill ghost" href="masuk.html">${L.login}</a> <a class="btn pill primary" href="masuk.html#daftar">${L.join} →</a>`}
function applyLang(){render();$('#langTxt').textContent=lang.toUpperCase();$('#flag').dataset.l=lang;document.documentElement.lang=lang;renderAuth()}
$('#lang').onclick=()=>{lang=lang==='id'?'en':'id';store.set('lang',lang);applyLang()};
function setTheme(t){document.documentElement.dataset.theme=t;store.set('theme',t);$('#theme').textContent=t==='dark'?'☀':'☾'}
setTheme(store.get('theme')||'dark');
function switchTheme(){const d=document.documentElement,n=d.dataset.theme==='dark'?'light':'dark';
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){setTheme(n);return}
 if(document.startViewTransition){document.startViewTransition(()=>setTheme(n));return}
 d.classList.add('theme-anim');setTheme(n);setTimeout(()=>d.classList.remove('theme-anim'),500)}
$('#theme').onclick=switchTheme;
$('#burger').onclick=()=>{const o=$('#links').classList.toggle('show');$('#burger').setAttribute('aria-expanded',o);$('#burger').textContent=o?'✕':'☰'};
$('#ddb').onclick=e=>{e.stopPropagation();const o=$('#dd').classList.toggle('open');$('#ddb').setAttribute('aria-expanded',o)};
document.addEventListener('click',e=>{if(!e.target.closest('#dd'))$('#dd').classList.remove('open')});
applyLang();reveal();
