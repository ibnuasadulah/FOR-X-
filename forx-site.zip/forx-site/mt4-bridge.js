'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const DATA=path.join(__dirname,'data');fs.mkdirSync(DATA,{recursive:true});
const STATE_FILE=path.join(DATA,'mt4-bridge-state.json'),COMMAND_FILE=path.join(DATA,'mt4-commands.json'),LOG_FILE=path.join(DATA,'mt4-audit.jsonl');
const read=(f,d)=>{try{return JSON.parse(fs.readFileSync(f,'utf8'))}catch(e){return d}};
const write=(f,v)=>{const t=f+'.tmp';fs.writeFileSync(t,JSON.stringify(v));fs.renameSync(t,f)};
const token=()=>String(process.env.MT4_BRIDGE_TOKEN||'');
const expectedLogin=()=>String(process.env.MT4_EXPECTED_LOGIN||'').trim();
const expectedServer=()=>String(process.env.MT4_EXPECTED_SERVER||'').trim();
const maxLot=()=>{const n=Number(process.env.MT4_MAX_LOT||0.10);return Number.isFinite(n)&&n>=0.01?Math.min(n,100):0.10};
const allowedSymbols=()=>String(process.env.MT4_ALLOWED_SYMBOLS||'XAUUSD,EURUSD,GBPUSD,USDJPY,AUDUSD,USDCAD').split(',').map(x=>x.trim().toUpperCase()).filter(Boolean);
const maxPositions=()=>{const n=Number(process.env.MT4_MAX_OPEN_POSITIONS||5);return Number.isInteger(n)&&n>=1?Math.min(n,100):5};
const noStore={'Cache-Control':'no-store'};
function reply(res,code,obj){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8',...noStore,'X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(obj));}
function body(req,limit=65536){return new Promise((resolve,reject)=>{let n=0,a=[];req.on('data',c=>{n+=c.length;if(n>limit){reject({code:413,error:'Payload terlalu besar.'});req.destroy()}else a.push(c)});req.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(a).toString('utf8')||'{}'))}catch(e){reject({code:400,error:'JSON tidak valid.'})}});req.on('error',()=>reject({code:400,error:'Permintaan gagal.'}))})}
function audit(action,details={}){try{fs.appendFileSync(LOG_FILE,JSON.stringify({at:new Date().toISOString(),action,...details})+'\n')}catch(e){}}
function state(){return read(STATE_FILE,{connected:false,account:null,positions:[],lastSeen:0});}
function commands(){return read(COMMAND_FILE,[]);}
function saveCommands(a){write(COMMAND_FILE,a.slice(-200));}
function revokeUser(email){const a=commands();let n=0;for(const c of a){if(c.requestedBy===email&&c.status==='pending'){c.status='cancelled';c.error='Akses trader dicabut sebelum perintah dikirim.';n++;}}saveCommands(a);if(n)audit('pending-commands-cancelled',{email,count:n});return n;}
function configured(){return !!(token()&&expectedLogin()&&expectedServer());}
function safeEqual(a,b){const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&crypto.timingSafeEqual(x,y)}
function bridgeAuth(req){const h=String(req.headers.authorization||'');return configured()&&h.startsWith('Bearer ')&&safeEqual(h.slice(7),token());}
function trader(req,ctx){const u=ctx.currentUser(req);return u&&(u.role==='admin'||u.role==='trader')?u:null;}
function sameOrigin(req,ctx){return ctx.sameOrigin?ctx.sameOrigin():true;}
function validAccount(b){return String(b.login||'')===expectedLogin()&&String(b.server||'')===expectedServer();}
function cleanPositions(p){if(!Array.isArray(p))return [];return p.slice(0,100).map(x=>({ticket:Number(x.ticket)||0,symbol:String(x.symbol||'').slice(0,20),type:Number(x.type)||0,lots:Number(x.lots)||0,openPrice:Number(x.openPrice)||0,sl:Number(x.sl)||0,tp:Number(x.tp)||0,profit:Number(x.profit)||0,swap:Number(x.swap)||0,commission:Number(x.commission)||0,openTime:Number(x.openTime)||0})).filter(x=>x.ticket>0&&x.symbol);}
async function handle(req,res,url,ctx){
 const ep=url.pathname;
 try{
  if(ep==='/api/mt4/bridge/heartbeat'&&req.method==='POST'){
   if(!bridgeAuth(req))return reply(res,401,{ok:false,error:'Bridge tidak terautentikasi atau konfigurasi belum lengkap.'});
   const b=await body(req);if(!validAccount(b))return reply(res,403,{ok:false,error:'Akun atau server MT4 tidak sesuai konfigurasi FOR-X.'});
   const account={login:String(b.login),server:String(b.server),currency:String(b.currency||'').slice(0,8),company:String(b.company||'').slice(0,80),name:String(b.name||'').slice(0,80),leverage:Number(b.leverage)||0,balance:Number(b.balance)||0,equity:Number(b.equity)||0,margin:Number(b.margin)||0,freeMargin:Number(b.freeMargin)||0,profit:Number(b.profit)||0};
   const st={connected:true,account,positions:cleanPositions(b.positions),lastSeen:Date.now(),terminalVersion:String(b.terminalVersion||'').slice(0,30)};write(STATE_FILE,st);return reply(res,200,{ok:true,serverTime:Date.now()});
  }
  if(ep==='/api/mt4/bridge/next'&&req.method==='GET'){
   if(!bridgeAuth(req))return reply(res,401,{ok:false,error:'Bridge tidak terautentikasi.'});
   const st=state();if(!st.lastSeen||Date.now()-st.lastSeen>20000||!st.account||st.account.login!==expectedLogin()||st.account.server!==expectedServer())return reply(res,409,{ok:false,error:'Akun MT4 belum terhubung.'});
   const a=commands();let c=a.find(x=>x.status==='pending');if(!c){const stale=a.find(x=>x.status==='sent'&&Date.now()-(x.sentAt||0)>25000);if(stale){if((stale.attempts||0)>=2){stale.status='failed';stale.error='Tidak ada konfirmasi dari terminal MT4.'}else{stale.status='pending';stale.attempts=(stale.attempts||0)+1}}c=a.find(x=>x.status==='pending')}
   if(!c){saveCommands(a);return reply(res,200,{ok:true,command:null})}c.status='sent';c.sentAt=Date.now();c.attempts=(c.attempts||0)+1;saveCommands(a);return reply(res,200,{ok:true,command:{id:c.id,action:c.action,symbol:c.symbol||'',side:c.side||'',lots:c.lots||0,sl:c.sl||0,tp:c.tp||0,ticket:c.ticket||0}});
  }
  if(ep==='/api/mt4/bridge/result'&&req.method==='POST'){
   if(!bridgeAuth(req))return reply(res,401,{ok:false,error:'Bridge tidak terautentikasi.'});const b=await body(req),a=commands(),c=a.find(x=>x.id===String(b.id||''));if(!c)return reply(res,404,{ok:false,error:'Perintah tidak ditemukan.'});
   if(c.status==='success'||c.status==='failed')return reply(res,200,{ok:true,duplicate:true});c.status=b.ok===true?'success':'failed';c.completedAt=Date.now();c.ticket=Number(b.ticket)||null;c.result=String(b.message||'').slice(0,240);saveCommands(a);audit('command-result',{id:c.id,status:c.status,ticket:c.ticket,message:c.result});return reply(res,200,{ok:true});
  }
  const me=trader(req,ctx);if(!me)return reply(res,403,{ok:false,error:'Akses trading hanya untuk admin atau trader yang ditunjuk.'});
  if(req.method==='GET'&&ep==='/api/mt4/status'){
   const st=state(),online=!!(st.lastSeen&&Date.now()-st.lastSeen<=20000&&st.account&&st.account.login===expectedLogin()&&st.account.server===expectedServer());
   const a=commands().filter(x=>x.requestedBy===me.email||me.role==='admin').slice(-10).reverse().map(x=>({id:x.id,action:x.action,symbol:x.symbol,side:x.side,lots:x.lots,ticket:x.ticket,status:x.status,result:x.result||x.error||'',createdAt:x.createdAt}));
   return reply(res,200,{ok:true,configured:configured(),online,account:online?st.account:null,positions:online?st.positions:[],lastSeen:st.lastSeen||null,maxLot:maxLot(),maxPositions:maxPositions(),allowedSymbols:allowedSymbols(),commands:a});
  }
  if(req.method==='POST'&&(ep==='/api/mt4/orders'||ep==='/api/mt4/close')){
   if(!sameOrigin(req,ctx))return reply(res,403,{ok:false,error:'Asal permintaan tidak valid.'});
   if(ctx.tooMany&&ctx.tooMany('mt4-order|'+me.email,20,60000))return reply(res,429,{ok:false,error:'Terlalu banyak perintah trading. Tunggu sebentar.'});
   const st=state();if(!configured()||!st.lastSeen||Date.now()-st.lastSeen>20000)return reply(res,503,{ok:false,error:'Terminal MT4 belum terhubung. Order tidak dikirim.'});
   const b=await body(req),a=commands();if(a.filter(x=>['pending','sent'].includes(x.status)).length>=10)return reply(res,429,{ok:false,error:'Antrean perintah penuh. Tunggu hasil perintah sebelumnya.'});
   let c;
   if(ep==='/api/mt4/orders'){
    const symbol=String(b.symbol||'').trim().toUpperCase(),side=String(b.side||'').toUpperCase(),lots=Number(b.lots),sl=Number(b.sl)||0,tp=Number(b.tp)||0;
    if(!allowedSymbols().includes(symbol))return reply(res,400,{ok:false,error:'Simbol tidak ada dalam daftar simbol yang diizinkan.'});
    if(!['BUY','SELL'].includes(side))return reply(res,400,{ok:false,error:'Arah order tidak valid.'});
    if((st.positions||[]).length>=maxPositions())return reply(res,409,{ok:false,error:'Batas jumlah posisi terbuka FOR-X telah tercapai ('+maxPositions()+').'});
    if(!Number.isFinite(lots)||lots<0.01||lots>maxLot())return reply(res,400,{ok:false,error:'Ukuran lot di luar batas FOR-X ('+maxLot()+').'});
    if(!Number.isFinite(sl)||!Number.isFinite(tp)||sl<0||tp<0)return reply(res,400,{ok:false,error:'Nilai SL/TP tidak valid.'});
    c={id:crypto.randomUUID(),action:'open',symbol,side,lots,sl,tp};
   }else{
    const ticket=Number(b.ticket);if(!Number.isSafeInteger(ticket)||ticket<=0)return reply(res,400,{ok:false,error:'Nomor tiket tidak valid.'});
    if(!st.positions.some(p=>p.ticket===ticket))return reply(res,404,{ok:false,error:'Posisi tidak ditemukan pada akun yang terhubung.'});
    c={id:crypto.randomUUID(),action:'close',ticket};
   }
   Object.assign(c,{status:'pending',attempts:0,createdAt:Date.now(),requestedBy:me.email});a.push(c);saveCommands(a);audit('command-created',{id:c.id,action:c.action,requestedBy:me.email,login:expectedLogin(),symbol:c.symbol||null,side:c.side||null,lots:c.lots||null,ticket:c.ticket||null});return reply(res,202,{ok:true,command:{id:c.id,status:c.status}});
  }
  return reply(res,404,{ok:false,error:'Endpoint MT4 tidak ditemukan.'});
 }catch(e){if(e&&e.code)return reply(res,e.code,{ok:false,error:e.error||'Permintaan tidak valid.'});console.error('MT4 bridge:',e);return reply(res,500,{ok:false,error:'Kesalahan internal bridge MT4.'});}
}
module.exports={handle,revokeUser};
