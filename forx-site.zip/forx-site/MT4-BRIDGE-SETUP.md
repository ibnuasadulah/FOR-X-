# FOR-X QuickPro MT4 Bridge — Phase 1

This package adds a controlled bridge between the existing FOR-X Node.js website and a QuickPro MT4 desktop terminal. It does **not** connect to the proprietary QuickPro App. It uses an MT4 Expert Advisor (EA) on a Windows PC/VPS logged into the QuickPro MT4 account.

## What is included

- `mt4-bridge.js`: authenticated bridge endpoints, account heartbeat, positions snapshot, command queue, execution results, and audit log.
- `mt4/Experts/FORX_QuickPro_Bridge.mq4`: MT4 EA source.
- `public/dashboard.html` and `public/js/trading.js`: an `Akun Real MT4` tab in the existing Trading dashboard.
- Admin panel role control: an admin can designate a user as `trader` or revoke that role.
- `.env.example`: required server-side configuration.

## Important: not live-ready by default

The EA defaults `InpEnableOrderExecution=false`. Keep it disabled for the first connection test. The bridge also remains inactive until `MT4_BRIDGE_TOKEN`, `MT4_EXPECTED_LOGIN`, and `MT4_EXPECTED_SERVER` are configured. Do not enable real order execution until demo tests, symbol mapping, lot rules, SL/TP behavior, and account authorization are verified.

## 1. QuickPro MT4 account

QuickPro's published MT4 server-change notice lists:

- Real server address: `mt4live.quickpro.co.id`
- Demo server address: `mt4demo.quickpro.co.id`

The exact server label returned inside MT4 by `AccountServer()` may differ from the DNS host. Log in to MT4 and read the exact account server shown by the terminal; use that exact value for `MT4_EXPECTED_SERVER`. For the first integration test, use a QuickPro **demo** login and its demo server. Only switch the environment values to the real login/server after the demo workflow has been validated.

QuickPro's website says its MT4 platform supports Expert Advisors, and its FAQ says robots are supported. Confirm that your specific account type and trading rules permit your intended use.

## 2. Configure the website server

1. Copy `.env.example` to `.env` (never upload a populated `.env` into a public repository).
2. Generate a long random secret, for example with `openssl rand -hex 32`.
3. Set:

```env
MT4_BRIDGE_TOKEN=PASTE_LONG_RANDOM_SECRET
MT4_EXPECTED_LOGIN=YOUR_MT4_ACCOUNT_NUMBER
MT4_EXPECTED_SERVER=EXACT_SERVER_LABEL_FROM_MT4
MT4_MAX_LOT=0.10
MT4_MAX_OPEN_POSITIONS=5
MT4_ALLOWED_SYMBOLS=XAUUSD,EURUSD,GBPUSD,USDJPY,AUDUSD,USDCAD
```

The server now reads `.env` without requiring a dotenv dependency. Environment variables configured by your hosting provider override `.env` values.

4. Restart the Node.js server.
5. Use HTTPS in production. Do not expose the Node server directly without TLS/reverse proxy and normal production hardening.

## 3. Designate a trader

1. Create the person's normal FOR-X member account.
2. Sign in as FOR-X admin and open the Admin panel.
3. In the user's action menu, select **Jadikan trader**.
4. The trader signs in normally and opens Dashboard → Chart & Trading → Akun Real MT4.

A trader role can submit trade commands and view the connected account snapshot. It cannot open the FOR-X admin panel.

## 4. Install the EA in MT4

1. Open QuickPro MT4 desktop and log in to the intended account. For the first test, use a demo account.
2. In MT4, open `File → Open Data Folder → MQL4 → Experts`.
3. Copy `mt4/Experts/FORX_QuickPro_Bridge.mq4` into that folder.
4. Open MetaEditor (F4), open the file, and compile it.
5. In MT4, open `Tools → Options → Expert Advisors` and enable **Allow automated trading**. Add your exact FOR-X HTTPS origin (e.g. `https://forxcommunity.com`) to **Allow WebRequest for listed URL**.
6. Attach the EA to a chart. Set `InpBridgeBaseUrl` to the origin only (no trailing slash), and `InpBridgeToken` to the same secret configured on the server.
7. Keep `InpEnableOrderExecution=false`. Confirm the EA logs successful HTTP requests and the FOR-X panel shows the account online.

MetaTrader disables WebRequest by default and requires the URL to be explicitly allow-listed. WebRequest is available to EAs/scripts, not indicators.

## 5. Demo execution test

Only after the account heartbeat is correct:

1. Confirm login number, exact server label, currency, and balance in FOR-X.
2. Verify the open positions list matches MT4.
3. Set the allowed symbols to the exact broker symbol names. Some brokers use suffixes; adjust `MT4_ALLOWED_SYMBOLS` to match the actual Market Watch names.
4. Keep the EA on a demo account. Set `InpEnableOrderExecution=true` only on that demo terminal.
5. Start with the smallest permitted lot. Verify BUY, SELL, SL, TP, close-position, error handling, and audit trail.
6. Confirm a result appears in the FOR-X command list and the actual MT4 terminal.

## Security and operating notes

- Never put the bridge token in browser JavaScript, HTML, Git, or a public support chat. It belongs in server `.env` and the private MT4 EA input on the controlled terminal.
- The MT4 account password is entered only into the official MT4 terminal; it is not sent to FOR-X.
- The website trader can execute real trades when execution is enabled. Only grant the role to a person you trust. Consider legal/regulatory requirements before operating another person's account or providing account-management services.
- Use a dedicated Windows VPS/PC. If it is offline, orders cannot be delivered. The terminal must remain logged in and connected.
- The EA keeps processed command IDs in MT4 terminal Global Variables to suppress duplicate execution if an HTTP result acknowledgement is retried. This is a practical duplicate guard, not a substitute for broker-side order reconciliation.
- The current first phase sends market orders and closes market positions. Pending orders, partial close, modification of SL/TP on existing positions, live tick streaming, and full trade history are not included yet.
- The default safeguards limit each order to 0.10 lots and the account to five open positions; adjust `MT4_MAX_LOT` and `MT4_MAX_OPEN_POSITIONS` deliberately. The current browser account panel polls every 5 seconds; MT4 polls the server every 2 seconds and sends heartbeat every 5 seconds.
- Before production use, add TLS, backups, server monitoring, durable database-backed command queue, stronger CSRF controls, and independent risk review. The existing website stores member data in JSON files, so this bridge should be treated as a controlled prototype until the wider application is hardened.

## API endpoints added

Website (session cookie; role `admin` or `trader`):
- `GET /api/mt4/status`
- `POST /api/mt4/orders` — `{ "symbol":"XAUUSD", "side":"BUY", "lots":0.01, "sl":0, "tp":0 }`
- `POST /api/mt4/close` — `{ "ticket":123456 }`

MT4 EA (Bearer bridge token):
- `POST /api/mt4/bridge/heartbeat`
- `GET /api/mt4/bridge/next`
- `POST /api/mt4/bridge/result`

Runtime data is stored under `data/mt4-bridge-state.json`, `data/mt4-commands.json`, and `data/mt4-audit.jsonl`. These files are not served from the public directory.
