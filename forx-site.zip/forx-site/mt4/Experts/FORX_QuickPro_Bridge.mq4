//+------------------------------------------------------------------+
//| FOR-X QuickPro MT4 Bridge - initial controlled execution agent   |
//| Install on MT4 desktop/VPS logged into the intended QuickPro acct|
//| Requires the HTTPS FOR-X origin in MT4 WebRequest allow-list.     |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "FOR-X bridge: account telemetry and explicitly authorized website orders."
input string InpBridgeBaseUrl = "https://YOUR-FORX-DOMAIN.COM";
input string InpBridgeToken = "CHANGE_ME_LONG_RANDOM_TOKEN";
input int    InpPollSeconds = 2;
input int    InpSlippagePoints = 30;
input int    InpMagicNumber = 84249;
input bool   InpEnableOrderExecution = false; // Keep false for first demo connection test.
input int    InpHeartbeatSeconds = 5;

bool g_busy=false; datetime g_lastHeartbeat=0;
string Url(const string path){return InpBridgeBaseUrl+path;}
string JsonEscape(string s){StringReplace(s,"\\","\\\\");StringReplace(s,"\"","\\\"");StringReplace(s,"\r"," ");StringReplace(s,"\n"," ");return s;}
string AuthHeaders(){return "Authorization: Bearer "+InpBridgeToken+"\r\nContent-Type: application/json\r\n";}
bool Http(const string method,const string path,const string payload,string &response){
 char data[],result[];string responseHeaders;ArrayResize(data,0);
 if(method=="POST"){int n=StringToCharArray(payload,data,0,WHOLE_ARRAY,CP_UTF8);if(n>0)ArrayResize(data,n-1);}
 ResetLastError();int code=WebRequest(method,Url(path),AuthHeaders(),10000,data,result,responseHeaders);
 if(code==-1){Print("FOR-X WebRequest error ",GetLastError(),". Check URL allow-list and HTTPS.");return false;}
 response=CharArrayToString(result,0,-1,CP_UTF8);
 if(code<200||code>=300){Print("FOR-X HTTP ",code,": ",response);return false;}return true;
}
string BuildHeartbeat(){
 string p="[";int count=0;
 for(int i=OrdersTotal()-1;i>=0;i--){if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES))continue;if(OrderType()>OP_SELL)continue;
  if(count>0)p+=",";p+="{\"ticket\":"+IntegerToString(OrderTicket())+",\"symbol\":\""+JsonEscape(OrderSymbol())+"\",\"type\":"+IntegerToString(OrderType())+",\"lots\":"+DoubleToString(OrderLots(),2)+",\"openPrice\":"+DoubleToString(OrderOpenPrice(),Digits)+",\"sl\":"+DoubleToString(OrderStopLoss(),Digits)+",\"tp\":"+DoubleToString(OrderTakeProfit(),Digits)+",\"profit\":"+DoubleToString(OrderProfit(),2)+",\"swap\":"+DoubleToString(OrderSwap(),2)+",\"commission\":"+DoubleToString(OrderCommission(),2)+",\"openTime\":"+IntegerToString((int)OrderOpenTime())+"}";count++;}
 p+="]";
 return "{\"login\":\""+IntegerToString(AccountNumber())+"\",\"server\":\""+JsonEscape(AccountServer())+"\",\"currency\":\""+JsonEscape(AccountCurrency())+"\",\"company\":\""+JsonEscape(AccountCompany())+"\",\"name\":\""+JsonEscape(AccountName())+"\",\"leverage\":"+IntegerToString(AccountLeverage())+",\"balance\":"+DoubleToString(AccountBalance(),2)+",\"equity\":"+DoubleToString(AccountEquity(),2)+",\"margin\":"+DoubleToString(AccountMargin(),2)+",\"freeMargin\":"+DoubleToString(AccountFreeMargin(),2)+",\"profit\":"+DoubleToString(AccountProfit(),2)+",\"terminalVersion\":\"MT4\",\"positions\":"+p+"}";
}
string GetString(const string json,const string key){string k="\""+key+"\":\"";int a=StringFind(json,k);if(a<0)return "";a+=StringLen(k);int b=StringFind(json,"\"",a);if(b<0)return "";return StringSubstr(json,a,b-a);}
double GetNumber(const string json,const string key){string k="\""+key+"\":";int a=StringFind(json,k);if(a<0)return 0;a+=StringLen(k);int b=a;while(b<StringLen(json)){int ch=StringGetCharacter(json,b);if((ch>='0'&&ch<='9')||ch=='.'||ch=='-')b++;else break;}return StrToDouble(StringSubstr(json,a,b-a));}
bool HasCommand(const string json){return StringFind(json,"\"command\":{")>=0;}
void SendResult(const string id,bool ok,int ticket,const string message){GlobalVariableSet("FORX_"+id+"_done",1);GlobalVariableSet("FORX_"+id+"_ok",ok?1:0);GlobalVariableSet("FORX_"+id+"_ticket",ticket);string r="";string payload="{\"id\":\""+id+"\",\"ok\":"+(ok?"true":"false")+",\"ticket\":"+IntegerToString(ticket)+",\"message\":\""+JsonEscape(message)+"\"}";Http("POST","/api/mt4/bridge/result",payload,r);}
void ExecuteCommand(const string response){
 string id=GetString(response,"id"),action=GetString(response,"action");if(id=="")return;
 string doneKey="FORX_"+id+"_done";if(GlobalVariableCheck(doneKey)){bool wasOk=GlobalVariableGet("FORX_"+id+"_ok")==1;int oldTicket=(int)GlobalVariableGet("FORX_"+id+"_ticket");SendResult(id,wasOk,oldTicket,"Pengiriman ulang dicegah; hasil eksekusi sebelumnya dikirim ulang.");return;}
 if(!InpEnableOrderExecution){SendResult(id,false,0,"Execution dinonaktifkan di EA; aktifkan setelah uji demo.");return;}
 if(action=="open"){
  string symbol=GetString(response,"symbol"),side=GetString(response,"side");double lots=GetNumber(response,"lots"),sl=GetNumber(response,"sl"),tp=GetNumber(response,"tp");
  if(symbol==""||!SymbolSelect(symbol,true)||lots<=0){SendResult(id,false,0,"Symbol atau lot tidak valid / tidak tersedia.");return;}
  int type=side=="BUY"?OP_BUY:(side=="SELL"?OP_SELL:-1);if(type<0){SendResult(id,false,0,"Arah order tidak valid.");return;}
  double price=type==OP_BUY?MarketInfo(symbol,MODE_ASK):MarketInfo(symbol,MODE_BID);int digits=(int)MarketInfo(symbol,MODE_DIGITS);
  double minLot=MarketInfo(symbol,MODE_MINLOT),maxLot=MarketInfo(symbol,MODE_MAXLOT),lotStep=MarketInfo(symbol,MODE_LOTSTEP);
  if(lots<minLot||lots>maxLot||lotStep<=0||MathAbs(lots/lotStep-MathRound(lots/lotStep))>0.000001){SendResult(id,false,0,"Lot tidak sesuai minimum, maksimum, atau lot step broker.");return;}
  if(price<=0){SendResult(id,false,0,"Harga pasar tidak tersedia.");return;}
  if(sl>0)sl=NormalizeDouble(sl,digits);if(tp>0)tp=NormalizeDouble(tp,digits);
  if(type==OP_BUY&&((sl>0&&sl>=price)||(tp>0&&tp<=price))){SendResult(id,false,0,"BUY: SL harus di bawah harga dan TP di atas harga.");return;}
  if(type==OP_SELL&&((sl>0&&sl<=price)||(tp>0&&tp>=price))){SendResult(id,false,0,"SELL: SL harus di atas harga dan TP di bawah harga.");return;}
  int ticket=OrderSend(symbol,type,lots,price,InpSlippagePoints,sl,tp,"FOR-X web order",InpMagicNumber,0,clrNONE);
  if(ticket<0){int err=GetLastError();SendResult(id,false,0,"OrderSend gagal. MT4 error "+IntegerToString(err));return;}
  SendResult(id,true,ticket,"Order berhasil dikirim ke broker.");return;
 }
 if(action=="close"){
  int ticket=(int)GetNumber(response,"ticket");if(ticket<=0||!OrderSelect(ticket,SELECT_BY_TICKET)){SendResult(id,false,0,"Ticket tidak ditemukan.");return;}
  int type=OrderType();if(type>OP_SELL){SendResult(id,false,0,"Ticket bukan market position.");return;}
  string symbol=OrderSymbol();double lots=OrderLots(),price=type==OP_BUY?MarketInfo(symbol,MODE_BID):MarketInfo(symbol,MODE_ASK);
  if(!OrderClose(ticket,lots,price,InpSlippagePoints,clrNONE)){int err=GetLastError();SendResult(id,false,0,"OrderClose gagal. MT4 error "+IntegerToString(err));return;}
  SendResult(id,true,ticket,"Posisi berhasil ditutup.");return;
 }
 SendResult(id,false,0,"Action tidak dikenal.");
}
void Poll(){string r="";if(!Http("GET","/api/mt4/bridge/next","",r))return;if(HasCommand(r))ExecuteCommand(r);}
void Heartbeat(){string r="";if(Http("POST","/api/mt4/bridge/heartbeat",BuildHeartbeat(),r))g_lastHeartbeat=TimeCurrent();}
int OnInit(){if(StringFind(InpBridgeBaseUrl,"https://")!=0){Print("FOR-X: gunakan URL HTTPS.");return INIT_FAILED;}if(InpBridgeToken==""||InpBridgeToken=="CHANGE_ME_LONG_RANDOM_TOKEN"){Print("FOR-X: isi token bridge terlebih dahulu.");return INIT_FAILED;}EventSetTimer(MathMax(1,InpPollSeconds));Print("FOR-X MT4 Bridge started. Execution enabled: ",InpEnableOrderExecution);return INIT_SUCCEEDED;}
void OnDeinit(const int reason){EventKillTimer();}
void OnTimer(){if(g_busy)return;g_busy=true;if(g_lastHeartbeat==0||TimeCurrent()-g_lastHeartbeat>=MathMax(3,InpHeartbeatSeconds))Heartbeat();Poll();g_busy=false;}
