'use strict';
/* Mengarahkan semua tautan "Kontak & Bantuan" ke kontak.html.
   Pemakaian (dari folder forx-node):  node update-links.js
   Membuat cadangan *.bak di samping file yang diubah. */
const fs=require('fs'),path=require('path');
const dir=path.join(__dirname,'public');let changed=0;
for(const f of fs.readdirSync(dir).filter(x=>x.endsWith('.html'))){
 const p=path.join(dir,f),s=fs.readFileSync(p,'utf8');let n=s;
 if(f==='kontak.html')continue;
 n=n.split('href="index.html#contact"').join('href="kontak.html"');                          /* halaman biasa (footer, tombol IB) */
 n=n.split('<a href="#contact">Kontak &amp; Bantuan</a>').join('<a href="kontak.html">Kontak &amp; Bantuan</a>'); /* footer index.html */
 if(n!==s){fs.writeFileSync(p+'.bak',s);fs.writeFileSync(p,n);changed++;console.log('diubah:',f)}}
console.log(changed?`Selesai. ${changed} file diperbarui (cadangan .bak dibuat).`:'Tidak ada tautan yang perlu diubah.');
