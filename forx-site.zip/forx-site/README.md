# FOR-X

Situs FOR-X: halaman statis (`public/`) + server kecil (`server.js`) untuk daftar, masuk, dasbor anggota, dan panel admin.
Tanpa dependensi npm: cukup Node.js 18 atau lebih baru.

## Menjalankan

```bash
npm start            # http://localhost:3000  (ubah port dengan PORT=8080)
```

Data pengguna dan sesi disimpan sebagai file JSON di folder `data/` (dibuat otomatis).
**Backup folder `data/` secara rutin.** Folder ini harus berada di disk permanen pada hosting.

## Variabel lingkungan

Server membaca variabel ini langsung dari lingkungan (bukan dari file `.env`).
Atur lewat panel hosting, atau jalankan `node --env-file=.env server.js` (Node 20.6+).

| Variabel | Fungsi |
|---|---|
| `PORT` | Port server (bawaan 3000). |
| `COOKIE_SECURE=1` | Wajib saat situs memakai HTTPS: cookie login hanya dikirim lewat HTTPS. |
| `TRUST_PROXY=1` | Aktifkan bila server berada di belakang Nginx/Cloudflare agar IP asli pengunjung terbaca. |

## Panel admin

Alamat: `/admin.html`. Fitur: ringkasan pendaftar, cari pengguna, reset kata sandi (sandi sementara, tampil sekali),
ubah peran, aktivasi VVIP manual, hapus akun, lihat dan cabut sesi login, serta riwayat tindakan admin (`data/admin-log.jsonl`).

**Aktivasi VVIP manual** (untuk pembayaran lewat transfer): di tab Pengguna, tombol **Beri VVIP** / **Kelola VVIP** pada tiap baris.
Pilih tanggal berakhir (atau tombol cepat +30/+90/+180/+365 hari), lalu **Aktifkan VVIP** atau **Perpanjang**; **Cabut VVIP** menghentikan VVIP seketika.
VVIP berlaku sampai pukul 23.59 WIB pada tanggal berakhir dan kedaluwarsa otomatis. Datanya disimpan di `data/users.json` (kolom `vvipUntil`),
dan setiap tindakan masuk ke riwayat admin. Status tampil ke pengguna lewat `/api/me` (`vvip_active`, `vvip_until`).

**Membuat admin pertama** (jalankan di server; boleh saat server sedang hidup):

```bash
npm run create-admin
```

Tanpa terminal interaktif (misalnya hosting yang hanya menyediakan variabel lingkungan):

```bash
ADMIN_EMAIL=anda@email.com ADMIN_PASSWORD='sandi-panjang-anda' ADMIN_NAME='Nama Anda' npm run create-admin
```

Skrip yang sama bisa dipakai untuk menaikkan akun yang sudah ada menjadi admin, atau mengganti kata sandi admin yang lupa.

**Cara masuk:** login dulu lewat `masuk.html` dengan akun admin, lalu buka `/admin.html`.
Bagi siapa pun yang bukan admin, `/admin.html` dan `/api/admin/*` tampak tidak ada (404).

Pengamanan yang aktif: pengecekan peran di server, pembatasan permintaan, pengecekan `Origin` pada setiap tindakan,
konfirmasi sebelum menghapus, admin tidak bisa mengubah atau menghapus akunnya sendiri, dan halaman tidak di-cache
serta tidak diindeks mesin pencari. Bila memakai Nginx/Cloudflare, teruskan header `Host` asli ke server
(`proxy_set_header Host $host;`) agar pengecekan `Origin` berjalan benar.

## Kalender Ekonomi

Dashboard memakai feed publik Fair Economy (pemilik Metals Mine dan Forex Factory): `https://nfs.faireconomy.media/ff_calendar_thisweek.json`,
diambil server lewat `/api/calendar` (hanya untuk pengguna yang sudah masuk) dan di-cache 30 menit. Server butuh akses internet keluar.
Feed hanya memuat minggu berjalan dan tanpa nilai "actual".

## Keamanan umum

- Kata sandi disimpan sebagai hash scrypt dengan salt; sesi disimpan sebagai hash token.
- Cookie `sid`: HttpOnly, SameSite=Lax, dan Secure bila `COOKIE_SECURE=1`.
- Percobaan daftar dan masuk dibatasi per IP.
- Pasang HTTPS di hosting produksi.

## Struktur

```
server.js            server (file statis + API)
create-admin.js      pembuat admin pertama
public/              situs (HTML, CSS, JS, gambar)
  admin.html         panel admin
data/                dibuat otomatis: users.json, sessions.json, admin-log.jsonl
```
