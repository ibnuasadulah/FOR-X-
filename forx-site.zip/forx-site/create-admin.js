'use strict';
/* Membuat akun admin pertama (atau menaikkan akun yang sudah ada menjadi admin).

   Cara biasa (interaktif):   npm run create-admin
   Tanpa terminal interaktif: ADMIN_EMAIL=anda@email.com ADMIN_PASSWORD='sandi-panjang' ADMIN_NAME='Nama' npm run create-admin

   Aman dijalankan saat server sedang hidup: server membaca ulang data/users.json bila isinya berubah. */
const fs = require('fs'), path = require('path'), crypto = require('crypto'), readline = require('readline');
const DATA = path.join(__dirname, 'data'), FU = path.join(DATA, 'users.json');

fs.mkdirSync(DATA, { recursive: true });
let users = {};
try { users = JSON.parse(fs.readFileSync(FU, 'utf8')); } catch (e) { if (fs.existsSync(FU)) { console.error('data/users.json rusak atau tidak terbaca. Perbaiki dulu sebelum melanjutkan.'); process.exit(1); } }

const save = () => { const t = FU + '.tmp'; fs.writeFileSync(t, JSON.stringify(users)); fs.renameSync(t, FU); };
const hash = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');   /* sama dengan server.js */
function newReferral() { let c; do { c = 'FX' + crypto.randomBytes(4).toString('hex').toUpperCase().slice(0, 6); } while (Object.values(users).some(u => u.ref === c)); return c; }

const env = process.env, auto = !!(env.ADMIN_EMAIL && env.ADMIN_PASSWORD);
let rl, muted = false;
if (!auto) {
  rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: !!process.stdin.isTTY });
  const w = rl._writeToOutput;
  rl._writeToOutput = function (s) { if (muted && process.stdin.isTTY) { if (/[\r\n]/.test(s)) process.stdout.write('\n'); else if (s) process.stdout.write('*'); } else w.call(rl, s); };
}
const ask = (q, hidden) => new Promise(r => { process.stdout.write(q); muted = !!hidden; rl.question('', a => { muted = false; r(a.trim()); }); });

(async () => {
  const email = (auto ? env.ADMIN_EMAIL : await ask('Email admin: ')).trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email) || email.length > 254) { console.error('Alamat email tidak valid.'); process.exit(1); }
  const existing = users[email];
  let pw = null, name = existing ? existing.name : null;

  if (existing) {
    console.log(`Akun ${email} sudah ada${existing.role === 'admin' ? ' dan sudah menjadi admin' : ''}.`);
    if (auto) pw = env.ADMIN_PASSWORD;
    else if (/^y/i.test(await ask('Ganti kata sandinya juga? (y/N): '))) pw = await ask('Kata sandi baru (min. 8 karakter): ', true);
  } else {
    name = (auto ? (env.ADMIN_NAME || 'Admin') : (await ask('Nama (Enter = Admin): ') || 'Admin')).slice(0, 60);
    pw = auto ? env.ADMIN_PASSWORD : await ask('Kata sandi (min. 8 karakter): ', true);
    if (!auto && pw !== await ask('Ulangi kata sandi: ', true)) { console.error('Kata sandi tidak sama.'); process.exit(1); }
  }
  if (pw !== null && (pw.length < 8 || pw.length > 128)) { console.error('Kata sandi harus 8 sampai 128 karakter.'); process.exit(1); }

  if (existing) {
    existing.role = 'admin';
    if (pw !== null) { existing.salt = crypto.randomBytes(16).toString('hex'); existing.hash = hash(pw, existing.salt); }
  } else {
    const salt = crypto.randomBytes(16).toString('hex');
    users[email] = { name, phone: '', salt, hash: hash(pw, salt), ref: newReferral(), refBy: null, role: 'admin', created: new Date().toISOString() };
  }
  save();
  console.log(`Selesai. ${email} sekarang admin. Masuk lewat halaman masuk.html, lalu buka /admin.html.`);
  if (rl) rl.close();
})().catch(e => { console.error('Gagal:', e.message); process.exit(1); });
