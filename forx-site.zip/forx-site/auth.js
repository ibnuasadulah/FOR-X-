/* auth.js (versi server Node.js): mendefinisikan window.API untuk masuk.js dan halaman lain.
   API.user() sinkron (dari localStorage 'session'), lalu disegarkan dari /api/me saat halaman dibuka. */
(function(){
const KEY='session';
const get=()=>{try{return JSON.parse(localStorage.getItem(KEY))}catch(e){return null}};
const put=u=>{try{u?localStorage.setItem(KEY,JSON.stringify({name:u.name,email:u.email,role:u.role,referral:u.referral,referral_code:u.referral_code,created:u.created,vvip_active:u.vvip_active,vvip_until:u.vvip_until})):localStorage.removeItem(KEY)}catch(e){}};
const notify=u=>{if(typeof window.onAuthChange==='function')try{window.onAuthChange(u)}catch(e){}};
async function call(path,body){
 try{const r=await fetch(path,{method:body===undefined?'GET':'POST',credentials:'same-origin',headers:body===undefined?{}:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});
  let d={};try{d=await r.json()}catch(e){}
  const noApi=!('ok' in d)&&[404,405,501].includes(r.status);
  return {status:r.status,data:d,ok:!!d.ok,error:d.error||(noApi?'Server API tidak ditemukan. Jalankan "node server.js" lalu buka http://localhost:3000 (bukan Live Server).':(r.ok?'':'Terjadi kesalahan. Coba lagi.')),user:d.user}}
 catch(e){return {status:0,ok:false,error:'Tidak dapat terhubung ke server. Pastikan server Node.js berjalan.'}}}
const api={
 user:get,
 async login(email,password){const r=await call('/api/login',{email,password});if(r.ok){put(r.user);notify(r.user)}return r},
 async register(data){const r=await call('/api/register',data);if(r.ok){put(r.user);notify(r.user)}return r},
 async logout(){await call('/api/logout',{});put(null);notify(null);return {ok:true}},
 async updateProfile(d){const r=await call('/api/profile',d);if(r.ok){put(r.user);notify(r.user)}return r},
 async changePassword(current,password){return call('/api/password',{current,password})},
 async logoutAll(){const r=await call('/api/logout-all',{});put(null);notify(null);return r},
 async sessions(){const r=await call('/api/sessions');return {ok:r.ok,error:r.error,sessions:(r.data&&r.data.sessions)||[]}},
 async revokeSession(id){return call('/api/sessions/revoke',{id})},
  async articles(){const r=await call('/api/articles');return {ok:r.ok,articles:(r.data&&r.data.articles)||[]}},
 async contact(d){return call('/api/contact',d)},
 async refresh(){const r=await call('/api/me');if(r.ok){put(r.user);notify(r.user)}else if(r.status===401&&get()){put(null);notify(null)}return r}
};
/* metode yang belum ada tidak membuat halaman error: mengembalikan hasil gagal yang aman */
window.API=new Proxy(api,{get:(t,k)=>k in t?t[k]:(typeof k==='string'&&k!=='then'?async()=>({ok:false,error:'Fitur ini belum tersedia di server.',articles:[]}):undefined)});
window.API.refresh();
})();
