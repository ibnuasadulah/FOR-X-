'use strict';
/* Server FOR-X: menyajikan folder ./public dan menyediakan /api (daftar, masuk, keluar, me).
   Tanpa dependensi npm. Data pengguna disimpan di ./data (JSON). Butuh Node.js 18 atau lebih baru. */
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),{promisify}=require('util');
// Load a local .env file without adding a dependency. Hosting-panel environment variables take precedence.
try{for(const line of fs.readFileSync(path.join(__dirname,'.env'),'utf8').split(/\r?\n/)){const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);if(m&&!Object.prototype.hasOwnProperty.call(process.env,m[1]))process.env[m[1]]=m[2].replace(/^(['"])(.*)\1$/,'$2')}}catch(e){}
const scrypt=promisify(crypto.scrypt);
const PORT=+process.env.PORT||3000,ROOT=path.join(__dirname,'public'),DATA=path.join(__dirname,'data');
const SECURE=process.env.COOKIE_SECURE==='1',TRUST_PROXY=process.env.TRUST_PROXY==='1';
const SESSION_DAYS=14;
const mt4Bridge=require('./mt4-bridge');

fs.mkdirSync(DATA,{recursive:true});
const FU=path.join(DATA,'users.json'),FS=path.join(DATA,'sessions.json');
const load=(f,d)=>{try{return JSON.parse(fs.readFileSync(f,'utf8'))}catch(e){return d}};
const save=(f,o)=>{const t=f+'.tmp';fs.writeFileSync(t,JSON.stringify(o));fs.renameSync(t,f)};
let users=load(FU,{}),sess=load(FS,{});
let umt=0;const stU=()=>{try{return fs.statSync(FU).mtimeMs}catch(e){return 0}};umt=stU();
function syncUsers(){const m=stU();if(m!==umt){users=load(FU,{});umt=m}}   /* ikut membaca perubahan dari create-admin */
const saveUsers=()=>{save(FU,users);umt=stU()};          /* users[email], sess[sha256(token)] */
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');

/* ---------- util ---------- */
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.ico':'image/x-icon','.gif':'image/gif','.woff':'font/woff','.woff2':'font/woff2','.txt':'text/plain; charset=utf-8','.mp4':'video/mp4','.webm':'video/webm'};
const SEC={'X-Content-Type-Options':'nosniff','X-Frame-Options':'SAMEORIGIN','Referrer-Policy':'strict-origin-when-cross-origin'};
function send(res,code,body,headers){res.writeHead(code,{...SEC,...headers});res.end(body)}
const json=(res,code,obj,extra)=>send(res,code,JSON.stringify(obj),{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...extra});
const ipOf=req=>TRUST_PROXY&&req.headers['x-forwarded-for']?String(req.headers['x-forwarded-for']).split(',')[0].trim():req.socket.remoteAddress;
function cookieOf(req,k){const m=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(k+'='));return m?m.slice(k.length+1):''}
function readBody(req){return new Promise((ok,no)=>{if(!/application\/json/i.test(req.headers['content-type']||''))return no({code:415,msg:'Permintaan tidak valid.'});
 let n=0,b=[];req.on('data',c=>{n+=c.length;if(n>10240){no({code:413,msg:'Permintaan terlalu besar.'});req.destroy()}else b.push(c)});
 req.on('end',()=>{try{ok(JSON.parse(Buffer.concat(b).toString()||'{}'))}catch(e){no({code:400,msg:'Format data tidak valid.'})}});req.on('error',()=>no({code:400,msg:'Permintaan gagal.'}))})}

/* pembatas percobaan */
const hits=new Map();
function tooMany(key,max,ms){const now=Date.now(),h=hits.get(key);if(!h||now-h.t>ms){hits.set(key,{n:1,t:now});return false}h.n++;return h.n>max}
function resetHits(key){hits.delete(key)}
setInterval(()=>{const now=Date.now();for(const[k,v]of hits)if(now-v.t>36e5)hits.delete(k);for(const[k,v]of Object.entries(sess))if(v.exp<now)delete sess[k];save(FS,sess)},6e5).unref();

/* ---------- auth ---------- */
const hashPw=async(pw,salt)=>(await scrypt(pw,salt,64)).toString('hex');
const DUMMY_SALT=crypto.randomBytes(16).toString('hex');
const vvipOn=u=>!!u.vvipUntil&&Date.parse(u.vvipUntil)>Date.now();   /* VVIP aktif = tanggal berakhir belum lewat (kedaluwarsa otomatis, tanpa cron) */
const publicUser=u=>({name:u.name,email:u.email,phone:u.phone,role:u.role||'member',referral:u.ref,created:u.created,vvip_active:vvipOn(u),vvip_until:u.vvipUntil||null,referred:Object.values(users).filter(x=>x.refBy&&x.refBy===u.ref).length});
function newReferral(){let c;do{c='FX'+crypto.randomBytes(4).toString('hex').toUpperCase().slice(0,6)}while(Object.values(users).some(u=>u.ref===c));return c}
function startSession(req,res,email,extra){const tok=crypto.randomBytes(32).toString('hex');
 sess[sha(tok)]={email,exp:Date.now()+SESSION_DAYS*864e5,iat:Date.now(),ua:String(req.headers['user-agent']||'').slice(0,200)};save(FS,sess);
 return {'Set-Cookie':`sid=${tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_DAYS*86400}${SECURE?'; Secure':''}`}}
function currentUser(req){const s=sess[sha(cookieOf(req,'sid'))];if(!s||s.exp<Date.now())return null;const u=users[s.email];return u?{...u,email:s.email}:null}

function uaName(ua){const b=/Edg\//.test(ua)?'Edge':/OPR\//.test(ua)?'Opera':/Firefox\//.test(ua)?'Firefox':/Chrome\//.test(ua)?'Chrome':/Safari\//.test(ua)?'Safari':'Browser';
 const o=/Windows/.test(ua)?'Windows':/Android/.test(ua)?'Android':/iPhone|iPad/.test(ua)?'iOS':/Mac OS/.test(ua)?'macOS':/Linux/.test(ua)?'Linux':'perangkat lain';return b+' di '+o}

/* Kalender ekonomi: feed publik Fair Economy (pemilik Metals Mine & Forex Factory), minggu berjalan.
   Di-cache 30 menit di server supaya tidak kena batas permintaan; bila gagal memakai data terakhir. */
const CAL_URL='https://nfs.faireconomy.media/ff_calendar_thisweek.json';let calC={t:0,items:[],ok:false};
async function calendar(){
 if(Date.now()-calC.t<18e5&&calC.ok)return {ok:true,at:calC.t,items:calC.items};
 try{const r=await fetch(CAL_URL,{headers:{'User-Agent':'Mozilla/5.0 FOR-X'},signal:AbortSignal.timeout(8000)});
  if(!r.ok)throw new Error('HTTP '+r.status);const a=await r.json();if(!Array.isArray(a))throw new Error('format');
  calC={t:Date.now(),ok:true,items:a.slice(0,400).map(e=>({title:String(e.title||'').slice(0,120),country:String(e.country||'').slice(0,6),date:String(e.date||''),impact:String(e.impact||''),forecast:String(e.forecast||'').slice(0,20),previous:String(e.previous||'').slice(0,20)}))};
 }catch(e){calC.t=Date.now()-17e5;/* coba lagi dalam ~2 menit */if(!calC.items.length)return {ok:false,error:'Data kalender belum bisa diambil.'}}
 return {ok:true,at:calC.t,items:calC.items}}
async function api(req,res,url){
 const ep=url.pathname,ip=ipOf(req);
 try{
 syncUsers();
 if(ep.startsWith('/api/mt4/'))return await mt4Bridge.handle(req,res,url,{currentUser,ip,tooMany,sameOrigin:()=>sameOrigin(req)});
 if(ep.startsWith('/api/admin/'))return await admin(req,res,url,ep,ip);
 if(ep==='/api/calendar'&&req.method==='GET'){if(!currentUser(req))return json(res,401,{ok:false,error:'Belum masuk.'});return json(res,200,await calendar())}
 if(ep==='/api/me'&&req.method==='GET'){const u=currentUser(req);return u?json(res,200,{ok:true,user:publicUser(u)}):json(res,401,{ok:false,error:'Belum masuk.'})}
 if(ep==='/api/sessions'&&req.method==='GET'){const u=currentUser(req);if(!u)return json(res,401,{ok:false,error:'Belum masuk.'});const cur=sha(cookieOf(req,'sid'));
  const list=Object.entries(sess).filter(([k,v])=>v.email===u.email&&v.exp>Date.now()).sort((a,b)=>(b[1].iat||0)-(a[1].iat||0)).map(([k,v])=>({id:k.slice(0,12),current:k===cur,device:uaName(v.ua||''),since:v.iat||null}));
  return json(res,200,{ok:true,sessions:list})}
 if(req.method!=='POST')return json(res,405,{ok:false,error:'Metode tidak didukung.'});
 if(ep==='/api/logout'){const t=cookieOf(req,'sid');if(t){delete sess[sha(t)];save(FS,sess)}
  return json(res,200,{ok:true},{'Set-Cookie':`sid=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${SECURE?'; Secure':''}`})}
 const b=await readBody(req);
 if(ep==='/api/register'){
  if(tooMany('reg|'+ip,10,36e5))return json(res,429,{ok:false,error:'Terlalu banyak pendaftaran dari perangkat ini. Coba lagi nanti.'});
  const name=String(b.name||'').trim(),email=String(b.email||'').trim().toLowerCase(),pw=String(b.password||''),phone=String(b.phone||'').replace(/[\s\-().]/g,''),ref=String(b.referral||'').trim().toUpperCase();
  if(name.length<2||name.length>60)return json(res,400,{ok:false,error:'Nama lengkap wajib diisi (2 sampai 60 karakter).'});
  if(!/^\S+@\S+\.\S+$/.test(email)||email.length>254)return json(res,400,{ok:false,error:'Alamat email tidak valid.'});
  if(!/^(\+?62|0)?8\d{7,13}$/.test(phone))return json(res,400,{ok:false,error:'Nomor telepon/WhatsApp tidak valid.'});
  if(pw.length<8||pw.length>128)return json(res,400,{ok:false,error:'Kata sandi minimal 8 karakter.'});
  if(b.terms!==true)return json(res,400,{ok:false,error:'Anda harus menyetujui Syarat & Ketentuan.'});
  if(ref&&!/^[A-Z0-9]{4,20}$/.test(ref)||ref&&!Object.values(users).some(u=>u.ref===ref))return json(res,400,{ok:false,error:'Kode referal tidak ditemukan.'});
  if(users[email])return json(res,409,{ok:false,error:'Email ini sudah terdaftar. Silakan masuk.'});
  const salt=crypto.randomBytes(16).toString('hex');
  users[email]={name,phone,salt,hash:await hashPw(pw,salt),ref:newReferral(),refBy:ref||null,role:'member',created:new Date().toISOString()};saveUsers();
  return json(res,201,{ok:true,user:publicUser({...users[email],email})},startSession(req,res,email))}
 if(ep==='/api/login'){
  const email=String(b.email||'').trim().toLowerCase(),pw=String(b.password||''),key='login|'+ip+'|'+email;
  if(tooMany(key,5,6e5))return json(res,429,{ok:false,error:'Terlalu banyak percobaan. Coba lagi dalam beberapa menit.'});
  const u=users[email],h=await hashPw(pw.slice(0,128),u?u.salt:DUMMY_SALT);
  if(!u||!crypto.timingSafeEqual(Buffer.from(h,'hex'),Buffer.from(u.hash,'hex')))return json(res,401,{ok:false,error:'Email atau kata sandi salah.'});
  resetHits(key);return json(res,200,{ok:true,user:publicUser({...u,email})},startSession(req,res,email))}
 if(ep==='/api/profile'||ep==='/api/password'||ep==='/api/logout-all'||ep==='/api/sessions/revoke'){
  const u=currentUser(req);if(!u)return json(res,401,{ok:false,error:'Sesi berakhir. Silakan masuk lagi.'});
  const rec=users[u.email];
  if(ep==='/api/profile'){
   const name=String(b.name||'').trim(),phone=String(b.phone||'').replace(/[\s\-().]/g,'');
   if(name.length<2||name.length>60)return json(res,400,{ok:false,error:'Nama lengkap wajib diisi (2 sampai 60 karakter).'});
   if(!/^(\+?62|0)?8\d{7,13}$/.test(phone))return json(res,400,{ok:false,error:'Nomor telepon/WhatsApp tidak valid.'});
   rec.name=name;rec.phone=phone;saveUsers();return json(res,200,{ok:true,user:publicUser({...rec,email:u.email})})}
  if(ep==='/api/password'){
   const cur=String(b.current||'').slice(0,128),pw=String(b.password||'');
   if(tooMany('pw|'+u.email,5,6e5))return json(res,429,{ok:false,error:'Terlalu banyak percobaan. Coba lagi dalam beberapa menit.'});
   if(pw.length<8||pw.length>128)return json(res,400,{ok:false,error:'Kata sandi baru minimal 8 karakter.'});
   const h=await hashPw(cur,rec.salt);if(!crypto.timingSafeEqual(Buffer.from(h,'hex'),Buffer.from(rec.hash,'hex')))return json(res,401,{ok:false,error:'Kata sandi saat ini salah.'});
   rec.salt=crypto.randomBytes(16).toString('hex');rec.hash=await hashPw(pw,rec.salt);saveUsers();
   const keep=sha(cookieOf(req,'sid'));for(const k of Object.keys(sess))if(sess[k].email===u.email&&k!==keep)delete sess[k];save(FS,sess);
   resetHits('pw|'+u.email);return json(res,200,{ok:true})}
  if(ep==='/api/sessions/revoke'){const id=String(b.id||''),cur=sha(cookieOf(req,'sid'));
   if(!/^[0-9a-f]{12}$/.test(id))return json(res,400,{ok:false,error:'ID sesi tidak valid.'});
   const key=Object.keys(sess).find(k=>k.startsWith(id)&&sess[k].email===u.email&&k!==cur);
   if(!key)return json(res,404,{ok:false,error:'Sesi tidak ditemukan.'});delete sess[key];save(FS,sess);return json(res,200,{ok:true})}
  for(const k of Object.keys(sess))if(sess[k].email===u.email)delete sess[k];save(FS,sess);
  return json(res,200,{ok:true},{'Set-Cookie':`sid=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${SECURE?'; Secure':''}`})}
 return json(res,404,{ok:false,error:'Endpoint tidak ditemukan.'});
 }catch(e){if(e&&e.code&&e.msg)return json(res,e.code,{ok:false,error:e.msg});console.error(e);return json(res,500,{ok:false,error:'Terjadi kesalahan di server.'})}}

/* ---------- admin ---------- */
/* Semua rute /api/admin/* hanya untuk akun ber-role "admin". Bagi pihak lain, rute ini tampak tidak ada (404). */
const ADMIN_LOG=path.join(DATA,'admin-log.jsonl'),WIB=7*36e5;
const wibDay=t=>new Date(t+WIB).toISOString().slice(0,10);
const logAdmin=(adm,action,target,ip,extra)=>{try{fs.appendFileSync(ADMIN_LOG,JSON.stringify({t:new Date().toISOString(),admin:adm,action,target:target||null,ip,...(extra||{})})+'\n')}catch(e){console.error('Catatan admin gagal ditulis:',e.message)}};
const readLog=n=>{try{return fs.readFileSync(ADMIN_LOG,'utf8').trim().split('\n').filter(Boolean).slice(-n).reverse().map(l=>{try{return JSON.parse(l)}catch(e){return null}}).filter(Boolean)}catch(e){return []}};
const adminCount=()=>Object.values(users).filter(u=>u.role==='admin').length;
const TEMP_CHARS='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
const tempPw=()=>Array.from({length:12},()=>TEMP_CHARS[crypto.randomInt(TEMP_CHARS.length)]).join('');
const sameOrigin=req=>{const o=req.headers.origin;if(!o)return true;const h=(TRUST_PROXY&&req.headers['x-forwarded-host'])||req.headers.host;try{return new URL(o).host===String(h).split(',')[0].trim()}catch(e){return false}};
const NF={ok:false,error:'Endpoint tidak ditemukan.'};
async function admin(req,res,url,ep,ip){
 const me=currentUser(req);
 if(!me||me.role!=='admin')return json(res,404,NF);
 if(tooMany('adm|'+ip,240,6e4))return json(res,429,{ok:false,error:'Terlalu banyak permintaan. Coba sebentar lagi.'});
 const sub=ep.slice('/api/admin/'.length),cur=sha(cookieOf(req,'sid'));
 if(req.method==='GET'){
  if(sub==='stats'){
   const all=Object.values(users),now=Date.now(),today=wibDay(now),days=[];
   for(let i=13;i>=0;i--)days.push(wibDay(now-i*864e5));
   const cnt=Object.fromEntries(days.map(d=>[d,0]));let t7=0,td=0;
   for(const u of all){const c=Date.parse(u.created);if(!c)continue;const d=wibDay(c);if(d in cnt)cnt[d]++;if(d===today)td++;if(now-c<7*864e5)t7++}
   return json(res,200,{ok:true,stats:{total:all.length,today:td,last7:t7,admins:adminCount(),vvip:all.filter(vvipOn).length,activeSessions:Object.values(sess).filter(v=>v.exp>now).length,daily:days.map(d=>({d,n:cnt[d]}))}})}
  if(sub==='users'){
   const q=(url.searchParams.get('q')||'').trim().toLowerCase().slice(0,80),page=Math.max(1,parseInt(url.searchParams.get('page'),10)||1),size=25,now=Date.now();
   const refs={},sc={};
   for(const u of Object.values(users))if(u.refBy)refs[u.refBy]=(refs[u.refBy]||0)+1;
   for(const v of Object.values(sess))if(v.exp>now)sc[v.email]=(sc[v.email]||0)+1;
   let rows=Object.entries(users).map(([email,u])=>({email,name:u.name,phone:u.phone||'',role:u.role||'member',created:u.created,referral:u.ref,refBy:u.refBy||null,referred:refs[u.ref]||0,sessions:sc[email]||0,vvipUntil:u.vvipUntil||null,vvipActive:vvipOn(u)}));
   if(q)rows=rows.filter(r=>[r.email,r.name,r.phone,r.referral].some(x=>String(x||'').toLowerCase().includes(q)));
   rows.sort((a,b)=>String(b.created).localeCompare(String(a.created)));
   return json(res,200,{ok:true,total:rows.length,page,pages:Math.max(1,Math.ceil(rows.length/size)),users:rows.slice((page-1)*size,page*size)})}
  if(sub==='sessions'){
   const email=String(url.searchParams.get('email')||'').trim().toLowerCase();
   if(!users[email])return json(res,404,{ok:false,error:'Pengguna tidak ditemukan.'});
   const list=Object.entries(sess).filter(([k,v])=>v.email===email&&v.exp>Date.now()).sort((a,b)=>(b[1].iat||0)-(a[1].iat||0)).map(([k,v])=>({id:k.slice(0,12),current:k===cur,device:uaName(v.ua||''),since:v.iat||null,until:v.exp}));
   return json(res,200,{ok:true,sessions:list})}
  if(sub==='log')return json(res,200,{ok:true,log:readLog(100)});
  return json(res,404,NF)}
 if(req.method!=='POST')return json(res,405,{ok:false,error:'Metode tidak didukung.'});
 if(!sameOrigin(req))return json(res,403,{ok:false,error:'Asal permintaan tidak valid.'});
 const b=await readBody(req),email=String(b.email||'').trim().toLowerCase(),t=users[email];
 if(!t)return json(res,404,{ok:false,error:'Pengguna tidak ditemukan.'});
 const self=email===me.email;
 const revokeAll=()=>{let n=0;for(const k of Object.keys(sess))if(sess[k].email===email&&!(self&&k===cur)){delete sess[k];n++}save(FS,sess);return n};
 if(sub==='role'){
  const role=['admin','member','trader'].includes(b.role)?b.role:null;
  if(!role)return json(res,400,{ok:false,error:'Peran tidak valid.'});
  if((t.role||'member')===role)return json(res,200,{ok:true,role});
  if(self)return json(res,400,{ok:false,error:'Anda tidak dapat mengubah peran akun Anda sendiri.'});
  if(t.role==='admin'&&adminCount()<=1)return json(res,400,{ok:false,error:'Harus ada minimal satu admin.'});
  t.role=role;saveUsers();if(role==='member')mt4Bridge.revokeUser(email);logAdmin(me.email,'role',email,ip,{role});
  return json(res,200,{ok:true,role})}
 if(sub==='reset'){
  if(self)return json(res,400,{ok:false,error:'Untuk akun Anda sendiri, ganti kata sandi lewat Pengaturan Akun.'});
  const pw=tempPw();t.salt=crypto.randomBytes(16).toString('hex');t.hash=await hashPw(pw,t.salt);saveUsers();
  const n=revokeAll();logAdmin(me.email,'reset',email,ip,{sessionsRevoked:n});
  return json(res,200,{ok:true,password:pw,sessionsRevoked:n})}
 if(sub==='logout-all'){const n=revokeAll();logAdmin(me.email,'logout-all',email,ip,{sessionsRevoked:n});return json(res,200,{ok:true,revoked:n})}
 if(sub==='sessions/revoke'){
  const id=String(b.id||'');
  if(!/^[0-9a-f]{12}$/.test(id))return json(res,400,{ok:false,error:'ID sesi tidak valid.'});
  const key=Object.keys(sess).find(k=>k.startsWith(id)&&sess[k].email===email);
  if(!key)return json(res,404,{ok:false,error:'Sesi tidak ditemukan.'});
  if(key===cur)return json(res,400,{ok:false,error:'Itu sesi Anda saat ini.'});
  delete sess[key];save(FS,sess);logAdmin(me.email,'revoke',email,ip);return json(res,200,{ok:true})}
 if(sub==='delete'){
  if(self)return json(res,400,{ok:false,error:'Anda tidak dapat menghapus akun Anda sendiri.'});
  if(String(b.confirm||'').trim().toLowerCase()!==email)return json(res,400,{ok:false,error:'Ketik email pengguna untuk konfirmasi.'});
  if(t.role==='admin'&&adminCount()<=1)return json(res,400,{ok:false,error:'Harus ada minimal satu admin.'});
  const n=revokeAll();mt4Bridge.revokeUser(email);delete users[email];saveUsers();logAdmin(me.email,'delete',email,ip,{name:t.name});
  return json(res,200,{ok:true})}

 if(sub==='vvip'){   /* beri / perpanjang / cabut VVIP secara manual (pembayaran via transfer) */
  const act=String(b.action||''),was=t.vvipUntil||null,on=vvipOn(t),bad=m=>json(res,400,{ok:false,error:m});
  if(!['grant','extend','revoke'].includes(act))return bad('Tindakan tidak valid.');
  if(act==='revoke'){
   if(!on)return bad('Pengguna ini tidak sedang VVIP.');
   delete t.vvipUntil;saveUsers();logAdmin(me.email,'vvip-revoke',email,ip,{was});
   return json(res,200,{ok:true,vvip_active:false,vvip_until:null})}
  if(act==='grant'&&on)return bad('Pengguna ini sudah VVIP. Gunakan Perpanjang.');
  if(act==='extend'&&!on)return bad('Pengguna ini belum VVIP aktif. Gunakan Beri VVIP.');
  const END=d=>Date.parse(d+'T23:59:59+07:00'),now=Date.now();   /* berakhir pada 23.59 WIB di tanggal tsb */
  let until;
  if(b.until!==undefined&&b.until!==''){
   const d=String(b.until);
   until=/^\d{4}-\d{2}-\d{2}$/.test(d)?END(d):NaN;
   if(!Number.isFinite(until)||wibDay(until)!==d)return bad('Tanggal berakhir tidak valid.')}
  else{
   const n=Number(b.days);if(!Number.isInteger(n)||n<1||n>3650)return bad('Isi tanggal berakhir atau jumlah hari (1 sampai 3650).');
   until=act==='extend'?Date.parse(t.vvipUntil)+n*864e5:END(wibDay(now+n*864e5))}
  if(until<=now)return bad('Tanggal berakhir harus setelah hari ini.');
  if(until>now+3650*864e5)return bad('Tanggal berakhir terlalu jauh (maksimal 10 tahun).');
  if(act==='extend'&&until<=Date.parse(t.vvipUntil))return bad('Tanggal baru harus setelah masa aktif saat ini.');
  t.vvipUntil=new Date(until).toISOString();saveUsers();
  logAdmin(me.email,'vvip-'+act,email,ip,{until:t.vvipUntil,was});
  return json(res,200,{ok:true,vvip_active:true,vvip_until:t.vvipUntil})}
 return json(res,404,NF)}

/* ---------- file statis ---------- */
function serve(req,res,url){
 if(req.method!=='GET'&&req.method!=='HEAD')return send(res,405,'Method Not Allowed',{Allow:'GET, HEAD'});
 let p;try{p=decodeURIComponent(url.pathname)}catch(e){return send(res,400,'Bad Request')}
 if(p.includes('\0')||p.split('/').some(s=>s.startsWith('.')))return send(res,404,'Not Found');
 if(p==='/admin.html'){syncUsers();const au=currentUser(req);if(!au||au.role!=='admin')return send(res,404,'<h1>404</h1><p>Halaman tidak ditemukan.</p>',{'Content-Type':'text/html; charset=utf-8'})}
 let f=path.join(ROOT,path.normalize(p));
 if(f!==ROOT&&!f.startsWith(ROOT+path.sep))return send(res,403,'Forbidden');
 fs.stat(f,(e,st)=>{
  if(!e&&st.isDirectory()){f=path.join(f,'index.html');return fs.stat(f,(e2,s2)=>e2?send(res,404,'Not Found'):stream(f,s2))}
  if(e||!st.isFile())return send(res,404,'<h1>404</h1><p>Halaman tidak ditemukan.</p>',{'Content-Type':'text/html; charset=utf-8'});
  stream(f,st)});
 function stream(f,st){const t=MIME[path.extname(f).toLowerCase()];if(!t)return send(res,404,'Not Found');
  res.writeHead(200,{...SEC,'Content-Type':t,'Content-Length':st.size,'Cache-Control':/\.woff2$/.test(p)?'public, max-age=2592000':'no-cache',...(p==='/admin.html'?{'Cache-Control':'no-store','X-Robots-Tag':'noindex, nofollow'}:{})});
  if(req.method==='HEAD')return res.end();fs.createReadStream(f).on('error',()=>res.destroy()).pipe(res)}}

http.createServer((req,res)=>{let url;try{url=new URL(req.url,'http://x')}catch(e){return send(res,400,'Bad Request')}
 if(url.pathname.startsWith('/api/'))return api(req,res,url);serve(req,res,url)})
.listen(PORT,()=>console.log(`FOR-X berjalan di http://localhost:${PORT}  (situs: ${ROOT})`));
