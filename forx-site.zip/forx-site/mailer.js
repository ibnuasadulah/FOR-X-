'use strict';
/* Pengirim email tanpa dependensi (pakai fetch bawaan Node 18+).
   Pilih salah satu lewat variabel lingkungan:
     RESEND_API_KEY  -> https://resend.com
     BREVO_API_KEY   -> https://brevo.com
   MAIL_FROM contoh: FOR-X <noreply@domainanda.com>
   Tanpa kunci apa pun: isi email dicetak ke konsol server (untuk uji coba di komputer sendiri). */
function parseFrom(s) {
  const m = String(s || '').match(/^\s*"?([^"<]*?)"?\s*<([^>]+)>\s*$/);
  return m ? { name: m[1].trim() || 'FOR-X', email: m[2].trim() } : { name: 'FOR-X', email: String(s || '').trim() };
}
async function sendMail({ to, subject, html, text }) {
  const E = process.env, from = E.MAIL_FROM || 'FOR-X <onboarding@resend.dev>';
  let r;
  if (E.BREVO_API_KEY) {
    const f = parseFrom(from);
    r = await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST', signal: AbortSignal.timeout(10000),
      headers: { 'api-key': E.BREVO_API_KEY, 'Content-Type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({ sender: f, to: [{ email: to }], subject, htmlContent: html, textContent: text })
    });
  } else if (E.RESEND_API_KEY) {
    r = await fetch('https://api.resend.com/emails', {
      method: 'POST', signal: AbortSignal.timeout(10000),
      headers: { Authorization: 'Bearer ' + E.RESEND_API_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from, to: [to], subject, html, text })
    });
  } else {
    console.log('\n[EMAIL - mode uji, belum ada RESEND_API_KEY / BREVO_API_KEY]\nKe: ' + to + '\nSubjek: ' + subject + '\n' + text + '\n');
    return { dev: true };
  }
  if (!r.ok) throw new Error('Pengiriman email gagal (HTTP ' + r.status + '): ' + (await r.text()).slice(0, 300));
  return { ok: true };
}
function resetEmail(link, minutes) {
  const subject = 'Reset kata sandi FOR-X';
  const text = 'Kami menerima permintaan reset kata sandi untuk akun FOR-X Anda.\n\nBuka link berikut untuk membuat kata sandi baru (berlaku ' + minutes + ' menit, sekali pakai):\n' + link + '\n\nJika Anda tidak merasa memintanya, abaikan email ini. Kata sandi Anda tidak berubah.';
  const html = '<div style="background:#0b0f0d;padding:32px 16px;font-family:Arial,Helvetica,sans-serif">'
    + '<div style="max-width:480px;margin:0 auto;background:#151a17;border:1px solid #243029;border-radius:16px;padding:32px;color:#e8efe9">'
    + '<h2 style="margin:0 0 12px;font-size:22px;color:#fff">Reset kata sandi</h2>'
    + '<p style="margin:0 0 20px;line-height:1.6;color:#b4c0b7">Kami menerima permintaan reset kata sandi untuk akun FOR-X Anda. Klik tombol di bawah untuk membuat kata sandi baru. Link berlaku <b>' + minutes + ' menit</b> dan hanya bisa dipakai sekali.</p>'
    + '<p style="margin:0 0 24px"><a href="' + link + '" style="display:inline-block;background:#12d37f;color:#04130b;text-decoration:none;font-weight:700;padding:14px 26px;border-radius:12px">Buat Kata Sandi Baru</a></p>'
    + '<p style="margin:0 0 6px;font-size:12px;color:#7f8c84;line-height:1.6">Atau salin link ini ke browser:<br><span style="word-break:break-all">' + link + '</span></p>'
    + '<p style="margin:18px 0 0;font-size:12px;color:#7f8c84;line-height:1.6">Jika Anda tidak merasa memintanya, abaikan email ini. Kata sandi Anda tidak berubah.</p>'
    + '</div></div>';
  return { subject, text, html };
}
module.exports = { sendMail, resetEmail };
